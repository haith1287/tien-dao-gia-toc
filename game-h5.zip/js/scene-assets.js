
(function() {
  const root = document.documentElement.style;
  root.setProperty("--asset-meditation-male", 'url("assets/images/asset_0421_57c31c588762.webp")');
  root.setProperty("--asset-meditation-female", 'url("assets/images/asset_0422_710b10e653a7.webp")');
})();
