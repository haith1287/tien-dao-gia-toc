
  document.documentElement.style.setProperty("--asset-estate-map-concept", 'url("assets/images/asset_0420_d06cad9b8073.webp")');
