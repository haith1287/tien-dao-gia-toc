
    // =========================================================================
    // 1. DỮ LIỆU CỐT LÕI & CẢNH GIỚI TU TIÊN (MASTER GDD 1.0)
    // =========================================================================
    const REALMS = [
      { id: 0, name: "Phàm Nhân", maxXp: 40, baseHp: 80, baseAtk: 12, baseDef: 6, baseSpd: 10, pillReq: null },
      { id: 1, name: "Luyện Khí 1", maxXp: 80, baseHp: 120, baseAtk: 20, baseDef: 10, baseSpd: 14, pillReq: null },
      { id: 2, name: "Luyện Khí 2", maxXp: 130, baseHp: 165, baseAtk: 29, baseDef: 15, baseSpd: 18, pillReq: null },
      { id: 3, name: "Luyện Khí 3", maxXp: 190, baseHp: 215, baseAtk: 39, baseDef: 21, baseSpd: 22, pillReq: null },
      { id: 4, name: "Luyện Khí 4", maxXp: 260, baseHp: 270, baseAtk: 50, baseDef: 28, baseSpd: 27, pillReq: null },
      { id: 5, name: "Luyện Khí 5", maxXp: 350, baseHp: 340, baseAtk: 64, baseDef: 36, baseSpd: 33, pillReq: null },
      { id: 6, name: "Luyện Khí 6", maxXp: 460, baseHp: 420, baseAtk: 80, baseDef: 45, baseSpd: 40, pillReq: null },
      { id: 7, name: "Luyện Khí 7", maxXp: 590, baseHp: 510, baseAtk: 98, baseDef: 55, baseSpd: 48, pillReq: null },
      { id: 8, name: "Luyện Khí 8", maxXp: 750, baseHp: 620, baseAtk: 118, baseDef: 67, baseSpd: 57, pillReq: null },
      { id: 9, name: "Luyện Khí 9", maxXp: 950, baseHp: 750, baseAtk: 142, baseDef: 80, baseSpd: 68, pillReq: "truc_co_dan" },
      { id: 10, name: "Trúc Cơ Sơ", maxXp: 1400, baseHp: 1150, baseAtk: 210, baseDef: 120, baseSpd: 90, pillReq: null },
      { id: 11, name: "Trúc Cơ Trung", maxXp: 2000, baseHp: 1550, baseAtk: 285, baseDef: 165, baseSpd: 112, pillReq: null },
      { id: 12, name: "Trúc Cơ Hậu", maxXp: 2800, baseHp: 2050, baseAtk: 370, baseDef: 215, baseSpd: 136, pillReq: "ket_kim_dan" },
      { id: 13, name: "Kim Đan Sơ", maxXp: 4200, baseHp: 3100, baseAtk: 540, baseDef: 310, baseSpd: 175, pillReq: null },
      { id: 14, name: "Kim Đan Hậu", maxXp: 6000, baseHp: 4300, baseAtk: 740, baseDef: 430, baseSpd: 215, pillReq: "ngung_anh_dan" },
      { id: 15, name: "Nguyên Anh", maxXp: 9000, baseHp: 6500, baseAtk: 1100, baseDef: 650, baseSpd: 270, pillReq: null }
    ];

    // Linh căn phân hóa mạnh 4 chỉ số thiên phú (Hút HP, Né Tránh, Bạo Kích, Liên Kích)
    const SPIRIT_ROOTS = [
      { id: "tap", name: "Ngũ Hành Tạp Căn", rate: 48, xpMult: 0.9, tribPenalty: 0, bias: { lifesteal: 1.0, dodge: 1.2, crit: 1.5, combo: 1.0 } },
      { id: "tu", name: "Tứ Hành Linh Căn", rate: 28, xpMult: 1.05, tribPenalty: 4, bias: { lifesteal: 1.5, dodge: 2.0, crit: 2.2, combo: 1.8 } },
      { id: "tam", name: "Tam Hành Chân Căn", rate: 14, xpMult: 1.25, tribPenalty: 8, bias: { lifesteal: 2.5, dodge: 3.0, crit: 3.5, combo: 2.5 } },
      { id: "song_huyet", name: "Mộc Thủy Song Căn", rate: 4, xpMult: 1.5, tribPenalty: 14, bias: { lifesteal: 6.5, dodge: 4.5, crit: 2.5, combo: 2.5 } },
      { id: "song_phong", name: "Phong Lôi Song Căn", rate: 3.5, xpMult: 1.55, tribPenalty: 15, bias: { lifesteal: 2.0, dodge: 6.8, crit: 5.5, combo: 5.2 } },
      { id: "thien_kiem", name: "Thiên Kiếm Linh Căn", rate: 1.8, xpMult: 1.85, tribPenalty: 22, bias: { lifesteal: 2.5, dodge: 4.0, crit: 9.5, combo: 7.5 } },
      { id: "di_loi", name: "Dị Biến Hỗn Độn Căn", rate: 0.7, xpMult: 2.1, tribPenalty: 28, bias: { lifesteal: 5.5, dodge: 5.5, crit: 8.5, combo: 8.0 } }
    ];

    const BLOODLINES = [
      { id: "kiem_hoang", name: "Kiếm Hoàng Huyết Mạch", desc: "+4% Bạo Kích & +3% Liên Kích bẩm sinh", bonus: { crit: 4, combo: 3 } },
      { id: "thanh_long", name: "Thanh Long Huyết Mạch", desc: "+4% Hút HP & +25% HP cơ bản", bonus: { lifesteal: 4, hpMult: 1.25 } },
      { id: "chu_tuoc", name: "Chu Tước Huyết Mạch", desc: "+4% Né Tránh & +20% Tốc Độ", bonus: { dodge: 4, spdMult: 1.2 } },
      { id: "huyen_vu", name: "Huyền Vũ Huyết Mạch", desc: "+30% Phòng Thủ & +10 điểm % tỷ lệ thành công độ kiếp", bonus: { defMult: 1.3, tribSave: 10 } }
    ];

    // Kho tên 2 chữ chuẩn chỉnh (Họ 1 chữ + Tên 1 chữ)
    const SURNAMES = ["Trần", "Lý", "Tiêu", "Lâm", "Diệp", "Tô", "Hàn", "Mạc", "Vũ", "Tần", "Giang", "Ninh"];
    const MALE_NAMES = ["Nam", "Phong", "Vân", "Tiêu", "Hạo", "Vũ", "Kiệt", "Minh", "Thần", "Huy", "Quân", "Lâm", "Sơn", "Triết"];
    const FEMALE_NAMES = ["Dao", "Nhi", "Linh", "Uyên", "Tuyết", "Lan", "Ngọc", "Vy", "Trúc", "Sương", "Mai", "Cầm", "Thanh", "Hân"];

    // =========================================================================
    // 2. BỘ SƯU TẬP BẢO VẬT (TRẤN TỘC CHI BẢO + PHÀM / THẦN / TUYỆT PHẨM)
    // =========================================================================
    const TREASURES_DB = [
      {
        id: "trantoc_an",
        name: "Thanh Liên Cổ Ấn",
        tier: "trantoc",
        tierLabel: "Trấn Tộc Chi Bảo",
        cannotUpgrade: true,
        owned: true,
        level: 1,
        shards: 0,
        lore: "Bảo ấn trấn sơn duy nhất còn sót lại từ thời Tiên Tổ khai phái, khắc phù văn Thanh Liên hộ mệnh toàn tộc, vĩnh viễn không thể thăng cấp.",
        effectDesc: "Toàn tộc +15% HP tối đa, +3% Né Tránh, +2 Tu Vi/tháng",
        bonus: { hpPct: 15, dodge: 3, xpFlat: 2 },
        color: "#059669"
      },
      {
        id: "pham_la_ban",
        name: "Tầm Long La Bàn",
        tier: "pham",
        tierLabel: "Phàm Phẩm",
        cannotUpgrade: false,
        owned: true,
        level: 1,
        shards: 10,
        lore: "La bàn đồng cổ dùng để dò tìm linh mạch và khoáng thạch dưới lòng đất.",
        effectDesc: "Cơ nghiệp tăng +8% sản lượng Linh thạch mỗi cấp",
        bonus: { incomePct: 8 },
        color: "#4b7561"
      },
      {
        id: "pham_kiem_quyet",
        name: "Thanh Phong Kiếm Phổ",
        tier: "pham",
        tierLabel: "Phàm Phẩm",
        cannotUpgrade: false,
        owned: false,
        level: 0,
        shards: 15,
        lore: "Tàn quyển kiếm pháp ghi lại tâm đắc ngự kiếm cơ bản của tán tu.",
        effectDesc: "Toàn tộc +18 Tấn Công & +1.2% Liên Kích mỗi cấp",
        bonus: { atkFlat: 18, combo: 1.2 },
        color: "#4b7561"
      },
      {
        id: "pham_ho_tam",
        name: "Huyền Thiết Hộ Tâm",
        tier: "pham",
        tierLabel: "Phàm Phẩm",
        cannotUpgrade: false,
        owned: false,
        level: 0,
        shards: 10,
        lore: "Tấm giáp hộ tâm rèn từ hàn thiết trăm năm, giảm sát thương chí mạng.",
        effectDesc: "Toàn tộc +15 Phòng Thủ & +80 HP mỗi cấp",
        bonus: { defFlat: 15, hpFlat: 80 },
        color: "#4b7561"
      },
      {
        id: "than_huyet_chau",
        name: "Thị Huyết Ma Châu",
        tier: "than",
        tierLabel: "Thần Phẩm",
        cannotUpgrade: false,
        owned: false,
        level: 0,
        shards: 5,
        lore: "Linh châu ngưng tụ tinh huyết Thái Cổ Yêu Vương, giúp người đeo hút sinh khí địch thủ.",
        effectDesc: "Toàn tộc +2.5% Hút HP & +35 Tấn Công mỗi cấp",
        bonus: { lifesteal: 2.5, atkFlat: 35 },
        color: "#7c3aed"
      },
      {
        id: "than_phong_dieu",
        name: "Lưu Vân Phượng Tiêu",
        tier: "than",
        tierLabel: "Thần Phẩm",
        cannotUpgrade: false,
        owned: false,
        level: 0,
        shards: 0,
        lore: "Ngọc tiêu làm từ tre Phượng Vĩ, tiếng sáo thanh tâm trấn áp Tâm Ma khi độ kiếp.",
        effectDesc: "Toàn tộc +2.8% Né Tránh & +15 Tốc Độ mỗi cấp",
        bonus: { dodge: 2.8, spdFlat: 15 },
        color: "#7c3aed"
      },
      {
        id: "tuyet_chu_tien",
        name: "Tru Tiên Tàn Kiếm",
        tier: "tuyet",
        tierLabel: "Tuyệt Phẩm",
        cannotUpgrade: false,
        owned: false,
        level: 0,
        shards: 0,
        lore: "Mảnh vỡ thần binh thượng cổ mang sát khí ngập trời, mỗi đòn chém đều có thể bộc phát uy lực hủy diệt.",
        effectDesc: "Toàn tộc +4.5% Bạo Kích, +3.5% Liên Kích & +80 Tấn Công mỗi cấp",
        bonus: { crit: 4.5, combo: 3.5, atkFlat: 80 },
        color: "#d97706"
      },
      {
        id: "tuyet_cuu_dinh",
        name: "Cửu Long Thần Đỉnh",
        tier: "tuyet",
        tierLabel: "Tuyệt Phẩm",
        cannotUpgrade: false,
        owned: false,
        level: 0,
        shards: 0,
        lore: "Thần đỉnh luyện đan thượng cổ có chín con rồng quấn quanh, tăng mạnh tỷ lệ thành đan và tu vi toàn tộc.",
        effectDesc: "Toàn tộc +250 HP, +3.0% Hút HP & +12 điểm % tỷ lệ luyện đan mỗi cấp",
        bonus: { hpFlat: 250, lifesteal: 3.0, alchemyPct: 12 },
        color: "#d97706"
      }
    ];

    // =========================================================================
    // 3. DỮ LIỆU ĐAN DƯỢC, LINH THẢO, BÍ CẢNH & CƠ NGHIỆP
    // =========================================================================
    const HERBS_DB = {
      ngoc_tuy_chi: { id: "ngoc_tuy_chi", name: "Ngọc Tủy Chi", rarity: "Nhất Giai", rate: 0.075 },
      thien_tinh_thao: { id: "thien_tinh_thao", name: "Thiên Tinh Thảo", rarity: "Nhị Giai", rate: 0.045 },
      cuu_khuc_tham: { id: "cuu_khuc_tham", name: "Cửu Khúc Linh Tham", rarity: "Tam Giai", rate: 0.022 }
    };

    const PILLS_DB = [
      { id: "truc_co_dan", name: "Trúc Cơ Đan", herbId: "ngoc_tuy_chi", herbCost: 2, stoneCost: 60, baseRate: 22, desc: "Đột phá Luyện Khí 9 → Trúc Cơ" },
      { id: "ket_kim_dan", name: "Kết Kim Đan", herbId: "thien_tinh_thao", herbCost: 2, stoneCost: 180, baseRate: 14, desc: "Đột phá Trúc Cơ Hậu → Kim Đan" },
      { id: "ngung_anh_dan", name: "Ngưng Anh Đan", herbId: "cuu_khuc_tham", herbCost: 2, stoneCost: 420, baseRate: 8, desc: "Đột phá Kim Đan Hậu → Nguyên Anh" }
    ];

    const SECRET_REALMS = [
      {
        id: "huyet_sac",
        name: "Huyết Sắc Cấm Địa",
        tierLabel: "Cảnh Giới: Luyện Khí 1 – 9",
        minRealm: 1,
        maxRealm: 9,
        herbDrop: "ngoc_tuy_chi",
        stoneReward: [28, 48],
        enemyPool: [
          { name: "Huyết Lang Yêu", hpMult: 1.5, atkMult: 1.05, defMult: 0.9, type: "beast" },
          { name: "Hắc Phong Tà Tu", hpMult: 1.4, atkMult: 1.15, defMult: 1.0, type: "rogue" }
        ]
      },
      {
        id: "van_trach",
        name: "Vạn Trạch Yêu Uyên",
        tierLabel: "Cảnh Giới: Trúc Cơ Sơ – Hậu",
        minRealm: 10,
        maxRealm: 12,
        herbDrop: "thien_tinh_thao",
        stoneReward: [85, 135],
        enemyPool: [
          { name: "Xích Hỏa Giao Long", hpMult: 1.75, atkMult: 1.2, defMult: 1.1, type: "beast" },
          { name: "Huyết Ma Trưởng Lão", hpMult: 1.65, atkMult: 1.25, defMult: 1.05, type: "rogue" }
        ]
      },
      {
        id: "co_tien_khau",
        name: "Cổ Tiên Kiếm Khư",
        tierLabel: "Cảnh Giới: Kim Đan – Nguyên Anh",
        minRealm: 13,
        maxRealm: 15,
        herbDrop: "cuu_khuc_tham",
        stoneReward: [220, 340],
        enemyPool: [
          { name: "Thái Cổ Lôi Viên", hpMult: 2.0, atkMult: 1.3, defMult: 1.2, type: "beast" },
          { name: "U Minh Ma Tôn", hpMult: 1.9, atkMult: 1.35, defMult: 1.15, type: "rogue" }
        ]
      }
    ];

    const ESTATES_INIT = [
      { id: "linh_dien", name: "Linh Điền", level: 1, baseIncome: 4.5, upgradeCost: 90, guardianId: null, type: "field" },
      { id: "linh_mo", name: "Linh Mỏ", level: 0, baseIncome: 9.0, upgradeCost: 140, guardianId: null, type: "mine" },
      { id: "dan_cac", name: "Đan Các", level: 0, baseIncome: 15.0, upgradeCost: 230, guardianId: null, type: "alchemy" },
      { id: "khi_phuong", name: "Khí Phường", level: 0, baseIncome: 22.0, upgradeCost: 340, guardianId: null, type: "forge" },
      { id: "tang_kinh", name: "Tàng Kinh Các", level: 0, baseIncome: 32.0, upgradeCost: 480, guardianId: null, type: "library" },
      { id: "to_son", name: "Tổ Sơn Linh Mạch", level: 0, baseIncome: 48.0, upgradeCost: 700, guardianId: null, type: "mountain" }
    ];

    // =========================================================================
    // 4. TRẠNG THÁI TOÀN CỤC CỦA GAME
    // =========================================================================
    const GAME_CONFIG = Object.freeze({
      saveSchemaVersion: 2,
      saveKey: "tien_dao_gia_toc_save_v2",
      legacySaveKey: "tien_dao_gia_toc_v5",
      backupKey: "tien_dao_gia_toc_backup",
      autosaveIntervalMs: 45000,
      maxSaveBytes: 5 * 1024 * 1024,
      maxMembers: 5000,
      maxCharacterAge: 1000, // Tránh cắt tuổi thọ tu sĩ cấp cao khi đọc save.
      maxResource: 1000000000,
      maxNameLength: 24,
      maxAbodeLevel: 11,
      maxSquadSize: 4,
      minMarriageAge: 16,
      guardianMinAge: 14,
      maxHistoryEntries: 200,
      adventureGlobalCooldownMonths: 6,
      defaultAdventureCooldownMonths: 24
    });

    function createInitialGameState() {
      return {
        started: false,
        paused: false,
        year: 1000,
        month: 1,
        clanSurname: "Trần",
        bloodlineId: "kiem_hoang",
        spiritStones: 180,
        veinLevel: 1,
        abodeLevel: 1, // Sức chứa: 6 / 12 / 24 / 48 ...
        members: [],
        nextMemberId: 1,
        activeCultivatorId: 1,
        squadIds: [1],
        teamHp: 120,
        teamMaxHp: 120,
        herbs: { ngoc_tuy_chi: 1, thien_tinh_thao: 0, cuu_khuc_tham: 0 },
        pills: { truc_co_dan: 0, ket_kim_dan: 0, ngung_anh_dan: 0 },
        healPills: 2,
        treasures: JSON.parse(JSON.stringify(TREASURES_DB)),
        pityThan: 0,
        pityTuyet: 0,
        estates: JSON.parse(JSON.stringify(ESTATES_INIT)),
        outerDisciples: [],
        factions: [
          { id: "thanh_van", name: "Thanh Vân Kiếm Tông", relation: 55, power: 450 },
          { id: "hac_phong", name: "Hắc Phong Tà Trại", relation: 20, power: 320 },
          { id: "duoc_vuong", name: "Dược Vương Cốc", relation: 60, power: 520 }
        ],
        historyLog: [],
        s3aChronicle: [],
        s3aSeen: {},
        s3dChains: [],
        s3dChronicle: [],
        destinyQueue: [],
        destinySeen: {},
        destinyLastMonth: -100,
        pendingAdventure: null,
        lastAdventureMonthIndex: 0,
        lastAdventureById: {},
        clanLeaderId: null,
        heirId: null,
        clanExtinct: false,
        clanRescueUsed: false,
        marriagePolicy: "manual",
        familyMatchmaking: {},
        familyPregnancies: [],
        familyRequests: [],
        familyRequestCooldowns: {},
        familyBirthHistory: [],
        anThaiPills: 0,
        marriageNotices: {},
        birthPolicy: "balanced",
        // 3F: Gia bảo truyền đời, một di bảo đang kích hoạt và đạo thống của đương nhiệm.
        legacyRelics: [],
        legacyActiveRelicId: null,
        s3f3Arc: null,
        s3f3ArcCount: 0,
        s3f3LastEndMonth: -100,
        s3f4Expedition: { enabled:false, permittedIds:[], minHpPct:60, everyMonths:5, realmId:'', lastMonth:-100, total:0, victories:0, deaths:0 },
        s3f4Politics: {lastMonth:-100, nextType:0, marks:{}, feud:0, alliance:0, school:0, recorded:[]}
      };
    }

    let gameState = createInitialGameState();
    let selectedStartupGender = "male";
    let selectedStartupBloodline = "kiem_hoang";
    let timeLoopTimer = null;
    let autosaveTimer = null;
    let autosaveDebounceTimer = null;
    let gameIsDirty = false;
    let savedProgressAvailable = false;
    let loadedSaveSource = null;
    let allowNewGameOverwrite = false;
    let currentTab = "family";
    let dirtyViews = new Set(["family", "cave", "secret", "estate", "affairs"]);
    let memberById = new Map();
    let aggregateBonusRevision = 0;
    let cachedAggregateBonusRevision = -1;
    let cachedAggregateBonuses = null;
    let marriageModalContext = null;
    let adoptCandidateContext = null;

    // Trạng thái Zoom & Pan Cây Gia Phả
    let treeTransform = { x: 40, y: 35, scale: 1 };
    let isDraggingTree = false;
    let dragStart = { x: 0, y: 0 };
    let pinchStartDist = 0;
    let pinchStartScale = 1;
    let pinchAnchor = { contentX: 0, contentY: 0 };

    // Trạng thái Chiến Đấu Bí Cảnh
    let battleState = null;
    let battleAutoTimer = null;
    let battleActionLock = false;


    // =========================================================================
    // 4A. HẠ TẦNG STATE, AN TOÀN DỮ LIỆU VÀ LƯU/TẢI PHIÊN BẢN 2
    // =========================================================================
    function safeNumber(value, fallback = 0, min = 0, max = GAME_CONFIG.maxResource) {
      if (value == null || (typeof value !== "number" && typeof value !== "string")) return fallback;
      const n = Number(value);
      if (!Number.isFinite(n)) return fallback;
      return Math.min(max, Math.max(min, n));
    }

    function safeInteger(value, fallback = 0, min = 0, max = Number.MAX_SAFE_INTEGER) {
      if (value == null || (typeof value !== "number" && typeof value !== "string")) return fallback;
      const n = Number(value);
      if (!Number.isFinite(n)) return fallback;
      return Math.min(max, Math.max(min, Math.trunc(n)));
    }

    function safeOptionalId(value) {
      if (typeof value !== "number" && typeof value !== "string") return null;
      const n = Number(value);
      return Number.isSafeInteger(n) && n > 0 ? n : null;
    }

    function normalizePlayerName(value, fallback = "Vô Danh") {
      const rawName = typeof value === "string" ? value : (typeof value === "number" ? String(value) : "");
      const cleaned = rawName
        .normalize("NFC")
        .replace(/[\u0000-\u001F\u007F]/g, "")
        .replace(/\s+/g, " ")
        .trim();
      return Array.from(cleaned).slice(0, GAME_CONFIG.maxNameLength).join("") || fallback;
    }

    function escapeHtml(value) {
      return String(value ?? "").replace(/[&<>"']/g, ch => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      })[ch]);
    }

    function formatSigned(value, decimals = 1) {
      const n = Number.isFinite(Number(value)) ? Number(value) : 0;
      const rounded = Number(n.toFixed(decimals));
      return `${rounded > 0 ? "+" : ""}${rounded}`;
    }

    function markGameDirty() {
      if (!gameState || !gameState.started) return;
      gameIsDirty = true;
      if (autosaveDebounceTimer) clearTimeout(autosaveDebounceTimer);
      autosaveDebounceTimer = setTimeout(() => {
        autosaveDebounceTimer = null;
        if (gameIsDirty && gameState.started) saveGameToLocal({ silent: true, closeModal: false });
      }, 1500);
    }

    function markAllViewsDirty() {
      ["family", "cave", "secret", "estate", "affairs"].forEach(tab => dirtyViews.add(tab));
    }

    function invalidateAggregateBonuses() {
      aggregateBonusRevision++;
      cachedAggregateBonuses = null;
    }

    function getClanAggregateBonuses() {
      if (cachedAggregateBonusRevision === aggregateBonusRevision && cachedAggregateBonuses) {
        return cachedAggregateBonuses;
      }
      const totals = {
        hpFlat: 0, hpPct: 0, atkFlat: 0, defFlat: 0, spdFlat: 0,
        lifesteal: 0, dodge: 0, crit: 0, combo: 0,
        incomePct: 0, xpFlat: 0, alchemyPct: 0, tribSave: 0
      };
      (gameState.treasures || []).forEach(t => {
        if (!t.owned || t.level <= 0 || !t.bonus) return;
        Object.keys(totals).forEach(key => {
          if (Number.isFinite(Number(t.bonus[key]))) totals[key] += Number(t.bonus[key]) * t.level;
        });
      });
      const bloodline = BLOODLINES.find(b => b.id === gameState.bloodlineId) || BLOODLINES[0];
      totals.tribSave += Number(bloodline.bonus.tribSave || 0);
      // 3F: Chỉ một gia bảo + một đạo thống đương nhiệm có hiệu lực; không cộng dồn di vật nhiều đời.
      const activeRelic=(gameState.legacyRelics||[]).find(r=>r.id===gameState.legacyActiveRelicId);
      if(activeRelic){
        if(activeRelic.legacyKind==='scholar')totals.xpFlat+=1;
        if(activeRelic.legacyKind==='guardian')totals.defFlat+=2;
        if(activeRelic.legacyKind==='industry')totals.incomePct+=2;
      }
      const leader=(gameState.members||[]).find(m=>m.id===gameState.clanLeaderId&&m.alive);
      if(leader){
        if(leader.legacyPath==='dao')totals.xpFlat+=1;
        if(leader.legacyPath==='bao')totals.defFlat+=2;
        if(leader.legacyPath==='nghiep')totals.incomePct+=2;
      }
      cachedAggregateBonuses = totals;
      cachedAggregateBonusRevision = aggregateBonusRevision;
      return totals;
    }

    function rebuildMemberIndex() {
      memberById = new Map((gameState.members || []).map(member => [member.id, member]));
    }

    function getMemberById(id) {
      if (!memberById.size && gameState.members?.length) rebuildMemberIndex();
      return memberById.get(Number(id)) || gameState.members.find(member => member.id === Number(id)) || null;
    }

    function getValidLivingMember(id) {
      const member = getMemberById(id);
      return member && member.alive ? member : null;
    }

    function getValidGuardian(estate) {
      if (!estate || estate.guardianId == null) return null;
      const guardian = getValidLivingMember(estate.guardianId);
      if (!guardian || guardian.age < GAME_CONFIG.guardianMinAge) {
        estate.guardianId = null;
        return null;
      }
      const assignedElsewhere = gameState.estates.some(other =>
        other.id !== estate.id && Number(other.guardianId) === Number(guardian.id)
      );
      if (assignedElsewhere) {
        estate.guardianId = null;
        return null;
      }
      return guardian;
    }

    function addXp(member, amount) {
      if (!member || !member.alive) return 0;
      const realm = REALMS[Math.min(Math.max(0, member.realmIdx), REALMS.length - 1)];
      const before = safeNumber(member.xp, 0, 0, realm.maxXp);
      member.xp = Math.min(realm.maxXp, Math.max(0, before + safeNumber(amount, 0, -GAME_CONFIG.maxResource, GAME_CONFIG.maxResource)));
      return member.xp - before;
    }

    function clampGameStateResources(state = gameState) {
      state.spiritStones = safeNumber(state.spiritStones, 0, 0, GAME_CONFIG.maxResource);
      state.healPills = safeInteger(state.healPills, 0, 0, GAME_CONFIG.maxResource);
      state.herbs = state.herbs && typeof state.herbs === "object" ? state.herbs : {};
      state.pills = state.pills && typeof state.pills === "object" ? state.pills : {};
      ["ngoc_tuy_chi", "thien_tinh_thao", "cuu_khuc_tham"].forEach(id => {
        state.herbs[id] = safeInteger(state.herbs[id], 0, 0, GAME_CONFIG.maxResource);
      });
      ["truc_co_dan", "ket_kim_dan", "ngung_anh_dan"].forEach(id => {
        state.pills[id] = safeInteger(state.pills[id], 0, 0, GAME_CONFIG.maxResource);
      });
    }

    function getMonthIndex(state = gameState) {
      return safeInteger(state.year, 1000, 1, 999999) * 12 + safeInteger(state.month, 1, 1, 12);
    }

    function normalizePendingAdventure(pending, state = gameState) {
      if (!pending || typeof pending !== "object") return null;
      const legacyTitle = pending.template && typeof pending.template.title === "string"
        ? pending.template.title
        : "";
      const eventId = String(pending.eventId || "");
      const template = ADVENTURE_TEMPLATES.find(item => item.id === eventId || (legacyTitle && item.title === legacyTitle));
      const memberId = safeOptionalId(pending.memberId);
      const member = memberId == null ? null : (state.members || []).find(item => item.id === memberId);
      if (!template || !member || !member.alive) return null;
      return {
        eventId: template.id,
        memberId: member.id,
        context: {},
        createdAtMonthIndex: safeInteger(pending.createdAtMonthIndex, getMonthIndex(state), 0, Number.MAX_SAFE_INTEGER)
      };
    }

    function validateAndMigrateSave(input) {
      if (!input || typeof input !== "object" || Array.isArray(input)) {
        throw new Error("Tệp lưu không phải đối tượng JSON hợp lệ.");
      }
      const version = safeInteger(input.schemaVersion, 1, 1, 9999);
      if (version > GAME_CONFIG.saveSchemaVersion) {
        throw new Error(`Save thuộc phiên bản mới hơn (v${version}); bản game hiện tại chỉ hỗ trợ v${GAME_CONFIG.saveSchemaVersion}.`);
      }
      const data = input.game && typeof input.game === "object" && !Array.isArray(input.game)
        ? input.game
        : input;
      if (!Array.isArray(data.members)) {
        throw new Error("Save thiếu danh sách tộc nhân; dữ liệu gốc được giữ nguyên.");
      }
      if (data.members.length > GAME_CONFIG.maxMembers) {
        throw new Error(`Save vượt giới hạn ${GAME_CONFIG.maxMembers} nhân vật.`);
      }

      const state = createInitialGameState();
      state.started = Boolean(data.started);
      state.paused = Boolean(data.paused);
      state.year = safeInteger(data.year, 1000, 1, 999999);
      state.month = safeInteger(data.month, 1, 1, 12);
      state.clanSurname = normalizePlayerName(data.clanSurname, "Trần");
      state.bloodlineId = BLOODLINES.some(item => item.id === data.bloodlineId) ? data.bloodlineId : "kiem_hoang";
      state.spiritStones = safeNumber(data.spiritStones, 0, 0, GAME_CONFIG.maxResource);
      state.veinLevel = safeInteger(data.veinLevel, 1, 1, 100);
      state.abodeLevel = safeInteger(data.abodeLevel, 1, 1, GAME_CONFIG.maxAbodeLevel);
      state.nextMemberId = safeInteger(data.nextMemberId, 1, 1, Number.MAX_SAFE_INTEGER);
      state.teamHp = safeNumber(data.teamHp, 120, 0, GAME_CONFIG.maxResource);
      state.teamMaxHp = safeNumber(data.teamMaxHp, 120, 1, GAME_CONFIG.maxResource);
      state.healPills = safeInteger(data.healPills, 2, 0, GAME_CONFIG.maxResource);
      state.pityThan = safeInteger(data.pityThan, 0, 0, 100000);
      state.pityTuyet = safeInteger(data.pityTuyet, 0, 0, 100000);
      state.clanExtinct = Boolean(data.clanExtinct);
      state.clanRescueUsed = Boolean(data.clanRescueUsed);
      state.marriagePolicy = "manual"; // 3F.4.1: Gia Chủ duyệt toàn bộ, kể cả khi đọc save cũ.
      state.anThaiPills=safeInteger(data.anThaiPills,0,0,99999);
      state.familyMatchmaking={};
      if(data.familyMatchmaking && typeof data.familyMatchmaking==='object' && !Array.isArray(data.familyMatchmaking)){
        for(const [k,v] of Object.entries(data.familyMatchmaking).slice(-120)){
          if(!/^\d+$/.test(k)||!v||typeof v!=='object')continue;
          const cs=Array.isArray(v.candidates)?v.candidates.slice(0,3).filter(c=>c&&SPIRIT_ROOTS.some(r=>r.id===c.rootId)).map(c=>({
            name:normalizePlayerName(c.name,'Đạo Hữu'),age:safeInteger(c.age,20,18,200),realmIdx:safeInteger(c.realmIdx,1,0,REALMS.length-1),
            rootId:c.rootId,harmony:safeInteger(c.harmony,50,0,100),cost:safeInteger(c.cost,20,0,999999)
          })):[];
          state.familyMatchmaking[k]={lastSearch:safeInteger(v.lastSearch,-100,-100,12000000),expires:safeInteger(v.expires,-1,-1,12000000),candidates:cs};
        }
      }
      state.familyPregnancies=Array.isArray(data.familyPregnancies)?data.familyPregnancies.slice(0,100).filter(p=>p&&Number.isInteger(p.fatherId)&&Number.isInteger(p.motherId)).map(p=>({
        fatherId:safeInteger(p.fatherId,1,1,999999999),motherId:safeInteger(p.motherId,1,1,999999999),
        conceived:safeInteger(p.conceived,0,0,12000000),due:safeInteger(p.due,0,0,12000000),
        approved:true
      })):[];
      state.familyRequests=Array.isArray(data.familyRequests)?data.familyRequests.slice(0,100).filter(r=>r&&Number.isInteger(r.fatherId)&&Number.isInteger(r.motherId)).map(r=>({fatherId:r.fatherId,motherId:r.motherId,created:safeInteger(r.created,0,0,12000000)})):[];
      state.familyRequestCooldowns={};
      if(data.familyRequestCooldowns && typeof data.familyRequestCooldowns==='object')for(const [k,v] of Object.entries(data.familyRequestCooldowns).slice(-300)){
        if(/^\d+:\d+$/.test(k))state.familyRequestCooldowns[k]=safeInteger(v,-100,-100,12000000);
      }
      state.familyBirthHistory=Array.isArray(data.familyBirthHistory)?data.familyBirthHistory.slice(-100).map(x=>String(x).slice(0,280)):[];
      state.birthPolicy = ["balanced", "slow"].includes(data.birthPolicy) ? data.birthPolicy : "balanced";
      state.legacyRelics = Array.isArray(data.legacyRelics) ? data.legacyRelics.slice(-16).filter(r=>r&&Number.isInteger(r.originId)&&r.originId>0).map(r=>({
        id:`leader:${safeInteger(r.originId,1,1,999999999)}`,
        originId:safeInteger(r.originId,1,1,999999999),
        originName:normalizePlayerName(r.originName,'Tiền Tộc Trưởng'),
        year:safeInteger(r.year,state.year,1,999999),
        generation:safeInteger(r.generation,1,1,1000),
        craftId:S3E_CRAFTS.some(c=>c.id===r.craftId)?r.craftId:'none',
        legacyKind:['scholar','guardian','industry'].includes(r.legacyKind)?r.legacyKind:'scholar',
        name:String(r.name||'Gia Bảo Truyền Đời').slice(0,80)
      })) : [];
      state.legacyActiveRelicId = state.legacyRelics.some(r=>r.id===data.legacyActiveRelicId) ? data.legacyActiveRelicId : null;
      // Sprint 3F.3: chuỗi liên điện chỉ lưu dữ liệu nguyên thủy, không lưu callback.
      const arc=data.s3f3Arc;
      state.s3f3Arc=arc && typeof arc==='object' &&
        ['discovered','research','formula','await_tribulation','complete','archived'].includes(arc.status) ? {
          status:arc.status,
          discovererId:safeInteger(arc.discovererId,1,1,999999999),
          startedAt:safeInteger(arc.startedAt,0,0,12000000),
          updatedAt:safeInteger(arc.updatedAt,0,0,12000000),
          progress:safeInteger(arc.progress,0,0,20),
          route:['funded','frugal','shelved',''].includes(arc.route)?arc.route:'',
          researcherId:arc.researcherId==null?null:safeOptionalId(arc.researcherId),
          product:['truc_co_dan','heal',''].includes(arc.product)?arc.product:'',
          resultMemberId:arc.resultMemberId==null?null:safeOptionalId(arc.resultMemberId)
        }:null;
      state.s3f3ArcCount=safeInteger(data.s3f3ArcCount,0,0,10000);
      state.s3f3LastEndMonth=safeInteger(data.s3f3LastEndMonth,-100,-100,12000000);
      // Sprint 3F.4.1: quyền lịch luyện và nhân quả liên điện được lưu đúng phiên bản.
      const ex=data.s3f4Expedition && typeof data.s3f4Expedition==='object'?data.s3f4Expedition:{};
      state.s3f4Expedition={
        enabled:ex.enabled===true,
        permittedIds:Array.isArray(ex.permittedIds)?[...new Set(ex.permittedIds.map(Number).filter(id=>Number.isInteger(id)&&id>0))].slice(0,200):[],
        minHpPct:safeInteger(ex.minHpPct,60,30,90),
        everyMonths:safeInteger(ex.everyMonths,5,3,12),
        realmId:typeof ex.realmId==='string'&&SECRET_REALMS.some(r=>r.id===ex.realmId)?ex.realmId:'',
        lastMonth:safeInteger(ex.lastMonth,-100,-100,12000000),total:safeInteger(ex.total,0,0,100000),
        victories:safeInteger(ex.victories,0,0,100000),deaths:safeInteger(ex.deaths,0,0,100000)};
      const pol=data.s3f4Politics && typeof data.s3f4Politics==='object'?data.s3f4Politics:{};
      state.s3f4Politics={lastMonth:safeInteger(pol.lastMonth,-100,-100,12000000),
        nextType:safeInteger(pol.nextType,0,0,2),
        marks:pol.marks&&typeof pol.marks==='object'&&!Array.isArray(pol.marks)?pol.marks:{},
        feud:safeInteger(pol.feud,0,0,6),alliance:safeInteger(pol.alliance,0,0,6),school:safeInteger(pol.school,0,0,6),
        recorded:Array.isArray(pol.recorded)?pol.recorded.slice(-30).map(x=>String(x).slice(0,200)):[]};
      // 3E.2: Hàng chờ Thiên Cơ, chỉ lưu dữ liệu thuần JSON để khôi phục save.
      state.destinySeen = {};
      if(data.destinySeen && typeof data.destinySeen==='object' && !Array.isArray(data.destinySeen)){
        for(const [key,value] of Object.entries(data.destinySeen).slice(-2500)){
          if(/^((trial|career|mentor|education|transmission|legacy|bloodline):\d+|story:[a-z_]+:\d+)$/.test(key) && value===true) state.destinySeen[key]=true;
        }
      }
      state.destinyQueue = Array.isArray(data.destinyQueue) ? data.destinyQueue.slice(0,20).filter(e=>
        e && ['trial','career','story','mentor','education','transmission','legacy','bloodline'].includes(e.kind) && Number.isInteger(e.memberId) && e.memberId>0 &&
        (e.kind!=='story' || S3D_STORIES.some(st=>st.id===e.storyId))
      ).map(e=>({kind:e.kind,memberId:e.memberId,storyId:e.kind==='story'?e.storyId:null})) : [];
      state.destinyLastMonth = safeInteger(data.destinyLastMonth,-100,-100,12000000);
      state.marriageNotices = data.marriageNotices && typeof data.marriageNotices === "object" && !Array.isArray(data.marriageNotices) ? data.marriageNotices : {};

      const seenIds = new Set();
      state.members = data.members.map(raw => {
        if (!raw || typeof raw !== "object") return null;
        const id = safeInteger(raw.id, -1, 1, Number.MAX_SAFE_INTEGER);
        if (id < 1 || seenIds.has(id)) return null;
        seenIds.add(id);
        const realmIdx = safeInteger(raw.realmIdx, 0, 0, REALMS.length - 1);
        const rootId = raw.spiritRoot?.id || raw.spiritRootId;
        const root = SPIRIT_ROOTS.find(item => item.id === rootId) || SPIRIT_ROOTS[0];
        const role = ["Tộc Trưởng", "Tộc Nhân", "Trưởng Lão"].includes(raw.role) ? raw.role : "Tộc Nhân";
        return {
          id,
          name: normalizePlayerName(raw.name, `Tộc nhân ${id}`),
          gender: raw.gender === "female" ? "female" : "male",
          age: safeInteger(raw.age, 16, 0, GAME_CONFIG.maxCharacterAge),
          generation: safeInteger(raw.generation, 1, 1, 1000),
          realmIdx,
          xp: safeNumber(raw.xp, 0, 0, REALMS[realmIdx].maxXp),
          innerDemon: safeNumber(raw.innerDemon, 0, 0, 100),
          spiritRoot: root,
          parentId: safeOptionalId(raw.parentId),
          spouseId: safeOptionalId(raw.spouseId),
          biologicalFatherId: safeOptionalId(raw.biologicalFatherId),
          biologicalMotherId: safeOptionalId(raw.biologicalMotherId),
          adoptiveParentId: safeOptionalId(raw.adoptiveParentId),
          lineageType: ["birth", "adopted", "unknown", "legacy_unknown"].includes(raw.lineageType)
            ? raw.lineageType : (raw.parentId != null ? "legacy_unknown" : "unknown"),
          isFounder: Boolean(raw.isFounder),
          isMarriedIn: Boolean(raw.isMarriedIn),
          alive: raw.alive !== false,
          birthYear: safeInteger(raw.birthYear, Math.max(1, state.year - safeInteger(raw.age, 16, 0, GAME_CONFIG.maxCharacterAge)), 1, 999999),
          deathYear: raw.deathYear == null ? null : safeInteger(raw.deathYear, state.year, 1, 999999),
          role,
          alchemyLevel: safeInteger(raw.alchemyLevel, 0, 0, 5),
          craftPath: S3E_CRAFTS.some(c => c.id === raw.craftPath) ? raw.craftPath : "none",
          craftXp: safeInteger(raw.craftXp, 0, 0, 2000),
          craftLastSwitchYear: safeInteger(raw.craftLastSwitchYear, -1, -1, 999999),
          s3e1LastWorkMonth: safeInteger(raw.s3e1LastWorkMonth, -1, -1, 12000000),
          s3e1ForgeCount: safeInteger(raw.s3e1ForgeCount, 0, 0, 4),
          s3e1WardCount: safeInteger(raw.s3e1WardCount, 0, 0, 4),
          s3e1WorkCount: safeInteger(raw.s3e1WorkCount, 0, 0, 100000),
          elderSatisfaction: safeNumber(raw.elderSatisfaction, 80, 0, 100),
          mentorId: safeOptionalId(raw.mentorId),
          careGuardianId: safeOptionalId(raw.careGuardianId),
          familyBond: safeInteger(raw.familyBond, 40, 0, 100),
          familyTrial: raw.familyTrial && typeof raw.familyTrial === 'object' && ['trust','discipline','explore'].includes(raw.familyTrial.choice)
            ? {choice:raw.familyTrial.choice,year:safeInteger(raw.familyTrial.year,state.year,1,999999),
              mentorId:safeOptionalId(raw.familyTrial.mentorId),resolved:Boolean(raw.familyTrial.resolved)} : null,
          inheritedTeaching: Boolean(raw.inheritedTeaching),
          legacyPath: ['dao','bao','nghiep'].includes(raw.legacyPath) ? raw.legacyPath : 'none',
          legacyReceivedYear: safeInteger(raw.legacyReceivedYear,-1,-1,999999),
           bloodlineInheritance: raw.bloodlineInheritance && typeof raw.bloodlineInheritance==='object' &&
             ['dao','nghe','ho'].includes(raw.bloodlineInheritance.path) &&
             Number.isInteger(raw.bloodlineInheritance.ancestorId) && raw.bloodlineInheritance.ancestorId>0 ? {
               path:raw.bloodlineInheritance.path,
               ancestorId:safeInteger(raw.bloodlineInheritance.ancestorId,1,1,999999999),
               year:safeInteger(raw.bloodlineInheritance.year,state.year,1,999999)
             } : null,
          educationPath: ["none","dao","dan","kiem"].includes(raw.educationPath) ? raw.educationPath : "none",
          educationLessons: safeInteger(raw.educationLessons, 0, 0, 6),
          lastEducationYear: safeInteger(raw.lastEducationYear, -1, -1, 999999),
          maritalHarmony: raw.maritalHarmony == null ? null : safeInteger(raw.maritalHarmony, 50, 0, 100),
          bonusHp: safeNumber(raw.bonusHp, 0, 0, GAME_CONFIG.maxResource),
          bonusAtk: safeNumber(raw.bonusAtk, 0, 0, GAME_CONFIG.maxResource),
          bonusDef: safeNumber(raw.bonusDef, 0, 0, GAME_CONFIG.maxResource),
          bonusSpd: safeNumber(raw.bonusSpd, 0, 0, GAME_CONFIG.maxResource),
          lifesteal: safeNumber(raw.lifesteal, 0, 0, 1000),
          dodge: safeNumber(raw.dodge, 0, 0, 1000),
          crit: safeNumber(raw.crit, 0, 0, 1000),
          combo: safeNumber(raw.combo, 0, 0, 1000),
          avatarSeed: safeInteger(raw.avatarSeed, 0, 0, 999999),
          appearance: normalizeAppearance(raw.appearance, {
            id, name: raw.name, gender: raw.gender,
            age: safeInteger(raw.age, 16, 0, GAME_CONFIG.maxCharacterAge),
            realmIdx, avatarSeed: safeInteger(raw.avatarSeed, 0, 0, 999999)
          })
        };
      }).filter(Boolean);

      const memberIds = new Set(state.members.map(member => member.id));
      state.members.forEach(member => {
        if (member.parentId === member.id || (member.parentId != null && !memberIds.has(member.parentId))) member.parentId = null;
        if (member.spouseId === member.id || (member.spouseId != null && !memberIds.has(member.spouseId))) member.spouseId = null;
        for (const field of ["biologicalFatherId", "biologicalMotherId", "adoptiveParentId", "mentorId", "careGuardianId"]) {
          if (member[field] === member.id || (member[field] != null && !memberIds.has(member[field]))) member[field] = null;
        }
        if (member.biologicalFatherId != null && member.biologicalFatherId === member.biologicalMotherId) {
          member.biologicalMotherId = null;
        }
        // Save cũ không có lịch sử hôn phối: giữ quan hệ là chưa xác định,
        // tuyệt đối không suy luận cha mẹ ruột qua spouseId hiện tại.
        if (member.lineageType === "birth" && !member.biologicalFatherId && !member.biologicalMotherId) {
          member.lineageType = "legacy_unknown";
        }
      });
      state.nextMemberId = Math.max(state.nextMemberId, ...state.members.map(member => member.id + 1), 1);
      const savedLeader = state.members.find(member =>
        member.id === safeOptionalId(data.clanLeaderId) && member.alive
      );
      const roleLeader = state.members.find(member => member.alive && member.role === "Tộc Trưởng");
      const founderLeader = state.members.find(member => member.alive && member.isFounder);
      state.clanLeaderId = (savedLeader || roleLeader || founderLeader)?.id || null;
      state.members.forEach(member => {
        if (member.role === "Tộc Trưởng" && member.id !== state.clanLeaderId) member.role = "Tộc Nhân";
      });
      const leaderMember = state.members.find(member => member.id === state.clanLeaderId);
      if (leaderMember) leaderMember.role = "Tộc Trưởng";
      const savedHeir = state.members.find(member =>
        member.id === safeOptionalId(data.heirId) &&
        member.alive && member.age >= GAME_CONFIG.minMarriageAge && !member.isMarriedIn
      );
      state.heirId = savedHeir && savedHeir.id !== state.clanLeaderId ? savedHeir.id : null;

      const rawHerbs = data.herbs && typeof data.herbs === "object" ? data.herbs : {};
      const rawPills = data.pills && typeof data.pills === "object" ? data.pills : {};
      Object.keys(state.herbs).forEach(id => state.herbs[id] = safeInteger(rawHerbs[id], state.herbs[id], 0, GAME_CONFIG.maxResource));
      Object.keys(state.pills).forEach(id => state.pills[id] = safeInteger(rawPills[id], state.pills[id], 0, GAME_CONFIG.maxResource));

      const rawTreasures = Array.isArray(data.treasures) ? data.treasures : [];
      state.treasures = TREASURES_DB.map(base => {
        const saved = rawTreasures.find(item => item && item.id === base.id) || {};
        return {
          ...JSON.parse(JSON.stringify(base)),
          owned: Boolean(saved.owned ?? base.owned),
          level: safeInteger(saved.level, base.level, 0, 1000),
          shards: safeInteger(saved.shards, base.shards, 0, GAME_CONFIG.maxResource)
        };
      });

      const rawEstates = Array.isArray(data.estates) ? data.estates : [];
      state.estates = ESTATES_INIT.map(base => {
        const saved = rawEstates.find(item => item && item.id === base.id) || {};
        return {
          ...base,
          level: safeInteger(saved.level, base.level, 0, 30),
          guardianId: safeOptionalId(saved.guardianId)
        };
      });

      const rawFactions = Array.isArray(data.factions) ? data.factions : [];
      state.factions = state.factions.map(base => {
        const saved = rawFactions.find(item => item && item.id === base.id) || {};
        return {
          ...base,
          relation: safeNumber(saved.relation, base.relation, 0, 100),
          power: safeNumber(saved.power, base.power, 0, GAME_CONFIG.maxResource)
        };
      });

      state.outerDisciples = Array.isArray(data.outerDisciples)
        ? data.outerDisciples.slice(0, 1000).filter(item => item && typeof item === "object").map((item, index) => ({
            id: safeNumber(item.id, index + 1, 1, Number.MAX_SAFE_INTEGER),
            name: normalizePlayerName(item.name, `Đệ tử ${index + 1}`),
            tier: ["Phàm Cấp", "Trung Phẩm", "Thượng Phẩm", "Kỳ Tài"].includes(item.tier) ? item.tier : "Phàm Cấp",
            proficiency: safeNumber(item.proficiency, 0, 0, 100)
          }))
        : [];

      state.historyLog = Array.isArray(data.historyLog)
        ? data.historyLog.slice(-GAME_CONFIG.maxHistoryEntries).map(line => String(line).slice(0, 2000))
        : [];
      state.s3aChronicle = Array.isArray(data.s3aChronicle) ? data.s3aChronicle.slice(-200).filter(e=>e&&typeof e==='object').map(e=>({
        year:safeInteger(e.year,state.year,1,999999),month:safeInteger(e.month,1,1,12),
        memberId:safeInteger(e.memberId,0,0,99999999),name:String(e.name||'').slice(0,32),
        title:String(e.title||'').slice(0,80),success:Boolean(e.success),result:String(e.result||'').slice(0,320)
      })) : [];
      state.s3aSeen = {};
      for(const entry of state.s3aChronicle){
        const t=S3A_STORIES.find(st=>st.title===entry.title);
        if(t)state.s3aSeen[s3aOneTimeKey(t.id,entry.memberId)]=true;
      }
      // Sprint 3D: Phục hồi tuyến nhiều hồi từ save cùng phiên bản.
      state.s3dChains = Array.isArray(data.s3dChains) ? data.s3dChains.slice(-500).filter(c=>c&&S3D_STORIES.some(s=>s.id===c.storyId)&&state.members.some(m=>m.id===c.memberId)).map(c=>({
        id:s3dChainId(c.storyId,c.memberId),storyId:c.storyId,memberId:c.memberId,
        stage:safeInteger(c.stage,1,1,4),status:['active','complete','unfinished'].includes(c.status)?c.status:'unfinished',
        due:c.due==null?null:safeInteger(c.due,getMonthIndex(state),0,Number.MAX_SAFE_INTEGER),
        decisions:Array.isArray(c.decisions)?c.decisions.slice(0,3).filter(d=>d&&[1,2,3].includes(d.stage)).map(d=>({stage:d.stage,choice:d.choice==='mao_hiem'?'mao_hiem':'than_trong',success:!!d.success,year:safeInteger(d.year,state.year,1,999999),month:safeInteger(d.month,1,1,12)})):[]
      })) : [];
      state.s3dChronicle = Array.isArray(data.s3dChronicle)?data.s3dChronicle.slice(-180).filter(e=>e&&S3D_STORIES.some(s=>s.id===e.storyId)).map(e=>({
        storyId:e.storyId,memberId:safeInteger(e.memberId,0,0,99999999),name:String(e.name||'').slice(0,32),stage:safeInteger(e.stage,1,1,3),year:safeInteger(e.year,state.year,1,999999),month:safeInteger(e.month,1,1,12),result:String(e.result||'').slice(0,250)
      })) : [];
      state.lastAdventureMonthIndex = safeInteger(data.lastAdventureMonthIndex, 0, 0, Number.MAX_SAFE_INTEGER);
      state.lastAdventureById = {};
      const savedAdventureCooldowns = data.lastAdventureById && typeof data.lastAdventureById === "object"
        ? data.lastAdventureById
        : {};
      ADVENTURE_TEMPLATES.forEach(template => {
        state.lastAdventureById[template.id] = safeInteger(savedAdventureCooldowns[template.id], 0, 0, Number.MAX_SAFE_INTEGER);
      });

      const rawSquad = Array.isArray(data.squadIds) ? data.squadIds : [];
      state.squadIds = [...new Set(rawSquad.map(safeOptionalId).filter(id => id != null))]
        .filter(id => {
          const member = state.members.find(item => item.id === id);
          return member && member.alive;
        }).slice(0, GAME_CONFIG.maxSquadSize);
      const activeId = safeOptionalId(data.activeCultivatorId);
      const active = state.members.find(member => member.id === activeId);
      state.activeCultivatorId = active && active.alive
        ? active.id
        : (state.members.find(member => member.alive)?.id || null);
      if (!state.squadIds.length && state.activeCultivatorId != null) state.squadIds = [state.activeCultivatorId];

      const aliveCount = state.members.filter(member => member.alive).length;
      while (aliveCount > 6 * Math.pow(2, state.abodeLevel - 1) && state.abodeLevel < GAME_CONFIG.maxAbodeLevel) {
        state.abodeLevel++;
      }
      if (aliveCount > 6 * Math.pow(2, state.abodeLevel - 1)) {
        throw new Error("Số tộc nhân vượt giới hạn sức chứa tối đa; không thể nhập mà không làm mất dữ liệu.");
      }

      const pendingRaw = data.pendingAdventure || null;
      state.pendingAdventure = normalizePendingAdventure(pendingRaw, state);
      if (state.pendingAdventure) {
        const eventMonth = state.pendingAdventure.createdAtMonthIndex;
        state.lastAdventureMonthIndex = Math.max(state.lastAdventureMonthIndex, eventMonth);
        state.lastAdventureById[state.pendingAdventure.eventId] = Math.max(
          state.lastAdventureById[state.pendingAdventure.eventId] || 0,
          eventMonth
        );
      }
      if (pendingRaw && !state.pendingAdventure) {
        state.historyLog.push("Một kỳ ngộ đang chờ không còn hợp lệ sau khi tải save; sự kiện đã được đóng an toàn.");
      }
      state.clanExtinct = aliveCount === 0 && state.started;
      if (state.clanExtinct) state.paused = true;
      clampGameStateResources(state);
      return state;
    }

    function serializeGameState() {
      const snapshot = JSON.parse(JSON.stringify(gameState));
      snapshot.pendingAdventure = normalizePendingAdventure(snapshot.pendingAdventure);
      delete snapshot.battleState;
      return {
        schemaVersion: GAME_CONFIG.saveSchemaVersion,
        savedAt: new Date().toISOString(),
        game: snapshot
      };
    }

    function deserializeGameState(rawText) {
      return validateAndMigrateSave(JSON.parse(rawText));
    }

    function saveGameToLocal(options = {}) {
      const silent = Boolean(options.silent);
      try {
        if (battleState) suspendBattleForSave();
        clampGameStateResources();
        const payload = serializeGameState();
        const json = JSON.stringify(payload);
        if (new Blob([json]).size > GAME_CONFIG.maxSaveBytes) {
          throw new Error("Dung lượng save vượt quá giới hạn 5 MB.");
        }
        const previous = options.backupRaw ||
          localStorage.getItem(GAME_CONFIG.saveKey) ||
          localStorage.getItem(GAME_CONFIG.legacySaveKey);
        if (previous) {
          try { localStorage.setItem(GAME_CONFIG.backupKey, previous); } catch (_) {}
        }
        localStorage.setItem(GAME_CONFIG.saveKey, json);
        savedProgressAvailable = Boolean(gameState.started);
        gameIsDirty = false;
        if (autosaveDebounceTimer) clearTimeout(autosaveDebounceTimer);
        autosaveDebounceTimer = null;
        loadedSaveSource = "local";
        if (options.closeModal !== false) closeGenericModal();
        if (!silent) showToast("💾 Đã lưu tiến trình gia tộc.");
        return true;
      } catch (error) {
        console.error("Save failed:", error);
        const message = `Không thể lưu: ${error.message || "Trình duyệt từ chối lưu (quota/private mode)."}`;
        if (!silent) showToast(message);
        else setTicker(`⚠️ ${message}`);
        return false;
      }
    }

    function loadGameFromLocal() {
      let foundAny = false;
      let loadError = "";
      const keys = [GAME_CONFIG.saveKey, GAME_CONFIG.legacySaveKey, GAME_CONFIG.backupKey];
      try {
        foundAny = keys.some(key => Boolean(localStorage.getItem(key)));
        const candidates = [
          [GAME_CONFIG.saveKey, "local"],
          [GAME_CONFIG.legacySaveKey, "legacy"],
          [GAME_CONFIG.backupKey, "backup"]
        ];
        for (const [key, source] of candidates) {
          const raw = localStorage.getItem(key);
          if (!raw) continue;
          try {
            const parsed = JSON.parse(raw);
            const restored = validateAndMigrateSave(parsed);
            gameState = restored;
            rebuildMemberIndex();
            invalidateAggregateBonuses();
            gameIsDirty = false;
            savedProgressAvailable = Boolean(restored.started);
            loadedSaveSource = source;
            let warning = "";
            if (source === "legacy") {
              try { localStorage.setItem(GAME_CONFIG.backupKey, raw); } catch (_) {}
              const migrated = saveGameToLocal({ silent: true, closeModal: false, backupRaw: raw });
              loadedSaveSource = migrated ? "migrated-v5" : "migrated-v5-memory";
              if (!migrated) warning = "Đã khôi phục save v5 trong phiên này nhưng chưa ghi được bản v2; file v5 gốc vẫn được giữ.";
            }
            return { loaded: true, foundAny: true, error: "", warning };
          } catch (error) {
            loadError = error.message || "Không đọc được save.";
            if (String(loadError).includes("phiên bản mới hơn")) break;
          }
        }
      } catch (error) {
        loadError = "Trình duyệt không cho phép truy cập localStorage (có thể do chế độ riêng tư).";
      }
      savedProgressAvailable = foundAny;
      loadedSaveSource = null;
      return { loaded: false, foundAny, error: loadError };
    }

    function startAutosaveLoop() {
      if (autosaveTimer) clearInterval(autosaveTimer);
      autosaveTimer = setInterval(() => {
        if (gameState.started && gameIsDirty) saveGameToLocal({ silent: true, closeModal: false });
      }, GAME_CONFIG.autosaveIntervalMs);
    }

    function stopGameTimers() {
      if (timeLoopTimer) clearInterval(timeLoopTimer);
      if (battleAutoTimer) clearInterval(battleAutoTimer);
      if (autosaveTimer) clearInterval(autosaveTimer);
      if (autosaveDebounceTimer) clearTimeout(autosaveDebounceTimer);
      timeLoopTimer = null;
      battleAutoTimer = null;
      autosaveTimer = null;
      autosaveDebounceTimer = null;
      battleState = null;
      battleActionLock = false;
    }

    function suspendBattleForSave() {
      if (!battleState) return;
      gameState.teamHp = safeNumber(battleState.heroHp, gameState.teamHp, 1, GAME_CONFIG.maxResource);
      stopBattleCleanup();
      gameState.paused = true;
      setTicker("⚔️ Trận Bí Cảnh đã tạm kết thúc an toàn để lưu tiến trình; không nhận hoặc mất thưởng trận.");
    }

    function exportSaveFile() {
      try {
        let payload;
        if (!gameState.started && savedProgressAvailable) {
          payload = localStorage.getItem(GAME_CONFIG.saveKey) ||
            localStorage.getItem(GAME_CONFIG.legacySaveKey) ||
            localStorage.getItem(GAME_CONFIG.backupKey);
        }
        if (!payload) payload = JSON.stringify(serializeGameState(), null, 2);
        const blob = new Blob([payload], { type: "application/json;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        const stamp = new Date().toISOString().replace(/[:.]/g, "-");
        link.href = url;
        link.download = `tien-dao-gia-toc-save-${stamp}.json`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        showToast("📤 Đã xuất file save JSON.");
      } catch (error) {
        showToast(`Không thể xuất save: ${error.message || "Lỗi dữ liệu."}`);
      }
    }

    async function importSaveFromInput(input) {
      const file = input?.files?.[0];
      if (!file) return;
      try {
        if (file.size > GAME_CONFIG.maxSaveBytes) throw new Error("File vượt quá giới hạn 5 MB.");
        const raw = await file.text();
        const importedState = deserializeGameState(raw);
        if (!importedState.started) throw new Error("File chưa có tiến trình gia tộc để khôi phục.");
        const oldRaw = localStorage.getItem(GAME_CONFIG.saveKey) || localStorage.getItem(GAME_CONFIG.legacySaveKey);
        if (oldRaw) {
          try { localStorage.setItem(GAME_CONFIG.backupKey, oldRaw); } catch (_) {}
        }
        stopGameTimers();
        gameState = importedState;
        marriageModalContext = null;
        adoptCandidateContext = null;
        rebuildMemberIndex();
        invalidateAggregateBonuses();
        gameIsDirty = true;
        savedProgressAvailable = Boolean(gameState.started);
        const persisted = saveGameToLocal({ silent: true, closeModal: false });
        closeGenericModal();
        document.getElementById("startupModal")?.classList.add("hidden");
        if (gameState.started) activateLoadedGame();
        showToast(persisted
          ? "📥 Đã nhập, kiểm tra và lưu save thành công."
          : "📥 Đã nhập vào phiên hiện tại nhưng trình duyệt không lưu được. Hãy xuất file JSON để giữ bản sao.");
      } catch (error) {
        showToast(`Không thể nhập save: ${error.message || "File không hợp lệ."}`);
      } finally {
        if (input) input.value = "";
      }
    }

    function confirmDeleteProgress() {
      openDecisionModal({
        title: '🗑️ Xóa Tiến Trình',
        message: 'Xóa toàn bộ tiến trình đã lưu và bản sao lưu? Thao tác này không thể hoàn tác.',
        confirmText: 'Xóa',
        cancelText: 'Giữ lại',
        confirmClass: 'bg-rose-700 text-white',
        onConfirm: () => {
          try {
            [GAME_CONFIG.saveKey, GAME_CONFIG.legacySaveKey, GAME_CONFIG.backupKey].forEach(key => localStorage.removeItem(key));
            stopGameTimers();
            gameState = createInitialGameState();
            marriageModalContext = null;
            adoptCandidateContext = null;
            rebuildMemberIndex();
            invalidateAggregateBonuses();
            gameIsDirty = false;
            savedProgressAvailable = false;
            allowNewGameOverwrite = true;
            document.getElementById("genericModal")?.classList.add("hidden");
            document.getElementById("startupModal")?.classList.remove("hidden");
            showStartupCreatePanel();
            renderStartupModalOptions();
            showToast("Đã xóa tiến trình và các bản save.");
          } catch (error) {
            showToast("Không thể xóa save do trình duyệt chặn quyền truy cập.");
          }
        }
      });
    }

    function showStartupCreatePanel() {
      document.getElementById("startupSaveMenu")?.classList.add("hidden");
      document.getElementById("startupCreatePanel")?.classList.remove("hidden");
      document.getElementById("btnBackStartupMenu")?.classList.toggle("hidden", !savedProgressAvailable);
    }

    function showStartupSaveMenu(statusText = "") {
      document.getElementById("startupCreatePanel")?.classList.add("hidden");
      document.getElementById("startupSaveMenu")?.classList.remove("hidden");
      document.getElementById("btnBackStartupMenu")?.classList.add("hidden");
      const status = document.getElementById("startupSaveStatus");
      if (status) status.textContent = statusText || (savedProgressAvailable ? "Đã tìm thấy tiến trình lưu trong trình duyệt." : "Chưa có save hợp lệ. Bạn có thể nhập file hoặc tạo mới.");
      const continueBtn = document.getElementById("btnContinueSave");
      if (continueBtn) continueBtn.disabled = !gameState.started;
    }

    function beginNewClanFlow() {
      const proceed = () => {
        allowNewGameOverwrite = true;
        showStartupCreatePanel();
        renderStartupModalOptions();
      };
      if (savedProgressAvailable || gameState.started) {
        openDecisionModal({
          title: '📦 Bản Sao Lưu Trước Khi Khai Tộc',
          message: 'Bạn đang có tiến trình. Có muốn xuất một bản sao lưu JSON trước khi tạo gia tộc mới không?',
          confirmText: 'Xuất rồi tiếp tục',
          cancelText: 'Bỏ qua',
          onConfirm: () => {
            exportSaveFile();
            openDecisionModal({
              title: '🌱 Khai Tộc Mới',
              message: 'Xác nhận tạo gia tộc mới? Tiến trình hiện tại sẽ được thay thế trong ô lưu chính; bản sao lưu gần nhất sẽ được giữ nếu trình duyệt cho phép.',
              confirmText: 'Tạo mới',
              cancelText: 'Quay lại',
              confirmClass: 'bg-emerald-700 text-white',
              onConfirm: proceed
            });
          },
          onCancel: () => {
            openDecisionModal({
              title: '🌱 Khai Tộc Mới',
              message: 'Xác nhận tạo gia tộc mới? Tiến trình hiện tại sẽ được thay thế trong ô lưu chính; bản sao lưu gần nhất sẽ được giữ nếu trình duyệt cho phép.',
              confirmText: 'Tạo mới',
              cancelText: 'Quay lại',
              confirmClass: 'bg-emerald-700 text-white',
              onConfirm: proceed
            });
          }
        });
        return false;
      }
      proceed();
      return true;
    }

    function continueSavedGame() {
      if (!gameState.started) return showToast("Không có save hợp lệ để tiếp tục.");
      document.getElementById("startupModal")?.classList.add("hidden");
      activateLoadedGame();
    }

    function activateLoadedGame() {
      allowNewGameOverwrite = false;
      rebuildMemberIndex();
      invalidateAggregateBonuses();
      document.getElementById("startupModal")?.classList.add("hidden");
      gameState.paused = Boolean(gameState.paused);
      updateAllUI();
      startContinuousTimeLoop();
      startAutosaveLoop();
      if (gameState.pendingAdventure) renderAdventureModal();
      if (gameState.clanExtinct) showClanExtinctionModal();
    }

    // =========================================================================
    // 5. HÀM KHỞI TẠO & TÍNH TOÁN 8 CHỈ SỐ PHÂN HÓA TỪ NHỎ
    // =========================================================================
    function generateTwoCharName(gender, fixedSurname = null) {
      const s = fixedSurname || SURNAMES[Math.floor(Math.random() * SURNAMES.length)];
      const pool = gender === "male" ? MALE_NAMES : FEMALE_NAMES;
      const g = pool[Math.floor(Math.random() * pool.length)];
      return `${s} ${g}`;
    }

    function rollSpiritRoot() {
      const r = Math.random() * 100;
      let acc = 0;
      for (const root of SPIRIT_ROOTS) {
        acc += root.rate;
        if (r <= acc) return root;
      }
      return SPIRIT_ROOTS[0];
    }

    // =========================================================================
    // SPRINT 2D — ADN NGOẠI HÌNH TÁCH LỚP (PHIÊN BẢN THỬ NGHIỆM)
    // Không tác động cơ chế linh căn, huyết mạch, chiến lực hoặc tài nguyên.
    // Tương thích ngược: Save schema vẫn là 2; các thuộc tính mới đều tùy chọn.
    // =========================================================================
    const APPEARANCE_OPTIONS = Object.freeze({
      faces: ["de_thuong", "lanh_lung", "hien_lanh", "nghiem_nghi"],
      hairstyles: ["bui_cao", "toc_dai", "toc_ngan", "buoc_hai_ben"],
      hairColors: ["#232B2B", "#4B2C28", "#554337", "#283E45"],
      eyeColors: ["#1E3A5F", "#34544C", "#5B4433", "#6B4D7D"],
      outfits: ["jade", "white", "violet", "bronze"],
      accessories: ["kiem", "ho_lo", "quat", "ngoc_boi", "tram_cai"]
    });

    const APPEARANCE_ROBES = Object.freeze({
      jade: { light: "#e3f4ed", main: "#80b5a5", dark: "#326e60" },
      white: { light: "#fffdf0", main: "#d8e7df", dark: "#819f98" },
      violet: { light: "#f5edf8", main: "#baa6d0", dark: "#78608c" },
      bronze: { light: "#fff1d1", main: "#d9b17f", dark: "#936840" }
    });

    // Hash ổn định giúp tạo ADN cho save cũ mà không gọi Math.random khi tải.
    function stableAppearanceSeed(m) {
      const raw = `${m.id || 0}|${m.name || ""}|${m.gender || ""}|${m.avatarSeed || 0}`;
      let hash = 2166136261;
      for (let i = 0; i < raw.length; i++) {
        hash ^= raw.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
      }
      return hash >>> 0;
    }

    function chooseAppearance(seed, choices, shift) {
      return choices[(seed + Math.imul(shift + 1, 2654435761) >>> 0) % choices.length];
    }

    function isVisuallyElder(age, realmIdx) {
      if (age < 50) return false;
      const lifespan = 75 + Math.max(0, realmIdx) * 18;
      return realmIdx < 10 || age >= Math.ceil(lifespan * 0.8);
    }

    function normalizeAppearance(raw, m) {
      const seed = stableAppearanceSeed(m);
      const data = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
      const select = (key, choices, shift) => choices.includes(data[key])
        ? data[key] : chooseAppearance(seed, choices, shift);
      return {
        version: 1,
        variantSeed: safeInteger(data.variantSeed, seed % 1000000, 0, 999999),
        bodyIndex: safeInteger(data.bodyIndex, seed % 5 + 1, 1, 5),
        faceId: select("faceId", APPEARANCE_OPTIONS.faces, 1),
        hairId: select("hairId", APPEARANCE_OPTIONS.hairstyles, 2),
        hairColor: select("hairColor", APPEARANCE_OPTIONS.hairColors, 3),
        eyeColor: select("eyeColor", APPEARANCE_OPTIONS.eyeColors, 4),
        outfitColor: select("outfitColor", APPEARANCE_OPTIONS.outfits, 5),
        accessoryId: select("accessoryId", APPEARANCE_OPTIONS.accessories, 6),
        // Chỉ là lựa chọn hình ảnh, không được di truyền cho con.
        visualOverride: data.visualOverride && typeof data.visualOverride === "object" && !Array.isArray(data.visualOverride)
          ? {
              hair: typeof data.visualOverride.hair === 'string' ? data.visualOverride.hair : 'bui_cao',
              eye: ['dark','jade'].includes(data.visualOverride.eye) ? data.visualOverride.eye : 'dark',
              robe: ['jade','white'].includes(data.visualOverride.robe) ? data.visualOverride.robe : 'jade',
              hairColor: Object.prototype.hasOwnProperty.call(S2G_HAIR, data.visualOverride.hairColor) ? data.visualOverride.hairColor : undefined,
              eyeColor: Object.prototype.hasOwnProperty.call(S2G_EYES, data.visualOverride.eyeColor) ? data.visualOverride.eyeColor : undefined,
              robeColor: Object.prototype.hasOwnProperty.call(S2G_ROBE, data.visualOverride.robeColor) ? data.visualOverride.robeColor : undefined,
              style: ['ornate','simple'].includes(data.visualOverride.style) ? data.visualOverride.style : undefined
            }
          : null,
        visualTraits: data.visualTraits && typeof data.visualTraits === "object" && !Array.isArray(data.visualTraits)
          ? {
              hairColor: Object.prototype.hasOwnProperty.call(S2G_HAIR,data.visualTraits.hairColor) ? data.visualTraits.hairColor : undefined,
              eyeColor: Object.prototype.hasOwnProperty.call(S2G_EYES,data.visualTraits.eyeColor) ? data.visualTraits.eyeColor : undefined,
              robeColor: Object.prototype.hasOwnProperty.call(S2G_ROBE,data.visualTraits.robeColor) ? data.visualTraits.robeColor : undefined
            } : null,
        elderReached: Boolean(data.elderReached) || isVisuallyElder(m.age, m.realmIdx)
      };
    }

    function createRandomAppearance(member) {
      // Dùng avatarSeed vốn có để không tiêu thụ thêm RNG của gameplay.
      return normalizeAppearance(null, member);
    }

    function makeAppearanceRng(seed) {
      let value = seed >>> 0;
      return () => {
        value = (Math.imul(value, 1664525) + 1013904223) >>> 0;
        return value / 4294967296;
      };
    }

    // Chỉ kế thừa các nét bẩm sinh (tóc, mắt, khuôn mặt), KHÔNG truyền chỉ số.
    // RNG độc lập, không ảnh hưởng roll linh căn/sinh nở/kỳ ngộ của game gốc.
    function inheritAppearance(parent, spouse) {
      const a = normalizeAppearance(parent.appearance, parent);
      const b = normalizeAppearance(spouse.appearance, spouse);
      const next = makeAppearanceRng(
        (stableAppearanceSeed(parent) ^ Math.imul(stableAppearanceSeed(spouse), 31) ^
          Math.imul(gameState.nextMemberId, 1597334677) ^ Math.imul(gameState.year, 73)) >>> 0
      );
      const inherit = (key, options) => {
        const roll = next();
        return roll < 0.45 ? a[key] : (roll < 0.90 ? b[key] : options[Math.floor(next() * options.length)]);
      };
      return {
        hairId: inherit("hairId", APPEARANCE_OPTIONS.hairstyles),
        hairColor: inherit("hairColor", APPEARANCE_OPTIONS.hairColors),
        eyeColor: inherit("eyeColor", APPEARANCE_OPTIONS.eyeColors),
        faceId: inherit("faceId", APPEARANCE_OPTIONS.faces)
      };
    }

    function getVisualAgeGroup(member) {
      const age = Math.max(0, Number(member.age) || 0);
      if (age <= 12) return "child";
      if (age <= 17) return "teen";
      const elderReached = member.appearance && member.appearance.elderReached;
      return elderReached || isVisuallyElder(age, Number(member.realmIdx) || 0) ? "elder" : "adult";
    }

    // Các dạng SVG nhỏ dưới đây chỉ là nguyên mẫu thẩm mỹ: chưa thay tranh WebP chính.
    function renderAppearancePrototype(member, visualStage = null, size = 112) {
      const dna = normalizeAppearance(member.appearance, member);
      const stage = ["child", "teen", "adult", "elder"].includes(visualStage)
        ? visualStage : getVisualAgeGroup(member);
      const safeSize = safeInteger(size, 112, 42, 240);
      const old = stage === "elder";
      const hair = old ? "#b1bbb6" : dna.hairColor;
      const robe = APPEARANCE_ROBES[dna.outfitColor];
      const roleTrim = member.role === "Trưởng Lão" || member.role === "Tộc Trưởng" ? "#c09b51" : "#8cb6a2";
      const child = stage === "child";
      const teen = stage === "teen";
      const headY = child ? 54 : teen ? 49 : old ? 47 : 46;
      const rx = child ? 29 : teen ? 26 : 24;
      const ry = child ? 27 : teen ? 25 : 24;
      const shoulder = child ? 80 : teen ? 77 : old ? 78 : 76;
      const hem = child ? 119 : teen ? 127 : 132;
      const eyeY = headY + (child ? 5 : 4);
      const hairTop = headY - ry;
      const id = `ap-${member.id || 0}-${stage}-${safeSize}`;
      const ink = "#2b413c";
      const bang = dna.hairId === "toc_ngan"
        ? `<path d="M${60-rx-3} ${headY-7} Q45 ${headY-32} 63 ${hairTop-4} Q84 ${hairY(headY,ry)} ${60+rx+4} ${headY-7} L${60+rx-5} ${headY-8} Q73 ${headY-19} 66 ${headY-11} Q57 ${headY-16} 51 ${headY-8} Q42 ${headY-13} ${60-rx+5} ${headY-6}Z"/>`
        : `<path d="M${60-rx-4} ${headY-8} Q38 ${hairTop-12} 65 ${hairTop-7} Q86 ${hairTop-4} ${60+rx+5} ${headY-8} Q79 ${headY-19} 71 ${headY-12} Q65 ${headY-8} 60 ${headY-8} Q53 ${headY-17} 48 ${headY-8} Q40 ${headY-15} ${60-rx+4} ${headY-4}Z"/>`;
      const backHair = dna.hairId === "toc_dai"
        ? `<path d="M35 ${headY-10} Q25 ${headY+29} 29 ${shoulder+21} Q40 ${shoulder+17} 43 ${headY+10} M85 ${headY-11} Q95 ${headY+28} 93 ${shoulder+23} Q82 ${shoulder+19} 77 ${headY+14}" fill="${hair}" stroke="${ink}" stroke-width="2"/>`
        : dna.hairId === "buoc_hai_ben"
        ? `<circle cx="${60-rx-3}" cy="${headY-12}" r="11" fill="${hair}" stroke="${ink}" stroke-width="1.6"/><circle cx="${60+rx+3}" cy="${headY-12}" r="11" fill="${hair}" stroke="${ink}" stroke-width="1.6"/>`
        : dna.hairId === "bui_cao"
        ? `<path d="M52 ${hairTop+4} Q45 ${hairTop-25} 60 ${hairTop-26} Q76 ${hairTop-24} 68 ${hairTop+4}Z" fill="${hair}" stroke="${ink}" stroke-width="2"/>`
        : "";
      const eyeArc = dna.faceId === "lanh_lung" ? "-2" : "0";
      const pupil = (x) => `<ellipse cx="${x}" cy="${eyeY}" rx="4.4" ry="5.4" fill="#fffdf7" stroke="${ink}" stroke-width="1.4"/><ellipse cx="${x + (dna.faceId === "lanh_lung" ? 1 : 0)}" cy="${eyeY+0.7}" rx="2.4" ry="3.7" fill="${dna.eyeColor}"/><circle cx="${x-1}" cy="${eyeY-1.3}" r="1.1" fill="white"/>`;
      const smile = dna.faceId === "nghiem_nghi"
        ? `<path d="M55 ${headY+14} Q60 ${headY+13} 65 ${headY+14}"/>`
        : dna.faceId === "lanh_lung"
        ? `<path d="M56 ${headY+14} Q62 ${headY+13} 66 ${headY+11}"/>`
        : `<path d="M54 ${headY+13} Q60 ${headY+20} 66 ${headY+13}"/>`;
      const accessory = dna.accessoryId === "kiem"
        ? `<path d="M92 ${shoulder+3} L109 ${hem-15}" stroke="#a0a9aa" stroke-width="4" stroke-linecap="round"/><path d="M91 ${shoulder+2} l-6 -3 m6 3 l6 -4" stroke="#b08c4f" stroke-width="3"/>`
        : dna.accessoryId === "ho_lo"
        ? `<path d="M98 ${shoulder+13} q-10 7 -3 17 q7 6 13 -1 q7 -10 -3 -17Z" fill="#c18f52" stroke="#704e2b" stroke-width="1.5"/><path d="M99 ${shoulder+10}h7" stroke="#62452c" stroke-width="3"/>`
        : dna.accessoryId === "quat"
        ? `<path d="M95 ${shoulder+14} Q103 ${shoulder-7} 116 ${shoulder+5} L101 ${shoulder+23}Z" fill="#fff5dd" stroke="#ab915c" stroke-width="1.5"/>`
        : dna.accessoryId === "ngoc_boi"
        ? `<circle cx="60" cy="${shoulder+25}" r="5" fill="#7bc9b4" stroke="#b99a56" stroke-width="2"/>`
        : `<path d="M53 ${hairTop+2}L69 ${hairTop+2}" stroke="#cfac5c" stroke-width="2.7"/><circle cx="68" cy="${hairTop+2}" r="2.3" fill="#7fcdbf"/>`;
      return `<svg xmlns="http://www.w3.org/2000/svg" class="appearance-svg" viewBox="0 0 120 144" width="${safeSize}" height="${Math.round(safeSize*1.2)}" role="img" aria-label="Ngoại hình ${escapeHtml(member.name || "Tộc nhân")} - ${stage}">
        <defs>
          <linearGradient id="${id}-robe" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${robe.light}"/><stop offset="1" stop-color="${robe.main}"/></linearGradient>
          <radialGradient id="${id}-glow"><stop offset="0" stop-color="#fff5cf" stop-opacity=".85"/><stop offset="1" stop-color="#d6f3e6" stop-opacity="0"/></radialGradient>
        </defs>
        ${member.realmIdx >= 13 ? `<circle cx="60" cy="67" r="60" fill="url(#${id}-glow)"/>` : ""}
        <g stroke-linejoin="round" stroke-linecap="round">
          <g><!-- lớp 2: thân và chân -->
            <path d="M46 ${hem-9} L41 ${hem+8} L56 ${hem+8} L60 ${hem-6} M74 ${hem-9} L78 ${hem+8} L64 ${hem+8} L60 ${hem-6}" fill="#43595a" stroke="${ink}" stroke-width="2"/>
            <path d="M40 ${shoulder+9} Q21 ${shoulder+14} 26 ${shoulder+35} L40 ${shoulder+32} L50 ${shoulder+13} M80 ${shoulder+9} Q99 ${shoulder+14} 94 ${shoulder+35} L80 ${shoulder+32} L70 ${shoulder+13}" fill="${robe.light}" stroke="${ink}" stroke-width="2"/>
          </g>
          <g><!-- lớp 3: đạo bào, giữ màu theo ADN -->
            <path d="M42 ${shoulder-2} Q60 ${shoulder-13} 78 ${shoulder-2} L88 ${hem} Q60 ${hem+4} 32 ${hem} Z" fill="url(#${id}-robe)" stroke="${ink}" stroke-width="2.1"/>
            <path d="M50 ${shoulder-5} L60 ${shoulder+20} L69 ${shoulder-5} M60 ${shoulder+20} L60 ${hem-3}" fill="none" stroke="${robe.dark}" stroke-width="3"/>
            <path d="M37 ${shoulder+25} Q60 ${shoulder+30} 83 ${shoulder+25}" fill="none" stroke="${roleTrim}" stroke-width="4"/>
            <path d="M45 ${hem-12} Q60 ${hem-9} 76 ${hem-12}" fill="none" stroke="${robe.dark}" opacity=".4" stroke-width="1.3"/>
          </g>
          <g><!-- lớp 5 phần tóc phía sau -->${backHair}</g>
          <g><!-- lớp 4: khuôn mặt không đổi đặc trưng qua tuổi -->
            <ellipse cx="60" cy="${headY}" rx="${rx}" ry="${ry}" fill="#f8dfc3" stroke="${ink}" stroke-width="2.1"/>
            <path d="M45 ${eyeY-8} l10 ${eyeArc} M65 ${eyeY-8} l10 ${eyeArc}" fill="none" stroke="${ink}" stroke-width="1.5"/>
            ${pupil(49)}${pupil(71)}
            <path d="M60 ${eyeY+5} l-1 3 l2 0" fill="none" stroke="#ad7d68" stroke-width=".9"/>
            <g stroke="#985e61" fill="none" stroke-width="1.25">${smile}</g>
            ${old ? `<path d="M38 ${headY+13} q5 1 8 3 M74 ${headY+16} q4 -3 8 -3" fill="none" stroke="#b89e8f" stroke-width="1.2"/>` : ""}
          </g>
          <g><!-- lớp 5: tóc/tóc bạc tùy tuổi thị giác -->
            <path d="M${60-rx+4} ${headY-13} Q60 ${hairTop-12} ${60+rx-5} ${headY-12} Q${60+rx+6} ${headY-23} ${60+rx+1} ${headY-3} L${60+rx-3} ${headY-9} Q78 ${headY-17} 68 ${headY-8} Q61 ${headY-18} 52 ${headY-9} Q41 ${headY-17} ${60-rx+5} ${headY-4}Z" fill="${hair}" stroke="${ink}" stroke-width="2"/>
            <g fill="${hair}" stroke="${ink}" stroke-width="1.4">${bang}</g>
            ${old ? `<path d="M55 ${headY+17} q5 6 10 0" fill="none" stroke="#adb8b1" stroke-width="1.2"/>` : ""}
          </g>
          <g><!-- lớp 6: phụ kiện không phải gen -->${accessory}</g>
        </g>
      </svg>`;
    }

    function hairY(y, radius) { return y - radius - 10; }

    // =========================================================================
    // SPRINT 2E — six PNG/WebP art layers per painted master (transparent pixels)
    // Các kiểu tóc dùng hai master vẽ khác nhau; không giả nhận đã có base trọc
    // đồng nhất. Chọn màu áo/mắt là lớp ảnh riêng, ADN gốc không bị thay đổi.
    // =========================================================================
    // Sprint 2G: palettes only recolor specified painting masks; same master/face per gender.
    const S2G_HAIR = {"black":{name:"Huyền mặc",hex:"#23232c"},"brown":{name:"Nâu trầm",hex:"#47322f"},"blue":{name:"Lam mặc",hex:"#253e57"},"silver":{name:"Bạch ngân",hex:"#d7d9df"},"jade":{name:"Thanh mặc",hex:"#345e51"},"plum":{name:"Tử mặc",hex:"#513956"}};
    const S2G_ROBE = {"jade":{name:"Thanh ngọc",hex:"#78beb3"},"sky":{name:"Lam băng",hex:"#8ecde0"},"ivory":{name:"Bạch ngọc",hex:"#eee8d7"},"forest":{name:"Lục trúc",hex:"#4f8b64"},"lilac":{name:"Tử ngọc",hex:"#b7a0d5"},"peach":{name:"Đào phấn",hex:"#f1b6b5"},"navy":{name:"Huyền lam",hex:"#344b80"},"gold":{name:"Kim sa",hex:"#d7b46f"}};
    const S2G_EYES = {"dark":{name:"Mặc",hex:"#343239"},"jade":{name:"Ngọc",hex:"#5a9881"},"blue":{name:"Lam",hex:"#5b9ac8"},"violet":{name:"Tím",hex:"#9d79b3"},"amber":{name:"Hổ phách",hex:"#bb873e"}};
    const S2G_STYLE = {ornate:'Trâm / ngọc sức',simple:'Gọn nhẹ'};
    let s2eTrial = null;
    function s2gGender(m){return m && m.gender === 'female' ? 'female':'male';}
    function s2gPick(v,opts,fallback){return Object.prototype.hasOwnProperty.call(opts,v)?v:fallback;}
    // Sprint 2G.2: mỗi nhân vật có một bộ màu sinh ra từ seed riêng.
    // Tôn trọng cấu hình đã lưu từ các bản trước, không random lại mỗi lần mở game.
    function getS2EAppearance(member) {
      const dna = normalizeAppearance(member.appearance,member);
      const old = dna.visualOverride || {};
      const stored = dna.visualTraits || {};
      const inheritHair = ({'#232B2B':'black','#4B2C28':'brown','#554337':'brown','#283E45':'blue'})[dna.hairColor];
      const inheritEyes = ({'#1E3A5F':'blue','#34544C':'jade','#5B4433':'amber','#6B4D7D':'violet'})[dna.eyeColor];
      const inheritRobe = ({jade:'jade',white:'ivory',violet:'lilac',bronze:'gold'})[dna.outfitColor];
      const seed = stableAppearanceSeed(member);
      const palettePick = (palette,shift) => {
        const keys = Object.keys(palette);
        return keys[(Math.imul((seed ^ (shift * 0x9e3779b9)) >>> 0,1664525) >>> 0) % keys.length];
      };
      const resolve = (kind, palette, legacy, shift) =>
        s2gPick(stored[kind],palette,s2gPick(old[kind],palette,legacy || palettePick(palette,shift)));
      return {
        hairColor:resolve('hairColor',S2G_HAIR,inheritHair,3),
        eyeColor:resolve('eyeColor',S2G_EYES,inheritEyes,4),
        robeColor:resolve('robeColor',S2G_ROBE,inheritRobe,5),
        // style không còn điều khiển việc cắt lớp tóc/kiếm
        style:'ornate'
      };
    }
    // Sprint 2H: dùng minh họa riêng cho các độ tuổi; giữ nguyên lựa chọn màu trong hồ sơ.
    // Các ảnh tuổi chỉ là mốc hình dáng, chưa phải asset recolor theo từng ADN.
    function s2hAgeArt(m,mini=false) {
      const g=s2gGender(m); const age=getVisualAgeGroup(m);
      if(age==='adult')return s2gSprite(m,getS2EAppearance(m),mini);
      const look=getS2EAppearance(m);
      const hc=s2gPick(look.hairColor,S2G_HAIR,'black');
      const rc=s2gPick(look.robeColor,S2G_ROBE,'jade');
      return `<span class="s2h-stage ${mini?'s2h-mini ':''}s2h-${age} s2h-paint-${g}-${age}-${hc}-${rc}" role="img" aria-label="${g==='female'?'Nữ':'Nam'} ${age==='child'?'ấu niên':age==='teen'?'thiếu niên':'lão niên'}"></span>`;
    }
    function s2gSprite(m,c,mini=false){
      const gender=s2gGender(m);const style=c.style==='simple'?'simple':'ornate';
      const hc=s2gPick(c.hairColor,S2G_HAIR,'black');const rc=s2gPick(c.robeColor,S2G_ROBE,'jade');
      const ec=s2gPick(c.eyeColor,S2G_EYES,'dark');
      const layers=[['base','base'],['hair_back_'+hc,'hair-back'],['robe_'+rc,'robe'],
        ['eyes_'+ec,'eyes'],['hair_front_'+hc,'hair-front'],['accessory','accessory']];
      return `<span class="s2g-stage ${mini?'s2g-mini ':''}${style==='simple'?'s2g-simple':''}" role="img" aria-label="${gender==='female'?'Nữ tu':'Nam tu'} tóc ${S2G_HAIR[hc].name}, mắt ${S2G_EYES[ec].name}, đạo bào ${S2G_ROBE[rc].name}">
        ${layers.map(([asset,role])=>`<span class="s2g-layer s2g-${role} s2g-${gender}-${asset}"></span>`).join('')}</span>`;
    }
    function s2gSwatches(member,kind,label,palette,color){
      return `<div class="s2g-section"><div class="s2g-section-label">${label}: ${palette[color].name}</div>
      <div class="s2g-swatches">${Object.entries(palette).map(([id,o])=>
        `<button type="button" class="s2g-swatch" style="--swatch:${o.hex}" aria-label="${label}: ${o.name}" title="${o.name}" aria-pressed="${color===id}" onclick="s2eSetTrial(${Number(member.id)},'${kind}','${id}')"></button>`).join('')}</div></div>`;
    }
    // Sprint 2I: Ngọc Giản hiển thị chỉ số chiến đấu thật từ getMemberStats,
    // không tạo dữ liệu gameplay mới và không cho sửa diện mạo bẩm sinh.
    function s2iStat(label,value,kind='basic') {
      return `<div class="s2i-stat s2i-${kind}"><span class="s2i-stat-name">${label}</span><strong>${value}</strong></div>`;
    }
    function s2eRenderTrial(member,choices){
      const stage=getVisualAgeGroup(member);
      const stats=getMemberStats(member);
      const stages=[['child','Ấu niên'],['teen','Thiếu niên'],['adult','Thanh niên'],['elder','Lão niên']];
      const basics=[['HP',stats.hp],['Tấn Công',stats.atk],['Phòng Thủ',stats.def],['Tốc Độ',stats.spd]];
      const talents=[['Hút HP',stats.lifesteal+'%'],['Né Tránh',stats.dodge+'%'],['Bạo Kích',stats.crit+'%'],['Liên Kích',stats.combo+'%']];
      return `<div class="s2e-card s2i-card">
        <div class="s2i-heading"><span>✦ Dung Mạo & Thiên Phú</span><span class="s2i-age">${member.gender==='female'?'Nữ tu':'Nam tu'} · ${Math.floor(Number(member.age)||0)} tuổi</span></div>
        <div class="s2f-agebar s2i-agebar">${stages.map(([v,t])=>`<span class="s2f-agechip ${stage===v?'active':''}">${t}</span>`).join('')}</div>
        <div class="s2e-layout s2i-layout">
          <div class="s2g-hero-frame s2i-portrait">${s2hAgeArt(member)}</div>
          <div class="s2i-stats">
            <div class="s2i-stat-heading s2i-basic-heading">Chỉ số cơ bản</div>
            <div class="s2i-stat-list">${basics.map(([k,v])=>s2iStat(k,v)).join('')}</div>
            <div class="s2i-stat-heading s2i-talent-heading">Chỉ số thiên phú</div>
            <div class="s2i-stat-list">${talents.map(([k,v])=>s2iStat(k,v,'talent')).join('')}</div>
          </div>
        </div>
      </div>`;
    }
    function getAppearancePreviewHtml(member){s2eTrial={memberId:member.id,...getS2EAppearance(member)};return `<section id="s2eTrialMount">${s2eRenderTrial(member,s2eTrial)}</section>`;}
    function s2eSetTrial(memberId,kind,value){
      if(!s2eTrial||s2eTrial.memberId!==memberId)return;
      const member=getMemberById(memberId);if(!member)return;
      const valid={hairColor:S2G_HAIR,robeColor:S2G_ROBE,eyeColor:S2G_EYES,style:S2G_STYLE};
      if(!Object.prototype.hasOwnProperty.call(valid,kind)||!Object.prototype.hasOwnProperty.call(valid[kind],value))return;
      s2eTrial[kind]=value;
      const el=document.getElementById('s2eTrialMount');if(el)el.innerHTML=s2eRenderTrial(member,s2eTrial);
    }
    function s2eApplyTrial(memberId){
      const member=getMemberById(memberId);if(!member||!s2eTrial||s2eTrial.memberId!==memberId)return;
      const c=s2eTrial;
      if(!S2G_HAIR[c.hairColor]||!S2G_ROBE[c.robeColor]||!S2G_EYES[c.eyeColor]||!S2G_STYLE[c.style])return;
      member.appearance={...normalizeAppearance(member.appearance,member),visualOverride:{
        hair:member.gender==='female'?'tram_ngoc':'bui_cao', eye:c.eyeColor==='jade'?'jade':'dark',robe:c.robeColor==='jade'?'jade':'white',
        hairColor:c.hairColor,eyeColor:c.eyeColor,robeColor:c.robeColor,style:c.style}};
      markGameDirty();if(gameState.started)saveGameToLocal({silent:true,closeModal:false});
      markAllViewsDirty();updateAllUI();openMemberDetailModal(memberId);
      showToast('🎨 Đã lưu bảng màu, giữ nguyên ADN và tiến trình.');
    }
    function s2eResetAppearance(memberId){
      const member=getMemberById(memberId);if(!member)return;
      member.appearance={...normalizeAppearance(member.appearance,member),visualOverride:null};
      markGameDirty();if(gameState.started)saveGameToLocal({silent:true,closeModal:false});
      markAllViewsDirty();updateAllUI();openMemberDetailModal(memberId);
      showToast('Đã khôi phục diện mạo theo ADN gốc.');
    }
    function createMember({
      name,
      gender,
      age = 16,
      generation = 1,
      realmIdx = 1,
      parentId = null,
      spouseId = null,
      isFounder = false,
      isMarriedIn = false,
      rootOverride = null,
      biologicalFatherId = null,
      biologicalMotherId = null,
      lineageType = "unknown",
      adoptiveParentId = null,
      inheritedAppearance = null
    }) {
      const root = rootOverride || rollSpiritRoot();
      const id = gameState.nextMemberId++;
      // Thiên phú 4 chỉ số đặc biệt phân hóa ngay từ nhỏ theo Linh căn + ngẫu nhiên cá nhân
      const talentLifesteal = +(root.bias.lifesteal * (0.75 + Math.random() * 0.65)).toFixed(1);
      const talentDodge = +(root.bias.dodge * (0.75 + Math.random() * 0.65)).toFixed(1);
      const talentCrit = +(root.bias.crit * (0.75 + Math.random() * 0.65)).toFixed(1);
      const talentCombo = +(root.bias.combo * (0.75 + Math.random() * 0.65)).toFixed(1);

      const member = {
        id,
        name: normalizePlayerName(name, "Vô Danh"),
        gender,
        age,
        generation,
        realmIdx,
        xp: 0,
        innerDemon: 0,
        spiritRoot: root,
        parentId,
        spouseId,
        biologicalFatherId,
        biologicalMotherId,
        lineageType,
        adoptiveParentId,
        isFounder,
        isMarriedIn,
        alive: true,
        birthYear: gameState.year - age,
        deathYear: null,
        role: isFounder ? "Tộc Trưởng" : "Tộc Nhân", // Tộc Trưởng / Trưởng Lão / Đan Sư / Tộc Nhân
        alchemyLevel: 0, // 0: Chưa nhập môn, 1-5: Nhất Phẩm -> Ngũ Phẩm Đan Sư
        craftPath: "none",
        craftXp: 0,
        craftLastSwitchYear: -1,
        elderSatisfaction: 80,
        mentorId: null,
        careGuardianId: null,
        familyBond: 40,
        familyTrial: null,
        inheritedTeaching: false,
        legacyPath: "none",
        legacyReceivedYear: -1,
         bloodlineInheritance: null,
        educationPath: "none", // Đạo học, Đan học, Kiếm học hoặc chưa định hướng
        educationLessons: 0,
        lastEducationYear: -1,
        maritalHarmony: null,
        // Điểm cộng thêm riêng của nhân vật qua tuổi tác, linh thạch & kỳ ngộ
        bonusHp: 0,
        bonusAtk: 0,
        bonusDef: 0,
        bonusSpd: 0,
        lifesteal: talentLifesteal,
        dodge: talentDodge,
        crit: talentCrit,
        combo: talentCombo,
        avatarSeed: Math.floor(Math.random() * 1000)
      };
      // Tạo một lần tại thời điểm gia nhập/sinh ra; không phát lại RNG khi render.
      member.appearance = createRandomAppearance(member);
      // Sinh ngẫu nhiên cố định cả 3 bảng màu, không tác động RNG gameplay.
      const lookSeed = stableAppearanceSeed(member);
      const pickBirthColor = (palette, salt) => {
        const ids = Object.keys(palette);
        let h = (lookSeed ^ Math.imul(salt, 0x9e3779b9)) >>> 0;
        h ^= h >>> 16; h = Math.imul(h, 0x7feb352d) >>> 0;
        h ^= h >>> 15; h = Math.imul(h, 0x846ca68b) >>> 0;
        return ids[(h ^ (h >>> 16)) % ids.length];
      };
      member.appearance.visualTraits = {
        hairColor:pickBirthColor(S2G_HAIR,1),
        eyeColor:pickBirthColor(S2G_EYES,2),
        robeColor:pickBirthColor(S2G_ROBE,3)
      };
      if (inheritedAppearance) {
        member.appearance = normalizeAppearance({ ...member.appearance, ...inheritedAppearance }, member);
      }
      return member;
    }

    // Tính toán đầy đủ 8 chỉ số của 1 nhân vật (HP, Tấn Công, Phòng Thủ, Tốc Độ, Hút HP, Né Tránh, Bạo Kích, Liên Kích)
    function getMemberStats(m) {
      const realm = REALMS[Math.min(m.realmIdx, REALMS.length - 1)];
      const bloodline = BLOODLINES.find(b => b.id === gameState.bloodlineId) || BLOODLINES[0];

      // Hệ số phát triển từ nhỏ (1 tuổi -> 18 tuổi trưởng thành, sau 18 tuổi tăng nhẹ theo kinh nghiệm)
      const ageFactor = m.age < 18 ? (0.32 + (m.age / 18) * 0.68) : (1 + Math.min(0.35, (m.age - 18) * 0.005));

      // Bonus bảo vật được tổng hợp một lần, dùng chung cho toàn bộ nhân vật.
      const bonuses = getClanAggregateBonuses();
      const tHpFlat = bonuses.hpFlat, tHpPct = bonuses.hpPct;
      const tAtkFlat = bonuses.atkFlat, tDefFlat = bonuses.defFlat, tSpdFlat = bonuses.spdFlat;
      const tLifesteal = bonuses.lifesteal, tDodge = bonuses.dodge;
      const tCrit = bonuses.crit, tCombo = bonuses.combo;

      const hpMult = (bloodline.bonus.hpMult || 1) * (1 + tHpPct / 100);
      const defMult = bloodline.bonus.defMult || 1;
      const spdMult = bloodline.bonus.spdMult || 1;

      const hp = Math.round((realm.baseHp * ageFactor + m.bonusHp + tHpFlat) * hpMult);
      const atk = Math.round(realm.baseAtk * ageFactor + m.bonusAtk + tAtkFlat);
      const def = Math.round((realm.baseDef * ageFactor + m.bonusDef + tDefFlat) * defMult);
      const spd = Math.round((realm.baseSpd * ageFactor + m.bonusSpd + tSpdFlat) * spdMult);

      // 4 chỉ số thiên phú tăng nhẹ theo tu vi và cộng bảo vật + huyết mạch
      const realmSkillBonus = m.realmIdx * 0.35;
      const lifesteal = +Math.min(100, Math.max(0, m.lifesteal + realmSkillBonus * 0.5 + (bloodline.bonus.lifesteal || 0) + tLifesteal)).toFixed(1);
      const dodge = +Math.min(100, Math.max(0, m.dodge + realmSkillBonus * 0.5 + (bloodline.bonus.dodge || 0) + tDodge)).toFixed(1);
      const crit = +Math.min(100, Math.max(0, m.crit + realmSkillBonus * 0.6 + (bloodline.bonus.crit || 0) + tCrit)).toFixed(1);
      const combo = +Math.min(100, Math.max(0, m.combo + realmSkillBonus * 0.5 + (bloodline.bonus.combo || 0) + tCombo)).toFixed(1);

      const power = Math.round(hp * 0.25 + atk * 2.4 + def * 1.8 + spd * 1.5 + (lifesteal + dodge + crit + combo) * 6);

      return { hp, atk, def, spd, lifesteal, dodge, crit, combo, power };
    }

    // =========================================================================
    // 6. VẼ CHÂN DUNG SVG TU TIÊN THEO ĐỘ TUỔI & GIỚI TÍNH
    // =========================================================================
    function getCharacterSvg(m, size = 54) {
      const alt = escapeHtml((m && m.name) || 'Tộc nhân tu tiên');
      const safeSize = Math.max(24, Math.min(260, Number(size) || 54));
      return `<span class="s2g-mini-outer" style="width:${safeSize}px;height:${safeSize}px" aria-label="${alt}">${s2hAgeArt(m||{},true)}</span>`;
    }

    function getCultivatorArtHtml(member) {
      if (!member) return "";
      const g=member.gender === "female" ? "female" : "male";
      const p=getS2EAppearance(member);
      const key=g+"_"+p.hairColor+"_"+p.robeColor;
      const art=S2K1_MEDITATION_ART[key] || S2K1_MEDITATION_ART[g+"_black_jade"];
      return `<img class="cultivator-fullbody s2k1-cultivator" src="${art}" loading="eager" decoding="async" draggable="false" alt="${escapeHtml(member.name)} đang tọa thiền" />`;
    }

    // =========================================================================
    // 7. KHỞI TẠO GAME MỚI & CHỌN THỦY TỔ
    // =========================================================================
    function renderStartupModalOptions() {
      const surnameEl = document.getElementById("inputSurname");
      const givenEl = document.getElementById("inputGivenName");
      const s = (surnameEl?.value || "Trần").trim().slice(0, 5) || "Trần";
      const g = (givenEl?.value || "Nam").trim().slice(0, 5) || "Nam";

      const previewEl = document.getElementById("startupAvatarPreview");
      if (previewEl) {
        previewEl.innerHTML = getCharacterSvg({
          name: `${s} ${g}`,
          gender: selectedStartupGender,
          age: 18,
          isFounder: true,
          spiritRoot: SPIRIT_ROOTS[4]
        }, 72);
      }

      const maleBtn = document.getElementById("btnGenderMale");
      const femaleBtn = document.getElementById("btnGenderFemale");
      if (maleBtn && femaleBtn) {
        maleBtn.className = selectedStartupGender === "male"
          ? "py-1.5 rounded-xl font-extrabold text-xs border-2 border-sky-600 bg-sky-100 text-sky-900"
          : "py-1.5 rounded-xl font-extrabold text-xs border-2 border-slate-300 bg-white text-slate-600";
        femaleBtn.className = selectedStartupGender === "female"
          ? "py-1.5 rounded-xl font-extrabold text-xs border-2 border-pink-600 bg-pink-100 text-pink-900"
          : "py-1.5 rounded-xl font-extrabold text-xs border-2 border-slate-300 bg-white text-slate-600";
      }

      const blBox = document.getElementById("bloodlineOptions");
      if (blBox) {
        blBox.innerHTML = BLOODLINES.map(b => `
          <button type="button" onclick="selectStartupBloodline('${b.id}')"
            class="text-left p-2 rounded-xl border-2 transition ${selectedStartupBloodline === b.id ? 'border-emerald-700 bg-emerald-100/90' : 'border-slate-300 bg-white'}">
            <div class="text-[11px] font-extrabold text-emerald-950">${b.name}</div>
            <div class="text-[9px] text-slate-600 leading-tight mt-0.5">${b.desc}</div>
          </button>
        `).join("");
      }
    }

    function setStartupGender(g) {
      selectedStartupGender = g;
      const givenEl = document.getElementById("inputGivenName");
      if (givenEl) {
        givenEl.value = g === "male" ? "Nam" : "Dao";
      }
      renderStartupModalOptions();
    }

    function selectStartupBloodline(id) {
      selectedStartupBloodline = id;
      renderStartupModalOptions();
    }

    function randomizeFounderName() {
      const s = SURNAMES[Math.floor(Math.random() * SURNAMES.length)];
      const pool = selectedStartupGender === "male" ? MALE_NAMES : FEMALE_NAMES;
      const g = pool[Math.floor(Math.random() * pool.length)];
      const surnameEl = document.getElementById("inputSurname");
      const givenEl = document.getElementById("inputGivenName");
      if (surnameEl) surnameEl.value = s;
      if (givenEl) givenEl.value = g;
      renderStartupModalOptions();
    }

    function startNewClanGame() {
      if ((savedProgressAvailable || gameState.started) && !allowNewGameOverwrite) {
        beginNewClanFlow();
        return;
      }
      const surnameEl = document.getElementById("inputSurname");
      const givenEl = document.getElementById("inputGivenName");
      const s = normalizePlayerName(surnameEl?.value, "Trần").split(/\s+/)[0] || "Trần";
      const g = normalizePlayerName(givenEl?.value, "Nam").split(/\s+/)[0] || "Nam";
      const fullName = normalizePlayerName(`${s} ${g}`, "Trần Nam");

      stopGameTimers();
      closeGenericModal();
      document.getElementById("battleScreen")?.classList.add("hidden");
      gameState = createInitialGameState();
      gameState.started = true;
      gameState.paused = false;
      gameState.clanSurname = s;
      gameState.bloodlineId = BLOODLINES.some(item => item.id === selectedStartupBloodline)
        ? selectedStartupBloodline
        : "kiem_hoang";
      currentTab = "family";
      treeTransform = { x: 40, y: 35, scale: 1 };
      isDraggingTree = false;
      pinchStartDist = 0;
      marriageModalContext = null;
      adoptCandidateContext = null;
      rebuildMemberIndex();
      invalidateAggregateBonuses();
      markAllViewsDirty();

      // Thủy tổ khởi đầu với Tam Linh Căn trở lên để đủ sức gánh vác gia tộc.
      const founder = createMember({
        name: fullName,
        gender: selectedStartupGender === "female" ? "female" : "male",
        age: 18,
        generation: 1,
        realmIdx: 1,
        isFounder: true,
        rootOverride: SPIRIT_ROOTS[2]
      });
      gameState.members.push(founder);
      rebuildMemberIndex();
      gameState.activeCultivatorId = founder.id;
      gameState.squadIds = [founder.id];
      gameState.clanLeaderId = founder.id;
      gameState.heirId = null;

      const fStats = getMemberStats(founder);
      gameState.teamMaxHp = fStats.hp;
      gameState.teamHp = fStats.hp;
      gameState.historyLog = [
        `Năm 1000: Tiên Tổ tiền nhiệm tọa hóa tại Hàn Môn Động Phủ, để lại Thanh Liên Cổ Ấn cho hậu duệ duy nhất ${founder.name}.`
      ];

      allowNewGameOverwrite = false;
      savedProgressAvailable = true;
      gameIsDirty = true;
      document.getElementById("startupModal")?.classList.add("hidden");
      ["cave", "secret", "estate", "affairs", "family"].forEach(tab => {
        document.getElementById(`view-${tab}`)?.classList.toggle("hidden", tab !== "family");
        document.getElementById(`tab-${tab}`)?.classList.toggle("active", tab === "family");
      });
      updateAllUI();
      centerTree();
      startContinuousTimeLoop();
      startAutosaveLoop();
      saveGameToLocal({ silent: true, closeModal: false });
    }

    // =========================================================================
    // 8. VÒNG LẶP THỜI GIAN TRÔI LIÊN TỤC (TỰ DỪNG KHI CÓ KỲ NGỘ)
    // =========================================================================
    function startContinuousTimeLoop() {
      if (timeLoopTimer) clearInterval(timeLoopTimer);
      if (!gameState.started) return;
      timeLoopTimer = setInterval(() => {
        if (!gameState.started || gameState.paused || gameState.pendingAdventure || battleState || gameState.clanExtinct) return;
        advanceOneMonth();
      }, 2400);
    }

    function toggleTimePause() {
      gameState.paused = !gameState.paused;
      const btn = document.getElementById("btnToggleTime");
      if (btn) btn.textContent = gameState.paused ? "▶️" : "⏸";
      markGameDirty();
      if (!gameState.paused && gameState.pendingAdventure) renderAdventureModal();
    }

    // Sprint 3F.3 — Nhân Quả Liên Điện: hành trình một tàn quyển qua năm điện.
    // Một hành trình tại một thời điểm; không ghi buff lặp theo khung hình.
    function s3f3ArcSummary(){
      const a=gameState.s3f3Arc;
      if(!a)return '';
      return ({discovered:'Bí Cảnh tìm thấy tàn quyển; Nội Chính sẽ họp bàn đầu tư.',
        research:`Đan Các đang giải bí phương (${a.progress}/8). Trấn Thủ Đan Sư cấp 2+ giúp nghiên cứu nhanh hơn.`,
        formula:'Bí phương đã hoàn thiện, chờ lựa chọn thành phẩm.',
        await_tribulation:'Trúc Cơ Đan cổ đã vào kho; chờ độ đại kiếp thành công để ghi nhận truyền thừa.',
        complete:'Đã hoàn tất hành trình Bí Cảnh → Nội Chính → Đan Các → Động Phủ → Gia Phả.',
        archived:'Tàn quyển được lưu trong gia phả; gia tộc chọn không đầu tư lần này.'})[a.status] || '';
    }
    function s3f3DiscoverFromVictory(b){
      if(b.overleveled||!gameState.started)return false;
      const now=getMonthIndex(),old=gameState.s3f3Arc;
      if(old && !['complete','archived'].includes(old.status))return false;
      if(old && now-gameState.s3f3LastEndMonth<36)return false;
      if((gameState.s3f3ArcCount||0)>=5)return false;
      // Cơ duyên đầu tiên đảm bảo xuất hiện sau trận thắng hợp lệ để người chơi trải nghiệm.
      const discoverer=getValidLivingMember(gameState.squadIds.find(id=>getValidLivingMember(id))) ||
        getValidLivingMember(gameState.clanLeaderId);
      if(!discoverer)return false;
      gameState.s3f3Arc={status:'discovered',discovererId:discoverer.id,startedAt:now,updatedAt:now,
        progress:0,route:'',researcherId:null,product:'',resultMemberId:null};
      gameState.s3f3ArcCount=(gameState.s3f3ArcCount||0)+1;
      addHistory(`Năm ${gameState.year}: ${discoverer.name} tìm thấy Tàn Quyển Huyền Đan ở Bí Cảnh. Nội Chính cần quyết định nghiên cứu.`);
      setTicker('📜 Bí Cảnh thu được Tàn Quyển Huyền Đan! Chờ cuộc họp Nội Chính.');
      return true;
    }
    function s3f3CommitCouncil(member,route){
      const a=gameState.s3f3Arc;
      if(!a||a.status!=='discovered')return 'Tàn quyển đã được xử lý.';
      if(route==='shelved'){
        a.status='archived';a.route='shelved';a.updatedAt=getMonthIndex();
        gameState.s3f3LastEndMonth=getMonthIndex();
        // Đổi lấy ngoại giao, không có đan dược mạnh để tránh chọn mọi lợi ích.
        const f=gameState.factions.find(f=>f.id==='duoc_vuong');if(f)f.relation=Math.min(100,f.relation+6);
        addHistory(`Năm ${gameState.year}: Nội Chính trao tàn quyển cho Dược Vương Cốc, hảo cảm +6; cơ duyên khép lại.`);
        return 'Gia tộc bảo toàn lực lượng, đổi lấy +6 hảo cảm Dược Vương Cốc. Tàn quyển không còn nghiên cứu được.';
      }
      if(gameState.spiritStones>=35){gameState.spiritStones-=35;a.route='funded';}
      else {a.route='frugal';}
      a.status='research';a.progress=0;a.updatedAt=getMonthIndex();
      addHistory(`Năm ${gameState.year}: Nội Chính quyết định giải bí phương theo hướng ${a.route==='funded'?'đầu tư 35 linh thạch':'tự nghiên cứu tiết kiệm'}.`);
      return a.route==='funded'?'Đã chi 35 linh thạch. Đan Các với Đan Sư trấn thủ sẽ đẩy nhanh nghiên cứu.':'Không đủ 35 linh thạch, chuyển sang nghiên cứu tiết kiệm. Công trình phù hợp vẫn tăng tốc.';
    }
    function s3f3ProcessResearch(){
      const a=gameState.s3f3Arc;
      if(!a||a.status!=='research')return;
      const now=getMonthIndex();if(now<=a.updatedAt)return;
      const dan=s3f2Estate('dan_cac'),worker=dan&&getValidGuardian(dan);
      const ready=!!(dan&&dan.level>=2&&worker&&worker.alive&&worker.craftPath==='dan_cac');
      // Hỗ trợ chậm khi không có Đan Sư, không khóa hành trình vĩnh viễn.
      const gain=ready?(a.route==='funded'?3:2):((now-a.startedAt)%3===0?1:0);
      if(gain){a.progress=Math.min(8,a.progress+gain);a.researcherId=ready?worker.id:a.researcherId;}
      a.updatedAt=now;
      if(a.progress>=8){
        a.status='formula';
        addHistory(`Năm ${gameState.year}: Bí phương Huyền Đan được giải mã! Đan Các chờ quyết định thành phẩm.`);
        setTicker('⚗️ Đan Các đã giải xong bí phương Tàn Quyển Huyền Đan!');
      }
    }
    function s3f3CommitFormula(member,product){
      const a=gameState.s3f3Arc;if(!a||a.status!=='formula')return 'Bí phương không còn chờ quyết định.';
      a.updatedAt=getMonthIndex();a.product=product;
      if(product==='truc_co_dan'){
        // Sử dụng đúng kho đan dược hiện tại; tránh thêm một loại vật phẩm không có UI.
        gameState.pills.truc_co_dan=(gameState.pills.truc_co_dan||0)+1;
        a.status='await_tribulation';
        addHistory(`Năm ${gameState.year}: Đan Các hoàn thành 1 Trúc Cơ Đan cổ. Động Phủ sẽ ghi nhận khi một tộc nhân độ đại kiếp thành công.`);
        return 'Đã nhập kho +1 Trúc Cơ Đan. Hãy chọn tộc nhân đủ tu vi ở Động Phủ để vượt đại kiếp.';
      }
      gameState.healPills=(gameState.healPills||0)+2;
      a.status='complete';gameState.s3f3LastEndMonth=getMonthIndex();
      addHistory(`Năm ${gameState.year}: Gia tộc chọn luyện 2 Hồi Xuân Đan. Hành trình bí phương khép lại trong Gia Phả.`);
      return 'Nhận +2 Hồi Xuân Đan cho đội Bí Cảnh; kết thúc tuyến truyền thừa an toàn.';
    }
    function s3f3FinishAtTribulation(member){
      const a=gameState.s3f3Arc;
      if(!a||a.status!=='await_tribulation')return false;
      a.status='complete';a.resultMemberId=member.id;a.updatedAt=getMonthIndex();
      gameState.s3f3LastEndMonth=getMonthIndex();
      // Thưởng gia phả và đạo tâm nhỏ một lần, không thêm buff định kỳ.
      member.familyBond=Math.min(100,(member.familyBond||40)+5);
      addHistory(`Năm ${gameState.year}: ${member.name} độ đại kiếp thành công; huyền đan cổ được ghi vào Gia Phả, tình thân +5.`);
      return true;
    }
    function s3f3DispatchArc(){
      if(gameState.pendingAdventure||battleState||!gameState.started||gameState.clanExtinct)return false;
      const a=gameState.s3f3Arc;if(!a)return false;
      const templateId=a.status==='discovered'?'s3f3_council':a.status==='formula'?'s3f3_formula':null;
      if(!templateId || getMonthIndex()<=a.updatedAt || getMonthIndex()-(gameState.destinyLastMonth??-100)<2)return false;
      const member=getValidLivingMember(a.discovererId)||getValidLivingMember(gameState.clanLeaderId)||gameState.members.find(m=>m.alive);
      if(!member)return false;
      gameState.pendingAdventure={eventId:templateId,memberId:member.id,context:{},createdAtMonthIndex:getMonthIndex()};
      gameState.destinyLastMonth=getMonthIndex();gameState.lastAdventureMonthIndex=getMonthIndex();
      markGameDirty();renderAdventureModal();return true;
    }
    // Sprint 3F.3 — Liên Kết Ngũ Điện: các tab dùng chung dữ liệu thành tựu.
    // Tất cả hiệu ứng là hàm tính từ trạng thái gốc; không ghi thưởng vĩnh viễn mỗi lần render.
    function s3f2Estate(id){return gameState.estates.find(e=>e.id===id);}
    function s3f2EstateReady(id){
      const e=s3f2Estate(id);return !!(e&&e.level>=2&&getValidGuardian(e));
    }
    function s3f2LinkBonuses(){
      const school=s3f2EstateReady('tang_kinh')?s3f2Estate('tang_kinh'):null;
      const mountain=s3f2EstateReady('to_son')?s3f2Estate('to_son'):null;
      const dan=s3f2EstateReady('dan_cac')?s3f2Estate('dan_cac'):null;
      const field=s3f2EstateReady('linh_dien')?s3f2Estate('linh_dien'):null;
      const forge=s3f2EstateReady('khi_phuong')?s3f2Estate('khi_phuong'):null;
      const elders=gameState.members.filter(m=>m.alive&&m.role==='Trưởng Lão'&&(m.elderSatisfaction??0)>=60);
      const allies=(gameState.factions||[]).filter(f=>f.relation>=60);
      return {
        schoolXp:school?Math.min(4,1+school.level):0,
        mountainXp:mountain?Math.min(4,1+Math.floor(mountain.level/2)):0,
        healPct:dan?Math.min(3,1+Math.floor(dan.level/2)):0,
        herbChance:field?Math.min(.18,.04+field.level*.02):0,
        forgeAtkPct:forge?Math.min(.06,.01+forge.level*.01):0,
        elderIncomePct:Math.min(.06,elders.length*.02),
        allyStonePct:Math.min(.15,allies.length*.05),
        elders:elders.length,allies:allies.length
      };
    }
    function s3f2FamilySquadBonus(squad){
      // Quan hệ cha mẹ ruột, đạo lữ hoặc sư đồ trong cùng đội tạo phối hợp, tối đa 6%.
      let bonds=0;
      for(let i=0;i<squad.length;i++)for(let j=i+1;j<squad.length;j++){
        const a=squad[i],b=squad[j];
        const linked=a.spouseId===b.id||b.spouseId===a.id||a.mentorId===b.id||b.mentorId===a.id||
          (a.lineageType==='birth'&&(a.biologicalFatherId===b.id||a.biologicalMotherId===b.id))||
          (b.lineageType==='birth'&&(b.biologicalFatherId===a.id||b.biologicalMotherId===a.id));
        if(linked)bonds++;
      }
      return Math.min(.06,bonds*.02);
    }
    function s3f2PanelData(tab){
      const b=s3f2LinkBonuses();
      const bits=tab==='cave'?[`Tàng Kinh +${b.schoolXp} tu vi/tháng`,`Tổ Sơn +${b.mountainXp} tu vi/tháng`,`Đan Các +${b.healPct}% hồi phục đội/tháng`]:
        tab==='secret'?[`Khí Phường +${Math.round(b.forgeAtkPct*100)}% tấn công tổ đội`,`Nội Chính +${Math.round(b.allyStonePct*100)}% linh thạch chiến thắng`,`Gia Phả: đi cùng thân nhân/sư phụ tăng hiệp lực (tối đa 6%)`,`Linh Điền: ${Math.round(b.herbChance*100)}% thu thêm Ngọc Tủy Chi khi thắng`]:
        tab==='estate'?[`Trưởng Lão trung thành: +${Math.round(b.elderIncomePct*100)}% thu nhập`,`Trấn Thủ cấp 2 trở lên mở liên kết Cơ Nghiệp → Động Phủ/Bí Cảnh`]:
        [`${b.elders} Trưởng Lão trung thành hỗ trợ Cơ Nghiệp`,`${b.allies} thế lực hảo cảm ≥60 hỗ trợ thưởng Bí Cảnh`];
      const cross=s3f3ArcSummary();
      return {bits,cross};
    }
    function s3f2OpenInfo(tab){
      const labels={cave:'Động Phủ',secret:'Bí Cảnh',estate:'Cơ Nghiệp',affairs:'Nội Chính'};
      const data=s3f2PanelData(tab);
      const lines=data.bits.map(t=>`<li class="rounded-xl border border-amber-200 bg-amber-50/80 px-3 py-2">${escapeHtml(t)}</li>`).join('');
      const body=`<div class="space-y-3 text-xs text-slate-800"><div class="rounded-2xl border border-amber-300 bg-amber-50/90 p-3"><b class="text-amber-900">🔗 Liên Kết Gia Tộc · ${escapeHtml(labels[tab]||'Hệ thống')}</b><div class="mt-1 text-[11px] text-slate-700">Các hiệu ứng này phụ thuộc công trình có Trấn Thủ, quan hệ và nhân sự hiện tại.</div></div><ul class="space-y-2">${lines}</ul>${data.cross?`<div class="rounded-2xl border border-emerald-200 bg-white p-3"><b class="text-emerald-900">📜 Nhân Quả Liên Điện</b><p class="mt-1 leading-5">${escapeHtml(data.cross)}</p></div>`:''}</div>`;
      openGenericModal('🔗 Liên Kết Gia Tộc',body);
    }
    function s3f2PanelHtml(tab){
      return `<div class="mb-2 flex justify-end" data-s3f2-crosslink="${tab}"><button onclick="s3f2OpenInfo('${tab}')" class="inline-flex items-center gap-1 rounded-full border border-amber-300 bg-amber-50/90 px-2.5 py-1 text-[10px] font-bold text-amber-900 shadow-sm active:scale-95"><span class="text-xs">🔗</span><span>Liên kết</span></button></div>`;
    }
    function s3f2ShowPanel(anchorId,tab){
      const anchor=document.getElementById(anchorId);
      if(!anchor||!anchor.parentElement)return;
      let el=anchor.parentElement.querySelector(`[data-s3f2-crosslink="${tab}"]`);
      if(!el){el=document.createElement('div');anchor.parentElement.insertBefore(el,anchor);}
      el.outerHTML=s3f2PanelHtml(tab);
    }

    function getNetMonthlyIncome() {
      const bonuses = getClanAggregateBonuses();
      const discBonus = gameState.outerDisciples.reduce((sum, disciple) =>
        sum + safeNumber(disciple.proficiency, 0, 0, 100) / 100, 0
      );
      let estateIncome = 0;
      const incomeContext = { bonuses, discBonus };
      gameState.estates.forEach(est => {
        estateIncome += getEstateProductionAtLevel(est, est.level, incomeContext);
      });

      const aliveCount = gameState.members.filter(member => member.alive).length;
      const upkeep = aliveCount * 0.6 + gameState.outerDisciples.length * 0.8;
      const pol=s3f4Politics();
      return Number((estateIncome*(1+pol.alliance*.015-pol.feud*.01) - upkeep).toFixed(1));
    }

    function advanceOneMonth() {
      if (!gameState.started || gameState.clanExtinct || gameState.pendingAdventure || battleState) return;
      gameState.month++;
      if (gameState.month > 12) {
        gameState.month = 1;
        gameState.year++;
        handleAnnualAgingAndLifeCycle();
        if (gameState.clanExtinct) {
          updateAllUI();
          return;
        }
      }

      // Cộng sản lượng trước, sau đó nhân sự tích lũy kinh nghiệm nghề cho tháng tiếp theo.
      const net = getNetMonthlyIncome();
      gameState.spiritStones = safeNumber(gameState.spiritStones + net, 0, 0, GAME_CONFIG.maxResource);
      s3eProcessMonthlyCraft();
      s3e3ProcessAutomaticEducation();
      s3f3ProcessResearch();

      const treasureXpFlat = getClanAggregateBonuses().xpFlat;
      gameState.members.filter(member => member.alive).forEach(member => {
        const realm = REALMS[member.realmIdx];
        const links=s3f2LinkBonuses();
        const veinGain = gameState.veinLevel * 1.2 * member.spiritRoot.xpMult + treasureXpFlat + links.mountainXp + (member.age<18?links.schoolXp:0);
        addXp(member, Math.round(veinGain));
        // Tiểu cảnh giới: toàn bộ tộc nhân tự thử tiến cấp, kể cả người đang bế quan.
        // Đại cảnh giới dừng tại ngưỡng có đan dược bắt buộc, chỉ vượt qua tại Động Phủ.
        s3e3TryMinorBreakthrough(member);
      });

      recalcTeamMaxHp();
      if (gameState.teamHp < gameState.teamMaxHp) {
        gameState.teamHp = Math.min(gameState.teamMaxHp, Math.round(gameState.teamHp + gameState.teamMaxHp * (0.035+s3f2LinkBonuses().healPct/100) + 4));
      }

      processFamilyBirths();
      s3f4AutoExpeditionMonth();
      // Kỳ ngộ có hồi đến hạn ưu tiên, tiếp theo Thiên Cơ, cuối cùng sự kiện ngẫu nhiên.
      const openedFamily = s3f41DispatchFamily();
      const openedStory = !openedFamily && s3dCheckDue();
      const openedCross = !openedFamily && !openedStory && s3f3DispatchArc();
      const openedPolitics = !openedFamily && !openedStory && !openedCross && s3f4DispatchPolitics();
      const openedDestiny = !openedFamily && !openedStory && !openedCross && !openedPolitics && s3e2DispatchDestiny();
      if (!openedFamily && !openedStory && !openedCross && !openedPolitics && !openedDestiny && canTriggerAdventure() && Math.random() < 0.14) triggerFamilyAdventure();

      updateAllUI();
    }

    function handleAnnualAgingAndLifeCycle() {
      const aliveMembers = gameState.members.filter(member => member.alive);
      aliveMembers.forEach(member => {
        member.age++;
        // Lão hóa đã xảy ra không đảo ngược khi tu vi tăng; hồi xuân thuộc kỳ ngộ riêng về sau.
        if (member.appearance && isVisuallyElder(member.age, member.realmIdx)) {
          member.appearance.elderReached = true;
        }
        if (member.age <= 18) {
          member.lifesteal = +(member.lifesteal + member.spiritRoot.bias.lifesteal * 0.08).toFixed(1);
          member.dodge = +(member.dodge + member.spiritRoot.bias.dodge * 0.08).toFixed(1);
          member.crit = +(member.crit + member.spiritRoot.bias.crit * 0.08).toFixed(1);
          member.combo = +(member.combo + member.spiritRoot.bias.combo * 0.08).toFixed(1);
        }

        const maxLifespan = 75 + member.realmIdx * 18;
        if (member.age >= maxLifespan && Math.random() < 0.25) {
          member.alive = false;
          member.deathYear = gameState.year;
          addHistory(`Năm ${gameState.year}: ${member.name} (${REALMS[member.realmIdx].name}) thọ nguyên cạn kiệt, an nhiên tọa hóa ở tuổi ${member.age}.`);
          setTicker(`🕯️ ${member.name} đã tọa hóa ở tuổi ${member.age}...`);
          if (member.id === gameState.activeCultivatorId) gameState.activeCultivatorId = null;
          if (member.id === gameState.clanLeaderId) {
            s3fSealLeaderLegacy(member);
            gameState.clanLeaderId = null;
          }
          if (member.id === gameState.heirId) gameState.heirId = null;
          gameState.squadIds = gameState.squadIds.filter(id => id !== member.id);
          gameState.estates.forEach(estate => {
            if (Number(estate.guardianId) === member.id) estate.guardianId = null;
          });
        }
      });

      const singles = gameState.members.filter(member =>
        member.alive && !member.spouseId && member.age >= 20 && !member.isMarriedIn
      );
      const eligible = singles.find(person => !gameState.marriageNotices[person.id]);
      if (eligible) {
        gameState.marriageNotices[eligible.id] = gameState.year;
        addHistory(`Năm ${gameState.year}: ${eligible.name} đủ tuổi tìm đạo lữ. Gia Chủ có thể quyết định mai mối khi thuận tiện.`);
      }

      s3c3ResolveComingOfAge();
      ensureClanLeadership();
      s3c2RefreshChildCare();
      if (getAliveCount() === 0) {
        gameState.clanExtinct = true;
        gameState.paused = true;
        addHistory(`Năm ${gameState.year}: Dòng chính gia tộc tạm thời tuyệt tự; chờ quyết định kế thừa.`);
        showClanExtinctionModal();
      } else if (!getValidLivingMember(gameState.activeCultivatorId)) {
        const nextAlive = gameState.members.find(member => member.alive);
        gameState.activeCultivatorId = nextAlive ? nextAlive.id : null;
      }
      rebuildMemberIndex();
      recalcTeamMaxHp();
    }

    function ensureClanLeadership() {
      const currentLeader = getValidLivingMember(gameState.clanLeaderId);
      if (currentLeader) {
        currentLeader.role = "Tộc Trưởng";
        return;
      }
      const preferredHeir = getValidLivingMember(gameState.heirId);
      const successor = preferredHeir && preferredHeir.age >= GAME_CONFIG.minMarriageAge && !preferredHeir.isMarriedIn
        ? preferredHeir
        : gameState.members
            .filter(member => member.alive && member.age >= GAME_CONFIG.minMarriageAge && !member.isMarriedIn)
            .sort((a, b) =>
              b.generation - a.generation ||
              b.realmIdx - a.realmIdx ||
              b.age - a.age
            )[0];
      if (!successor) {
        gameState.clanLeaderId = null;
        return;
      }
      const previousLeader = gameState.members.find(member => member.id === gameState.clanLeaderId);
      if (previousLeader && previousLeader.alive) previousLeader.role = "Tộc Nhân";
      successor.role = "Tộc Trưởng";
      gameState.clanLeaderId = successor.id;
      gameState.heirId = null;
      s3fSuccession(successor);
      addHistory(`Năm ${gameState.year}: ${successor.name} được chọn kế nhiệm chức Tộc Trưởng, tiếp nối đạo thống.`);
      setTicker(`👑 ${successor.name} đã kế nhiệm vị trí Tộc Trưởng.`);
    }

    function setClanHeir(memberId) {
      const candidate = getValidLivingMember(memberId);
      if (!candidate || candidate.age < GAME_CONFIG.minMarriageAge || candidate.isMarriedIn) {
        return showToast("Người kế vị phải còn sống, từ 16 tuổi và thuộc dòng chính gia tộc.");
      }
      if (candidate.id === gameState.clanLeaderId) return showToast("Người này hiện đã là Tộc Trưởng.");
      gameState.heirId = candidate.id;
      addHistory(`Năm ${gameState.year}: ${candidate.name} được chỉ định làm người kế vị Tộc Trưởng.`);
      updateAllUI();
      showToast(`👑 Đã chỉ định ${candidate.name} làm người kế vị.`);
      openMemberDetailModal(candidate.id);
    }

    // Sprint 3F.4.1.1: Thai kỳ phải có quyết định của Gia Chủ và được lưu theo tháng.
    const S3F41_MATCH_FEE=15, S3F41_MATCH_COOLDOWN=6, S3F41_MATCH_VALID=12;
    function s3f41Couple(parent){
      if(!parent||!parent.alive||!parent.spouseId||parent.isMarriedIn||parent.age<18||parent.age>55)return null;
      const spouse=getValidLivingMember(parent.spouseId);
      if(!spouse||spouse.age<18||spouse.age>55||spouse.spouseId!==parent.id||parent.gender===spouse.gender)return null;
      return {parent,spouse,father:parent.gender==='male'?parent:spouse,mother:parent.gender==='female'?parent:spouse};
    }
    function s3f41CoupleKey(fatherId,motherId){return `${fatherId}:${motherId}`;}
    function s3f41ChildrenCount(fatherId,motherId){
      return gameState.members.filter(m=>m.lineageType==='birth'&&m.biologicalFatherId===fatherId&&m.biologicalMotherId===motherId).length;
    }
    function s3f41Pregnant(fatherId,motherId){return gameState.familyPregnancies.some(p=>p.fatherId===fatherId&&p.motherId===motherId);}
    function s3f41CanConceive(c){
      return !!(c && s3f41ChildrenCount(c.father.id,c.mother.id)<3 && !s3f41Pregnant(c.father.id,c.mother.id) &&
        getAliveCount()+gameState.familyPregnancies.length<getMaxAbodeCapacity());
    }
    function processFamilyBirths(){
      // Không tự sinh con. Chỉ đưa đề nghị cầu tự vào hàng chờ theo xác suất mỗi tháng.
      const now=getMonthIndex();
      for(const parent of gameState.members){
        const c=s3f41Couple(parent);if(!s3f41CanConceive(c))continue;
        const key=s3f41CoupleKey(c.father.id,c.mother.id);
        if(now-(gameState.familyRequestCooldowns[key]??-100)<12)continue;
        const harmony=Number.isFinite(parent.maritalHarmony)?parent.maritalHarmony:55;
        const chance=(gameState.birthPolicy==='slow'?0.012:0.025)+Math.min(100,Math.max(0,harmony))*(gameState.birthPolicy==='slow'?0.00012:0.00022);
        if(Math.random()<chance){
          gameState.familyRequestCooldowns[key]=now;
          gameState.familyRequests=gameState.familyRequests||[];
          if(!gameState.familyRequests.some(r=>r.fatherId===c.father.id&&r.motherId===c.mother.id))
            gameState.familyRequests.push({fatherId:c.father.id,motherId:c.mother.id,created:now});
        }
      }
    }
    function s3f41PregnancyResult(motherId,method){
      const pregnancy=gameState.familyPregnancies.find(p=>p.motherId===motherId);
      if(!pregnancy)return 'Thai kỳ không còn hiệu lực.';
      const father=getMemberById(pregnancy.fatherId),mother=getMemberById(pregnancy.motherId);
      gameState.familyPregnancies=gameState.familyPregnancies.filter(p=>p!==pregnancy);
      if(!father||!mother||!mother.alive){return 'Thai kỳ không thể tiếp tục vì mẹ đã qua đời.';}
      let table=[.90,.06,.03,.01];
      if(method==='healer'){
        if(gameState.spiritStones<20){gameState.familyPregnancies.push(pregnancy);return 'Không đủ 20 linh thạch mời y sư; sự kiện sẽ được hỏi lại.';}
        gameState.spiritStones-=20;table=[.96,.03,.008,.002];
      }else if(method==='pill'){
        if(gameState.anThaiPills<1){gameState.familyPregnancies.push(pregnancy);return 'Không có An Thai Đan; hãy chọn phương án khác.';}
        gameState.anThaiPills--;table=[.98,.015,.004,.001];
      }
      // Tu vi cao và tu luyện vững hỗ trợ sinh nở, nhưng không loại bỏ hẳn hiểm nguy.
      const resilience=Math.min(.015,Math.max(0,mother.realmIdx)*.002);
      table[0]+=resilience;table[1]=Math.max(0,table[1]-resilience);
      const roll=Math.random();let kind='safe',cum=0;
      for(const [i,prob] of table.entries()){cum+=prob;if(roll<cum){kind=['safe','complication','loss','fatal'][i];break;}}
      let result='';
      if(kind==='safe'||kind==='complication'){
        const gender=Math.random()<.5?'male':'female';
        const child=createMember({name:generateTwoCharName(gender,gameState.clanSurname),gender,age:0,
          generation:Math.max(father.generation,mother.generation)+1,realmIdx:0,parentId:father.isMarriedIn?mother.id:father.id,
          biologicalFatherId:father.id,biologicalMotherId:mother.id,lineageType:'birth'});
        child.careGuardianId=mother.id;
        gameState.members.push(child);rebuildMemberIndex();
        result=`${mother.name} sinh hạ ${child.name} (${child.spiritRoot.name}), mẹ con ${kind==='safe'?'bình an':'gặp biến chứng nhưng đã qua nguy hiểm'}.`;
        if(kind==='complication'){mother.innerDemon=Math.min(100,(mother.innerDemon||0)+4);mother.familyBond=Math.max(0,(mother.familyBond||40)-3);}
      }else if(kind==='loss'){
        mother.innerDemon=Math.min(100,(mother.innerDemon||0)+8);father.innerDemon=Math.min(100,(father.innerDemon||0)+4);
        result=`${mother.name} qua cơn hiểm nghèo nhưng thai nhi không giữ được. Gia tộc ghi lại biến cố đau buồn.`;
      }else{
        // Trường hợp cực hiếm: người mẹ gặp tử kiếp. Con không sống sót.
        mother.alive=false;mother.deathYear=gameState.year;
        if(gameState.activeCultivatorId===mother.id)gameState.activeCultivatorId=null;
        if(gameState.clanLeaderId===mother.id){s3fSealLeaderLegacy(mother);gameState.clanLeaderId=null;}
        if(gameState.heirId===mother.id)gameState.heirId=null;
        gameState.squadIds=gameState.squadIds.filter(id=>id!==mother.id);
        gameState.estates.forEach(e=>{if(Number(e.guardianId)===mother.id)e.guardianId=null;});
        father.innerDemon=Math.min(100,(father.innerDemon||0)+12);
        result=`${mother.name} gặp tử kiếp khi lâm bồn, mẹ và con đều không qua khỏi.`;
        ensureClanLeadership();s3c2RefreshChildCare();
      }
      const record=`Năm ${gameState.year}, tháng ${gameState.month}: ${result}`;
      gameState.familyBirthHistory.push(record);gameState.familyBirthHistory=gameState.familyBirthHistory.slice(-100);
      addHistory(record);setTicker('👶 '+result);markGameDirty();return result;
    }
    function s3f41ApproveConception(parent,approve){
      const c=s3f41Couple(parent);if(!c)return 'Cặp đạo lữ không còn đủ điều kiện cầu tự.';
      const key=s3f41CoupleKey(c.father.id,c.mother.id);
      gameState.familyRequests=gameState.familyRequests.filter(r=>!(r.fatherId===c.father.id&&r.motherId===c.mother.id));
      gameState.familyRequestCooldowns[key]=getMonthIndex();
      if(!approve)return `Gia Chủ tạm hoãn cầu tự của ${c.father.name} và ${c.mother.name}. Sau ít nhất 12 tháng họ mới có thể xin phép lại.`;
      if(!s3f41CanConceive(c))return 'Gia tộc thiếu chỗ ở, đã đủ ba con hoặc cặp đạo lữ có thai kỳ khác; không thể bắt đầu thai kỳ.';
      const now=getMonthIndex();gameState.familyPregnancies.push({fatherId:c.father.id,motherId:c.mother.id,conceived:now,due:now+9,approved:true});
      addHistory(`Năm ${gameState.year}, tháng ${gameState.month}: Gia Chủ chuẩn y cầu tự cho ${c.father.name} và ${c.mother.name}; dự sinh sau 9 tháng.`);
      return `Gia Chủ đã chuẩn y. ${c.mother.name} bước vào thai kỳ chín tháng; khi lâm bồn sẽ lại xin quyết định của Gia Chủ.`;
    }
    function s3f41DispatchFamily(){
      if(!gameState.started||gameState.pendingAdventure||battleState||gameState.clanExtinct)return false;
      const now=getMonthIndex();
      // Lâm bồn ưu tiên tuyệt đối trước kỳ ngộ khác.
      for(const p of gameState.familyPregnancies){
        if(p.due>now)continue;
        const mother=getValidLivingMember(p.motherId);
        if(!mother){gameState.familyPregnancies=gameState.familyPregnancies.filter(x=>x!==p);continue;}
        gameState.pendingAdventure={eventId:'s3f41_birth',memberId:mother.id,context:{},createdAtMonthIndex:now};
        renderAdventureModal();markGameDirty();return true;
      }
      gameState.familyRequests=gameState.familyRequests||[];
      for(let i=0;i<gameState.familyRequests.length;i++){
        const r=gameState.familyRequests[i],father=getValidLivingMember(r.fatherId),mother=getValidLivingMember(r.motherId);
        const main=father&&!father.isMarriedIn?father:mother;
        const c=s3f41Couple(main);
        if(!c||!s3f41CanConceive(c)){gameState.familyRequests.splice(i--,1);continue;}
        gameState.pendingAdventure={eventId:'s3f41_request',memberId:main.id,context:{},createdAtMonthIndex:now};
        renderAdventureModal();markGameDirty();return true;
      }
      return false;
    }
    function getAliveCount() {
      return gameState.members.filter(member => member.alive).length;
    }

    function getMaxAbodeCapacity() {
      return 6 * Math.pow(2, Math.max(0, gameState.abodeLevel - 1));
    }

    function recalcTeamMaxHp() {
      const validIds = [...new Set((gameState.squadIds || []).map(Number))]
        .filter(id => {
          const member = getValidLivingMember(id);
          return Boolean(member);
        }).slice(0, GAME_CONFIG.maxSquadSize);
      gameState.squadIds = validIds;
      if (!getValidLivingMember(gameState.activeCultivatorId)) {
        gameState.activeCultivatorId = validIds[0] || gameState.members.find(member => member.alive)?.id || null;
      }
      if (validIds.length === 0 && gameState.activeCultivatorId != null) {
        gameState.squadIds = [gameState.activeCultivatorId];
      }
      const squadMembers = gameState.squadIds.map(getMemberById).filter(Boolean);
      const totalMax = squadMembers.reduce((sum, member) => sum + getMemberStats(member).hp, 0);
      gameState.teamMaxHp = Math.max(80, totalMax);
      gameState.teamHp = safeNumber(gameState.teamHp, gameState.teamMaxHp, 0, gameState.teamMaxHp);
    }

    function showClanExtinctionModal() {
      if (!gameState.clanExtinct) return;
      const canRescue = !gameState.clanRescueUsed;
      const body = `
        <div class="text-center space-y-3">
          <div class="text-3xl">🕯️</div>
          <p class="text-xs leading-relaxed text-slate-700">Toàn bộ tộc nhân đã tọa hóa. Đạo thống có thể được tiếp nối bởi một nghĩa tử ngoại tộc; lựa chọn này chỉ sử dụng một lần trong tiến trình.</p>
          ${canRescue ? `<button onclick="continueWithAdoptedHeir()" class="w-full bg-emerald-700 text-white font-extrabold py-2.5 rounded-xl text-xs">Nhận nghĩa tử kế thừa miễn phí</button>` : `<p class="text-xs font-bold text-rose-700">Cơ hội cứu nguy đã sử dụng. Đây là hồi kết của gia tộc.</p>`}
          <button onclick="closeGenericModal()" class="w-full bg-slate-200 text-slate-800 font-bold py-2 rounded-xl text-xs">Đóng</button>
        </div>
      `;
      openGenericModal("⚰️ Gia Tộc Tuyệt Tự", body, true);
    }

    function continueWithAdoptedHeir() {
      if (!gameState.clanExtinct || gameState.clanRescueUsed || getAliveCount() > 0) return;
      const gender = Math.random() < 0.5 ? "male" : "female";
      const maxGeneration = Math.max(1, ...gameState.members.map(member => member.generation));
      const heir = createMember({
        name: generateTwoCharName(gender, gameState.clanSurname),
        gender,
        age: 16,
        generation: maxGeneration + 1,
        realmIdx: 1,
        isFounder: false,
        lineageType: "adopted"
      });
      heir.role = "Tộc Trưởng";
      gameState.members.push(heir);
      gameState.clanExtinct = false;
      gameState.clanRescueUsed = true;
      gameState.activeCultivatorId = heir.id;
      gameState.squadIds = [heir.id];
      gameState.clanLeaderId = heir.id;
      gameState.heirId = null;
      rebuildMemberIndex();
      recalcTeamMaxHp();
      gameState.teamHp = gameState.teamMaxHp;
      addHistory(`Năm ${gameState.year}: ${heir.name} được nhận làm nghĩa tử, kế thừa đạo thống sau biến cố tuyệt tự.`);
      closeGenericModal();
      gameState.paused = false;
      updateAllUI();
      saveGameToLocal({ silent: true, closeModal: false });
      showToast(`🌱 Đạo thống được tiếp nối bởi ${heir.name}.`);
    }

    // =========================================================================
    // 9. CÂY GIA PHẢ ĐA THẾ HỆ CÓ VỢ/CHỒNG CHO CON CHÁU + ZOOM/PAN
    // =========================================================================
    function renderFamilyTree() {
      const container = document.getElementById("treeNodesContainer");
      const svg = document.getElementById("treeLinesSvg");
      if (!container || !svg) return;

      const mainMembers = gameState.members.filter(m => !m.isMarriedIn);
      const gens = {};
      mainMembers.forEach(m => {
        if (!gens[m.generation]) gens[m.generation] = [];
        gens[m.generation].push(m);
      });

      const CARD_W = 110;
      const CARD_H = 154;
      const SPOUSE_GAP = 9;
      const UNIT_GAP = 24;
      const ROW_GAP = 44;
      const positions = {};
      let maxWidth = 360;
      const genKeys = Object.keys(gens).map(Number).sort((a, b) => a - b);
      const rowUnits = {};

      genKeys.forEach(g => {
        const list = gens[g];
        let rowW = 0;
        const units = list.map(m => {
          const spouse = m.spouseId ? getMemberById(m.spouseId) : null;
          const uWidth = spouse ? (CARD_W * 2 + SPOUSE_GAP) : CARD_W;
          rowW += uWidth;
          return { main: m, spouse, width: uWidth };
        });
        rowW += Math.max(0, units.length - 1) * UNIT_GAP;
        if (rowW + 72 > maxWidth) maxWidth = rowW + 72;
        rowUnits[g] = { units, totalWidth: rowW };
      });

      let html = "";
      let linesHtml = "";
      genKeys.forEach((g, rowIndex) => {
        const { units, totalWidth } = rowUnits[g];
        let curX = (maxWidth - totalWidth) / 2;
        const curY = 20 + rowIndex * (CARD_H + ROW_GAP);
        units.forEach(u => {
          positions[u.main.id] = { x: curX, y: curY, w: CARD_W, h: CARD_H };
          html += buildMemberCardHtml(u.main, curX, curY);
          if (u.spouse) {
            const spX = curX + CARD_W + SPOUSE_GAP;
            positions[u.spouse.id] = { x: spX, y: curY, w: CARD_W, h: CARD_H };
            html += buildMemberCardHtml(u.spouse, spX, curY);
            const lineY = curY + 78;
            linesHtml += `<line x1="${curX + CARD_W}" y1="${lineY}" x2="${spX}" y2="${lineY}" stroke="#b56c83" stroke-width="2.5" stroke-dasharray="4 3"/>`;
            linesHtml += `<circle cx="${curX + CARD_W + SPOUSE_GAP / 2}" cy="${lineY}" r="4" fill="#d98a9d"/>`;
          }
          curX += u.width + UNIT_GAP;
        });
      });

      mainMembers.forEach(child => {
        if (!child.parentId || !positions[child.parentId] || !positions[child.id]) return;
        const pPos = positions[child.parentId];
        const parentObj = getMemberById(child.parentId);
        const spPos = (parentObj && parentObj.spouseId && positions[parentObj.spouseId])
          ? positions[parentObj.spouseId] : null;
        const startX = spPos ? (pPos.x + CARD_W + SPOUSE_GAP / 2) : (pPos.x + CARD_W / 2);
        const startY = spPos ? (pPos.y + 78) : (pPos.y + CARD_H);
        const cPos = positions[child.id];
        const endX = cPos.x + CARD_W / 2;
        const endY = cPos.y;
        const midY = pPos.y + CARD_H + ROW_GAP / 2;
        linesHtml += `<path d="M ${startX} ${startY} L ${startX} ${midY} L ${endX} ${midY} L ${endX} ${endY}" fill="none" stroke="#a9823d" stroke-width="2.8" stroke-linecap="round"/>`;
        linesHtml += `<circle cx="${endX}" cy="${endY}" r="3" fill="#d7b56d"/>`;
      });

      const totalHeight = Math.max(440, genKeys.length * (CARD_H + ROW_GAP) + 76);
      container.style.width = `${maxWidth}px`;
      container.style.height = `${totalHeight}px`;
      svg.setAttribute("width", maxWidth);
      svg.setAttribute("height", totalHeight);
      svg.innerHTML = linesHtml;
      container.innerHTML = html;
      applyTreeTransform();
    }

    function buildMemberCardHtml(m, x, y) {
      const genderClass = m.gender === "male" ? "male" : "female";
      const founderClass = m.isFounder ? "founder" : "";
      const deadClass = !m.alive ? "dead" : "";
      const realmName = REALMS[m.realmIdx]?.name || "Phàm Nhân";
      const roleTag = m.alchemyLevel > 0
        ? `Đan Sư ${m.alchemyLevel}`
        : (m.role !== "Tộc Nhân" ? m.role : "");
      const plaque = m.isFounder ? "Tộc Chủ" : (m.isMarriedIn ? "Đạo Lữ" : `Đời ${m.generation}`);
      const subtitle = !m.alive
        ? "Đã tọa hóa"
        : (m.isFounder ? "Khai Tộc Tổ Sư" : (m.isMarriedIn ? "Phu Nhân / Đạo Lữ" : (roleTag || "Hậu Duệ")));
      const age = Math.max(0, Number(m.age) || 0);

      return `
        <button type="button"
          onclick="openMemberDetailModal(${Number(m.id)})"
          aria-label="Xem hồ sơ ${escapeHtml(m.name)}"
          style="position:absolute;left:${x}px;top:${y}px;"
          class="member-card ${genderClass} ${founderClass} ${deadClass} member-card-ornate">
          <span class="member-card-plaque">${escapeHtml(plaque)}</span>
          <span class="member-card-age">${age} tuổi</span>
          <span class="member-card-portrait">${getCharacterSvg(m, 88)}</span>
          <span class="member-card-name">${escapeHtml(m.name)}</span>
          <span class="member-card-subtitle">${escapeHtml(subtitle)}</span>
          <span class="member-card-realm">${escapeHtml(realmName)}</span>
        </button>
      `;
    }

    // Xử lý kéo thả & phóng to thu nhỏ Cây Gia Phả
    function clampTreePan() {
      const viewport=document.getElementById('treeViewport');
      const canvas=document.getElementById('treeNodesContainer');
      if(!viewport||!canvas)return;
      const width=(parseFloat(canvas.style.width)||canvas.scrollWidth||360)*treeTransform.scale;
      const height=(parseFloat(canvas.style.height)||canvas.scrollHeight||420)*treeTransform.scale;
      const vx=viewport.clientWidth,vy=viewport.clientHeight;
      const clamp=(position,total,available)=>{
        if(total<=available-24)return (available-total)/2;
        return Math.min(24,Math.max(available-total-24,position));
      };
      treeTransform.x=clamp(treeTransform.x,width,vx);
      treeTransform.y=clamp(treeTransform.y,height,vy);
    }

    // Sprint 2J: thống nhất Pointer Events cho chuột / 1 ngón / 2 ngón.
    // Di chuyển từ thẻ vẫn kéo được, nhưng chạm nhẹ thẻ vẫn mở Ngọc Giản.
    function initTreePanZoom() {
      const vp = document.getElementById("treeViewport");
      if (!vp || vp.dataset.panZoomBound === "1") return;
      vp.dataset.panZoomBound = "1";
      const pointers = new Map();
      let gesture = null;
      let dragged = false;
      let blockNextClick = false;
      let clickGuardUntil = 0;
      const localPoint = e => {
        const r = vp.getBoundingClientRect();
        return {x:e.clientX-r.left,y:e.clientY-r.top};
      };
      const updateZoomAnchor = () => {
        const pts = [...pointers.values()];
        if (pts.length < 2) return;
        const a=pts[0],b=pts[1];
        const midX=(a.x+b.x)/2,midY=(a.y+b.y)/2;
        gesture = {type:'pinch', distance:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),
          scale:treeTransform.scale,
          contentX:(midX-treeTransform.x)/treeTransform.scale,
          contentY:(midY-treeTransform.y)/treeTransform.scale};
        dragged = true;
      };
      vp.addEventListener('pointerdown', e => {
        if (e.pointerType==='mouse' && e.button!==0) return;
        const point=localPoint(e);
        pointers.set(e.pointerId,{...point,startX:point.x,startY:point.y});
        if (pointers.size===1) {
          dragged=false;
          gesture={type:'pan',startX:point.x,startY:point.y,baseX:treeTransform.x,baseY:treeTransform.y};
        } else if (pointers.size>=2) updateZoomAnchor();
        // Không setPointerCapture lên viewport khi chạm thẻ:
        // capture sẽ đổi click target, làm thẻ không mở được Ngọc Giản.
      });
      window.addEventListener('pointermove', e => {
        if (!pointers.has(e.pointerId)) return;
        const point=localPoint(e);
        const old=pointers.get(e.pointerId);
        pointers.set(e.pointerId,{...old,x:point.x,y:point.y});
        if (pointers.size>=2) {
          if (!gesture || gesture.type!=='pinch') updateZoomAnchor();
          const [a,b]=[...pointers.values()];
          const cx=(a.x+b.x)/2,cy=(a.y+b.y)/2;
          const dist=Math.max(1,Math.hypot(a.x-b.x,a.y-b.y));
          treeTransform.scale=Math.max(.55,Math.min(1.8,gesture.scale*dist/gesture.distance));
          treeTransform.x=cx-gesture.contentX*treeTransform.scale;
          treeTransform.y=cy-gesture.contentY*treeTransform.scale;
          dragged=true;
        } else if (gesture && gesture.type==='pan') {
          const dx=point.x-gesture.startX,dy=point.y-gesture.startY;
          if (dragged || Math.hypot(dx,dy)>7) {
            dragged=true;
            treeTransform.x=gesture.baseX+dx;
            treeTransform.y=gesture.baseY+dy;
          }
        }
        if (dragged) {clampTreePan();applyTreeTransform();}
      });
      const endPointer=e=>{
        if (!pointers.has(e.pointerId)) return;
        pointers.delete(e.pointerId);
        if (dragged) {blockNextClick=true;clickGuardUntil=Date.now()+350;}
        if (pointers.size>=2) updateZoomAnchor();
        else if (pointers.size===1) {
          const p=[...pointers.values()][0];
          gesture={type:'pan',startX:p.x,startY:p.y,baseX:treeTransform.x,baseY:treeTransform.y};
          dragged=true;
        } else {gesture=null;dragged=false;}
      };
      window.addEventListener('pointerup',endPointer);
      window.addEventListener('pointercancel',endPointer);

      vp.addEventListener('click',e=>{
        if(blockNextClick && Date.now()<clickGuardUntil){
          e.preventDefault();e.stopImmediatePropagation();blockNextClick=false;
        } else if(Date.now()>=clickGuardUntil){blockNextClick=false;}
      },true);
      vp.addEventListener('wheel',e=>{
        e.preventDefault();
        const point=localPoint(e),old=treeTransform.scale;
        const factor=e.deltaY<0?1.1:1/1.1;
        treeTransform.scale=Math.max(.55,Math.min(1.8,old*factor));
        treeTransform.x=point.x-(point.x-treeTransform.x)*treeTransform.scale/old;
        treeTransform.y=point.y-(point.y-treeTransform.y)*treeTransform.scale/old;
        clampTreePan();applyTreeTransform();
      },{passive:false});
    }

    function zoomTree(delta) {
      treeTransform.scale = +(Math.min(1.8, Math.max(0.55, treeTransform.scale + delta))).toFixed(2);
      clampTreePan();
      applyTreeTransform();
    }

    function centerTree() {
      const vp = document.getElementById("treeViewport");
      const container = document.getElementById("treeNodesContainer");
      const vpW = vp ? vp.clientWidth : 400;
      const contentW = container ? (parseFloat(container.style.width) || 360) : 360;
      treeTransform.scale = Math.min(1, Math.max(0.62, (vpW - 18) / contentW));
      treeTransform.x = Math.round((vpW - contentW * treeTransform.scale) / 2);
      treeTransform.y = 14;
      applyTreeTransform();
    }

    function applyTreeTransform() {
      const canvas = document.getElementById("treeCanvas");
      if (canvas) {
        canvas.style.transform = `translate(${treeTransform.x}px, ${treeTransform.y}px) scale(${treeTransform.scale})`;
      }
      const zoomBadge = document.getElementById("uiZoomLevel");
      if (zoomBadge) zoomBadge.textContent = `${Math.round(treeTransform.scale * 100)}%`;
    }

    // =========================================================================
    // 10. NGỌC GIẢN THUỘC TÍNH NHÂN VẬT (8 CHỈ SỐ & KẾT HÔN CHO CON CHÁU)
    // =========================================================================
    function s3aMemberChronicle(m){
      const rows=(gameState.s3aChronicle||[]).filter(e=>e.memberId===m.id).slice(-5).reverse();
      return `<details class="bg-amber-50 border border-amber-300/70 rounded-xl p-2.5 text-[11px]">
        <summary class="font-extrabold text-emerald-950 cursor-pointer">📜 Dấu Ấn Cuộc Đời · ${rows.length} biến cố gần nhất</summary>
        <div class="space-y-1.5 mt-2">${rows.length?rows.map(e=>`<div class="bg-white rounded-lg p-2 border border-amber-100"><b>${escapeHtml(e.title)}</b> · Năm ${e.year}<p class="text-slate-600">${escapeHtml(e.result)}</p></div>`).join(''):'Chưa ghi nhận biến cố Thiên Mệnh nào.'}</div>
      </details>`;
    }
    // Sprint 3C.3 — Một nhân quả thiếu niên, hiệu quả dài hạn khi đủ 16 tuổi.
    // Không thay thế sự kiện Kỳ Ngộ ngẫu nhiên; đây là lựa chọn chủ động ở Ngọc Giản.
    const S3C3_CHOICES = Object.freeze({
      trust:{title:'Tin tưởng con trẻ',cost:10,bond:14,description:'Dành thời gian lắng nghe. Tình thân tăng mạnh; tới tuổi 16 nhận thêm căn cơ.'},
      discipline:{title:'Rèn luyện nghiêm khắc',cost:22,bond:-5,description:'Đầu tư thầy và tài nguyên. Nhận thêm phòng thủ và tu vi khi trưởng thành, nhưng tình thân giảm nhẹ.'},
      explore:{title:'Cho ra ngoài lịch luyện',cost:12,bond:4,description:'Tạo cơ hội trải nghiệm. Khi đủ tuổi, nhận tốc độ và khả năng lĩnh ngộ.'}
    });
    function s3c3EligibleChild(m) {
      return !!(m && m.alive && !m.isMarriedIn && m.age >= 8 && m.age < 16);
    }
    function s3c3OpenFamilyTrial(memberId){
      const child=getValidLivingMember(memberId);
      if(!s3c3EligibleChild(child)) return showToast('Gia sự thiếu niên chỉ dành cho hậu duệ từ 8 đến 15 tuổi.');
      if(child.familyTrial) return showToast('Hậu duệ này đã trải qua biến cố trưởng thành.');
      const caretaker=getValidLivingMember(child.careGuardianId)||s3c2FindGuardian(child);
      const mentor=getValidLivingMember(child.mentorId);
      const body=`<div class="space-y-3 text-xs"><p class="leading-relaxed"><b>${escapeHtml(child.name)}</b> đang ở ngã rẽ tuổi thiếu niên. ${caretaker?'Người giám hộ '+escapeHtml(caretaker.name)+' đang chờ quyết định của gia tộc.':'Gia tộc trực tiếp đảm nhận trách nhiệm giáo dưỡng.'} ${mentor?'Sư phụ '+escapeHtml(mentor.name)+' có thể cùng chỉ dẫn.':''}</p>
        <p class="text-amber-800 font-bold">Đây là quyết định duy nhất cho mỗi hậu duệ; kết quả sẽ được ghi nhận khi 16 tuổi.</p>
        ${Object.entries(S3C3_CHOICES).map(([key,v])=>`<button type="button" onclick="s3c3ChooseFamilyTrial(${child.id},'${key}')" class="w-full text-left bg-white border border-emerald-300 rounded-xl p-3"><b class="text-emerald-900">${v.title} · ${v.cost} 💎</b><span class="block text-[11px] mt-1 text-slate-600">${v.description}</span></button>`).join('')}</div>`;
      openGenericModal('🌿 Gia Sự Thiếu Niên',body);
    }
    function s3c3ChooseFamilyTrial(memberId,choice){
      return showToast('Gia sự Thiếu Niên sẽ đến theo Thiên Cơ, không cần mở trong Ngọc Giản.');
      const child=getValidLivingMember(memberId), cfg=S3C3_CHOICES[choice];
      if(!cfg||!s3c3EligibleChild(child)||child.familyTrial) return showToast('Quyết định gia sự không còn hợp lệ.');
      if(gameState.spiritStones < cfg.cost) return showToast(`Cần ${cfg.cost} Linh thạch.`);
      gameState.spiritStones -= cfg.cost;
      child.familyBond=Math.max(0,Math.min(100,(child.familyBond??40)+cfg.bond));
      child.familyTrial={choice,year:gameState.year,mentorId:child.mentorId??null,resolved:false};
      addHistory(`Năm ${gameState.year}: ${child.name} trải qua gia sự '${cfg.title}', tình thân ${child.familyBond}/100; đến năm 16 tuổi sẽ ứng nghiệm.`);
      markGameDirty();markAllViewsDirty();updateAllUI();
      saveGameToLocal({silent:true,closeModal:false});
      openMemberDetailModal(child.id);
    }
    function s3c3ResolveComingOfAge(){
      for(const child of gameState.members){
        const story=child.familyTrial;
        if(!child.alive||child.age<16||!story||story.resolved)continue;
        // Đánh dấu trước khi trao thưởng, tránh nhận hai lần sau lưu/tải hoặc lặp năm.
        story.resolved=true;
        const mentor=getValidLivingMember(story.mentorId);
        const guideBonus=mentor && mentor.id===child.mentorId ? 1:0;
        let reward='';
        if(story.choice==='trust'){
          child.bonusHp+=12+4*guideBonus;
          child.innerDemon=Math.max(0,child.innerDemon-5);
          reward='sinh lực tăng, đạo tâm vững hơn';
        }else if(story.choice==='discipline'){
          child.bonusDef+=4+guideBonus;
          addXp(child,18+6*guideBonus);
          reward='phòng thủ và tu vi tăng';
        }else if(story.choice==='explore'){
          child.bonusSpd+=3+guideBonus;
          child.crit=Math.min(100,child.crit+0.5);
          reward='tốc độ và bạo kích tăng';
        }
        addHistory(`Năm ${gameState.year}: ${child.name} trưởng thành, nhân quả '${S3C3_CHOICES[story.choice].title}' ứng nghiệm: ${reward}.`);
        setTicker(`🌱 ${child.name} trưởng thành: ${reward}.`);
        markGameDirty();
      }
    }
    function s3c3TransmitTeaching(memberId){
      return showToast('Truyền công sẽ xuất hiện qua Thiên Cơ khi đủ duyên.');
      const disciple=getValidLivingMember(memberId);
      if(!disciple||disciple.age<16||disciple.inheritedTeaching)return showToast('Không đủ điều kiện nhận truyền công.');
      const mentor=getValidLivingMember(disciple.mentorId);
      if(!mentor||mentor.id===disciple.id||mentor.age<18||mentor.realmIdx<3)return showToast('Cần sư phụ còn sống, có cảnh giới từ Luyện Khí 3.');
      if((disciple.familyBond??40)<60)return showToast('Cần Tình Thân ít nhất 60.');
      if(gameState.spiritStones<35)return showToast('Cần 35 Linh thạch cho nghi thức truyền công.');
      gameState.spiritStones-=35;
      disciple.inheritedTeaching=true;
      const gain=Math.min(90,20+mentor.realmIdx*4);
      addXp(disciple,gain);
      disciple.bonusAtk+=Math.min(6,1+Math.floor(mentor.realmIdx/4));
      disciple.familyBond=Math.min(100,disciple.familyBond+5);
      addHistory(`Năm ${gameState.year}: ${mentor.name} truyền đạo cho ${disciple.name}; +${gain} tu vi và thêm tấn công. Tình thầy trò thêm sâu nặng.`);
      markGameDirty();markAllViewsDirty();recalcTeamMaxHp();updateAllUI();
      saveGameToLocal({silent:true,closeModal:false});
      openMemberDetailModal(disciple.id);
    }
    function s3c3FamilyStoryPanel(m){
      if(m.isMarriedIn)return '';
      const trial=m.familyTrial, mentor=getMemberById(m.mentorId);
      const trialTitle=trial?S3C3_CHOICES[trial.choice]?.title||'Gia sự':'';
      const isChild=s3c3EligibleChild(m);
      const canLearn=m.alive&&m.age>=16&&mentor?.alive&&m.familyBond>=60&&!m.inheritedTeaching;
      return `<details class="bg-teal-50 rounded-xl border border-teal-300 p-2.5 text-[11px]" open>
       <summary class="font-extrabold text-emerald-950 cursor-pointer">🌱 Nhân Quả & Truyền Thừa</summary>
       <div class="mt-2 space-y-2"><p class="text-slate-700">Tình thân <b>${m.familyBond??40}/100</b> · ${trial?`Gia sự: <b>${escapeHtml(trialTitle)}</b> (${trial.resolved?'đã ứng nghiệm':'chờ trưởng thành'})`:'Chưa có gia sự thiếu niên'} · ${m.inheritedTeaching?'Đã nhận truyền công':'Chưa nhận truyền công'}</p>
       ${isChild&&!trial?'<p class="text-emerald-800">🌿 Gia sự sẽ tự xuất hiện theo đạo lịch khi đến duyên.</p>':''}
       ${canLearn?'<p class="text-indigo-800">📜 Cơ duyên truyền công sẽ tự xuất hiện khi đủ điều kiện.</p>':''}</div></details>`;
    }
    // Sprint 3C.3: giáo dưỡng là quyết định của gia tộc, không tự động random mỗi tháng.
    // Một lượt / năm, tối đa 6 lượt và chỉ dành cho tộc nhân dưới 16 tuổi.
    // Sprint 3C.3 — chăm sóc tách khỏi huyết thống: parentId không bao giờ bị đổi.
    function s3c2IsAdultCaretaker(m, child) {
      return !!(m && m.alive && m.id !== child.id && m.age >= 18 && m.age - child.age >= 12);
    }
    function s3c2FindGuardian(child) {
      const choices = [child.adoptiveParentId, child.parentId, child.biologicalFatherId, child.biologicalMotherId, gameState.clanLeaderId];
      for (const id of choices) {
        const m = id == null ? null : getMemberById(id);
        if (s3c2IsAdultCaretaker(m, child)) return m;
      }
      return gameState.members.filter(m => s3c2IsAdultCaretaker(m,child) && !m.isMarriedIn)
        .sort((a,b) => a.generation-b.generation || b.realmIdx-a.realmIdx || a.id-b.id)[0] || null;
    }
    function s3c2RefreshChildCare() {
      for (const child of gameState.members) {
        if (!child.alive || child.age >= 16 || child.isMarriedIn) continue;
        const current = getMemberById(child.careGuardianId);
        if (s3c2IsAdultCaretaker(current,child)) continue;
        const guardian = s3c2FindGuardian(child);
        if (child.careGuardianId !== (guardian?.id ?? null)) {
          child.careGuardianId = guardian?.id ?? null;
          if (guardian) addHistory(`Năm ${gameState.year}: ${guardian.name} đảm nhận chăm sóc ${child.name} trong gia tộc.`);
        }
      }
    }
    function s3c2MentorCandidates(child) {
      const active = gameState.members.filter(m => m.alive && m.age >= 18 && m.id!==child.id && m.age-child.age>=10);
      return active.filter(m => m.id === child.mentorId || gameState.members.filter(c => c.alive && c.age < 16 && c.mentorId === m.id && c.id!==child.id).length < 3);
    }
    function s3c2OpenMentorModal(childId) {
      return showToast('Bái sư nay được định qua Thiên Cơ, không mở thủ công.');
      const child = getValidLivingMember(childId);
      if (!child || child.age >= 16) return showToast('Chỉ thu nhận đệ tử dưới 16 tuổi.');
      const options = s3c2MentorCandidates(child);
      const cards = options.map(m => `<button type="button" onclick="s3c2AssignMentor(${child.id},${m.id})" class="w-full flex items-center gap-2 p-2 bg-white border border-violet-300 rounded-xl text-left text-xs">
        ${getCharacterSvg(m,36)}<span class="flex-1"><b>${escapeHtml(m.name)}</b> · ${escapeHtml(REALMS[m.realmIdx]?.name||'Phàm Nhân')}<br>Đan đạo ${m.alchemyLevel||0} · ${m.id===child.mentorId?'Đang là sư phụ':'Chọn làm sư phụ'}</span></button>`).join('');
      openGenericModal('📚 Bái Sư — '+escapeHtml(child.name), `<p class="text-xs mb-2 text-slate-700">Mỗi sư phụ nhận tối đa 3 đệ tử dưới 16 tuổi. Sư phụ có tu vi và chuyên môn phù hợp sẽ tăng hiệu quả giáo dưỡng.</p><div class="space-y-2 max-h-80 overflow-y-auto">${cards||'<p>Chưa có sư phụ phù hợp.</p>'}</div><button onclick="s3c2AssignMentor(${child.id},null)" class="w-full bg-slate-200 p-2 rounded-lg text-xs font-bold mt-2">Không chọn sư phụ</button>`);
    }
    function s3c2AssignMentor(childId, mentorId) {
      return showToast('Sư đồ được xác lập bởi cơ duyên, không thể đổi tùy ý.');
      const child = getValidLivingMember(childId);
      if (!child || child.age >= 16) return showToast('Đệ tử không hợp lệ.');
      if (mentorId != null && !s3c2MentorCandidates(child).some(m=>m.id===mentorId)) return showToast('Sư phụ không còn đủ điều kiện.');
      child.mentorId = mentorId;
      child.familyBond = Math.min(100,(child.familyBond||40)+ (mentorId==null?0:3));
      const mentor = mentorId == null ? null : getMemberById(mentorId);
      addHistory(`Năm ${gameState.year}: ${child.name} ${mentor?'bái '+mentor.name+' làm sư phụ':'tạm ngừng bái sư'}.`);
      markGameDirty(); markAllViewsDirty(); updateAllUI();
      saveGameToLocal({silent:true,closeModal:false});
      openMemberDetailModal(child.id);
    }
    function s3c2LessonBonus(child, kind) {
      const mentor = getMemberById(child.mentorId);
      if (!mentor || !mentor.alive || mentor.age < 18) return 0;
      let score = Math.min(3,Math.floor(Math.max(0,mentor.realmIdx)/3));
      if (kind==='dan') score += Math.min(3,Math.floor((mentor.alchemyLevel||0)/2));
      if (kind==='kiem') score += Math.min(2,Math.floor(Math.max(0,mentor.bonusAtk||0)/25));
      return Math.min(5,Math.max(1,score));
    }
    const S3B_EDUCATION = {
      dao:{name:'Đạo Học',desc:'Tu vi và dưỡng tâm',cost:18},
      dan:{name:'Đan Học',desc:'Căn cơ, sinh lực, y lý',cost:22},
      kiem:{name:'Kiếm Học',desc:'Tấn công, tốc độ',cost:22}
    };
    function s3bFamilyEducation(m){
      if(!m.alive || m.age>=16 || m.isMarriedIn) return '';
      const lessons=Math.min(6,Math.max(0,m.educationLessons||0));
      const current=S3B_EDUCATION[m.educationPath];
      const carer = getMemberById(m.careGuardianId) || s3c2FindGuardian(m);
      const mentor = getMemberById(m.mentorId);
      const guide = carer?.alive?`Người giám hộ: ${escapeHtml(carer.name)}.`:'Gia tộc chưa có người giám hộ phù hợp.';
      const master = mentor?.alive?escapeHtml(mentor.name):'Chưa bái sư';
      return `<section class="bg-emerald-50/90 border border-emerald-300 rounded-2xl p-3 space-y-2">
        <div class="font-extrabold text-emerald-950 text-sm">🌱 Giáo Dưỡng Hậu Duệ</div>
        <p class="text-[11px] text-emerald-900">${guide} · Tình thân <b>${m.familyBond??40}/100</b><br>Sư phụ: <b>${master}</b> · Định hướng: <b>${current?current.name:'Chưa chọn'}</b> · ${lessons}/6 khóa.</p>
        <p class="text-[10px] text-slate-700">📜 Bái sư và hướng học được quyết định qua Thiên Cơ một lần; không thể chỉnh sửa tùy ý.</p>
        <p class="text-[10px] text-slate-600">${lessons>=6?'Đã hoàn thành giáo dưỡng.':current?'Tự học một khóa mỗi năm khi gia tộc đủ linh thạch.':'Chờ cơ duyên định hướng giáo dưỡng.'}</p>
      </section>`;
    }
    function s3bEducateChild(memberId,kind){
      return showToast('Giáo dưỡng nay tự tiến triển theo năm, không cần bấm từng khóa.');
      const m=getValidLivingMember(memberId), course=S3B_EDUCATION[kind];
      if(!m||!course||m.age>=16||m.isMarriedIn) return showToast('Chỉ có thể giáo dưỡng hậu duệ dưới 16 tuổi.');
      if((m.educationLessons||0)>=6) return showToast('Tộc nhân đã hoàn thành tối đa 6 khóa giáo dưỡng.');
      if(m.lastEducationYear===gameState.year) return showToast('Mỗi năm chỉ được giáo dưỡng một lần.');
      if(gameState.spiritStones<course.cost) return showToast(`Cần ${course.cost} Linh thạch để giáo dưỡng.`);
      gameState.spiritStones-=course.cost;
      m.educationPath=kind;
      m.educationLessons=(m.educationLessons||0)+1;
      m.lastEducationYear=gameState.year;
      const bonus = s3c2LessonBonus(m,kind);
      const guardian = getMemberById(m.careGuardianId) || s3c2FindGuardian(m);
      m.familyBond = Math.min(100,(m.familyBond??40)+ (guardian?.alive?4:1) + (bonus>0?2:0));
      if(kind==='dao'){
        m.xp=Math.min(REALMS[m.realmIdx].maxXp,m.xp+12+bonus*3);
        m.innerDemon=Math.max(0,m.innerDemon-3);
        m.dodge=+(m.dodge+0.3).toFixed(1);
      } else if(kind==='dan'){
        m.bonusHp+=8+bonus*2; m.bonusDef+=2+Math.floor(bonus/2);
        m.lifesteal=+(m.lifesteal+0.25).toFixed(2);
      } else {
        m.bonusAtk+=3+bonus; m.bonusSpd+=2+Math.floor(bonus/2);
        m.crit=+(m.crit+0.25).toFixed(2);
      }
      addHistory(`Năm ${gameState.year}: ${m.name} hoàn thành khóa ${course.name} (${m.educationLessons}/6)${bonus>0?' với chỉ điểm của sư phụ':''}; tình thân ${m.familyBond}/100.`);
      markGameDirty(); markAllViewsDirty(); updateAllUI();
      saveGameToLocal({silent:true,closeModal:false});
      openMemberDetailModal(m.id);
      showToast(`🌱 ${m.name} đã hoàn thành ${course.name}.`);
    }

    // Sprint 3E.4 — Ngọc Giản tinh gọn: chỉ một thẻ nội dung mỗi lúc.
    function s3e4SelectMemberTab(tabName) {
      const known = ['overview','path','family','chronicle','manage'];
      if (!known.includes(tabName)) return;
      const root = document.getElementById('s3e4MemberRoot');
      if (!root) return;
      root.querySelectorAll('[data-s3e4-panel]').forEach(panel => {
        const active = panel.getAttribute('data-s3e4-panel') === tabName;
        panel.classList.toggle('hidden', !active);
        panel.style.display = active ? '' : 'none';
        panel.setAttribute('aria-hidden', active ? 'false' : 'true');
      });
      root.querySelectorAll('[data-s3e4-tab]').forEach(btn => {
        const active = btn.getAttribute('data-s3e4-tab') === tabName;
        btn.setAttribute('aria-selected', active ? 'true' : 'false');
        btn.className = 'rounded-xl px-2 py-2 text-[11px] font-extrabold min-h-[39px] transition-colors ' +
          (active ? 'bg-emerald-800 text-white shadow-sm' : 'bg-white text-emerald-900 border border-emerald-200');
      });
    }

    function openMemberDetailModal(memberId) {
      const m = getMemberById(memberId);
      if (!m) return;
      const stats = getMemberStats(m);
      const realm = REALMS[m.realmIdx];
      const spouse = m.spouseId ? getMemberById(m.spouseId) : null;
      const father = m.biologicalFatherId ? getMemberById(m.biologicalFatherId) : null;
      const mother = m.biologicalMotherId ? getMemberById(m.biologicalMotherId) : null;
      const adoptive = m.adoptiveParentId ? getMemberById(m.adoptiveParentId) : null;
      const carer = m.careGuardianId ? getMemberById(m.careGuardianId) : null;
      const mentor = m.mentorId ? getMemberById(m.mentorId) : null;
      const craft = s3eCraftOf(m);
      const trialTitle = m.familyTrial ? (S3C3_CHOICES[m.familyTrial.choice]?.title || 'Gia sự thiếu niên') : 'Chưa có';
      const chains = (gameState.s3dChains || []).filter(chain => chain.memberId === m.id);
      const majorReady = m.alive && s3e3IsMajorBoundary(m) && m.xp >= realm.maxXp;
      const majorWaiting = m.alive && s3e3IsMajorBoundary(m) && !majorReady;
      const realmStatus = !m.alive ? 'Đã tọa hóa' : majorReady ? '⚡ Đã đủ tu vi — chờ độ đại kiếp tại Động Phủ' :
        majorWaiting ? '🧘 Đang tu luyện tới ngưỡng đại kiếp' :
        m.realmIdx >= REALMS.length - 1 ? '✨ Đã đạt cảnh giới cao nhất' : '🌿 Tiểu cảnh giới tự đột phá theo thời gian';
      const statTiles = [
        ['Sinh lực', stats.hp],['Tấn công',stats.atk],['Phòng thủ',stats.def],
        ['Tốc độ',stats.spd],['Bạo kích',stats.crit+'%'],['Né tránh',stats.dodge+'%'],
        ['Liên kích',stats.combo+'%'],['Hút máu',stats.lifesteal+'%']
      ].map(([name,value])=>`<div class="bg-white rounded-xl px-2 py-2 border border-emerald-100"><div class="text-[10px] text-slate-500">${name}</div><div class="text-xs font-extrabold text-emerald-950">${value}</div></div>`).join('');
      const actionButtons = m.alive ? `
        <div class="grid grid-cols-2 gap-2">
          <button onclick="nurtureMemberWithStones(${m.id})" class="bg-emerald-700 text-white font-bold py-2 rounded-xl text-[11px]">💎 Bồi dưỡng căn cơ</button>
          <button onclick="setAsActiveCultivator(${m.id})" class="bg-amber-500 text-slate-950 font-bold py-2 rounded-xl text-[11px]">⚡ Đến Động Phủ</button>
          ${(!m.spouseId && m.age >= 16 && !m.isMarriedIn) ? `<button onclick="openMarriageModal(${m.id})" class="bg-rose-700 text-white font-bold py-2 rounded-xl text-[11px]">💞 Kết đạo lữ</button>` : ''}
          ${(!m.isMarriedIn && m.age >= GAME_CONFIG.minMarriageAge && m.id !== gameState.clanLeaderId) ? `<button onclick="setClanHeir(${m.id})" class="bg-indigo-700 text-white font-bold py-2 rounded-xl text-[11px]">📜 Chỉ định kế vị</button>` : ''}
          <button onclick="trainMemberAlchemy(${m.id})" class="bg-purple-700 text-white font-bold py-2 rounded-xl text-[11px]">⚗️ Bồi dưỡng đan đạo</button>
          ${!m.isFounder ? `<button onclick="appointElder(${m.id})" class="bg-slate-700 text-white font-bold py-2 rounded-xl text-[11px]">🏛️ Bổ nhiệm trưởng lão</button>` : ''}
        </div>` : `<p class="text-center text-xs text-slate-500">Nhân vật đã tọa hóa năm ${m.deathYear}.</p>`;
      const kinship = m.lineageType === 'adopted' ? `Con nuôi · Cha/mẹ nuôi: ${escapeHtml(adoptive?.name || getMemberById(m.parentId)?.name || 'Không rõ')}` :
        m.lineageType === 'birth' ? `Con ruột · Cha: ${escapeHtml(father?.name || 'Không rõ')} · Mẹ: ${escapeHtml(mother?.name || 'Không rõ')}` :
        m.isFounder ? 'Khai tộc thủy tổ' : m.isMarriedIn ? 'Đạo lữ nhập tộc' : 'Chưa rõ thân thế';
      const tabLabels = [['overview','Tổng quan'],['path','Đạo lộ'],['family','Quan hệ'],['chronicle','Biên niên'],['manage','Điều hành']];
      const body = `<div id="s3e4MemberRoot" class="space-y-3 text-emerald-950">
        <section class="rounded-2xl border border-emerald-200 bg-white p-3">
          <div class="flex gap-3 items-center">
            <div class="shrink-0">${getCharacterSvg(m, 72)}</div>
            <div class="min-w-0 flex-1 space-y-1">
              <div class="text-base font-extrabold leading-tight break-words">${escapeHtml(m.name)}</div>
              <div class="text-[11px] text-slate-600">Đời ${m.generation} · ${m.age} tuổi · ${escapeHtml(m.role || 'Tộc nhân')}</div>
              <div class="text-xs font-bold text-amber-800">${escapeHtml(realm.name)}</div>
              <div class="text-[11px] text-purple-800">${escapeHtml(m.spiritRoot?.name || 'Không rõ linh căn')} · Chiến lực ${stats.power}</div>
              ${m.id === gameState.clanLeaderId ? '<span class="text-[10px] font-bold text-amber-800">👑 Tộc trưởng</span>' : m.id === gameState.heirId ? '<span class="text-[10px] font-bold text-indigo-800">📜 Người kế vị</span>' : ''}
            </div>
          </div>
          <div class="mt-2 rounded-lg px-2 py-1.5 text-[11px] font-semibold ${majorReady?'bg-amber-100 text-amber-950':'bg-emerald-50 text-emerald-900'}">${realmStatus}</div>
        </section>
        <nav class="grid grid-cols-3 gap-1.5" aria-label="Mục Ngọc Giản">
          ${tabLabels.map(([key,label])=>`<button type="button" data-s3e4-tab="${key}" role="tab" onclick="s3e4SelectMemberTab('${key}')">${label}</button>`).join('')}
        </nav>
        <section data-s3e4-panel="overview" role="tabpanel" class="space-y-3">
          <div class="rounded-2xl bg-emerald-50 border border-emerald-200 p-3 space-y-2">
            <div class="flex justify-between text-xs font-bold"><span>Tu vi</span><span>${Math.floor(m.xp)}/${realm.maxXp}</span></div>
            <div class="rounded-full bg-emerald-200 h-2 overflow-hidden"><div class="h-2 bg-emerald-700 rounded-full" style="width:${Math.min(100, Math.max(0, (m.xp/Math.max(1,realm.maxXp))*100))}%"></div></div>
            <div class="text-[11px] text-slate-600">${m.alive&&s3e3IsMajorBoundary(m)?'Vượt cảnh giới lớn cần chuẩn bị đan dược tại Động Phủ.':'Tu vi tích lũy tự nhiên theo tháng.'}</div>
          </div>
          <div class="grid grid-cols-2 gap-2">${statTiles}</div>
          <div class="rounded-xl bg-white border border-emerald-200 p-3 text-xs space-y-1"><b>Đạo lộ:</b> ${craft?escapeHtml(craft.name)+' · bậc '+s3eRank(m):m.age<16?'Đang trưởng thành':'Chưa định nghề / chuyên tu'}<br><b>Đạo lữ:</b> ${escapeHtml(spouse?.name || 'Chưa kết đôi')}<br><b>Nhân quả:</b> ${escapeHtml(trialTitle)} · <b>Thiên mệnh:</b> ${chains.length} tuyến</div>
        </section>
        <section data-s3e4-panel="path" role="tabpanel" class="hidden space-y-3">
          ${s3eMemberPanel(m)}
          ${s3bFamilyEducation(m)}
          ${m.age>=16 ? '<div class="text-[11px] bg-white p-3 rounded-xl border border-emerald-200">Đạo lộ đã chọn được giữ cố định. Nghề nghiệp và giáo dưỡng tiến triển theo thời gian; chỉ biến cố đặc biệt mới có thể đổi hướng.</div>' : ''}
        </section>
        <section data-s3e4-panel="family" role="tabpanel" class="hidden space-y-3">
          <div class="bg-white border border-emerald-200 rounded-xl p-3 text-[11px] space-y-2">
            <div><b>Thân thế:</b> ${kinship}</div>
            <div><b>Đạo lữ:</b> ${escapeHtml(spouse?.name || 'Chưa kết đôi')}${spouse&&m.maritalHarmony!=null?' · Hòa hợp '+m.maritalHarmony+'/100':''}</div>
            ${gameState.familyPregnancies.filter(p=>p.fatherId===m.id||p.motherId===m.id).map(p=>`<div class="bg-rose-50 border border-rose-200 rounded-lg p-2"><b>Gia Đạo:</b> Thai kỳ được Gia Chủ phê duyệt; dự sinh sau ${Math.max(0,p.due-getMonthIndex())} tháng. Đến kỳ sinh sẽ có Thiên Cơ.</div>`).join('')}
            <div class="text-slate-600"><b>Hộ sản:</b> Kho An Thai Đan: ${gameState.anThaiPills||0} viên · Gia Chủ phê duyệt từng lần cầu tự.</div>
            <div><b>Người giám hộ:</b> ${escapeHtml(carer?.name || 'Không có / không cần')}</div>
            <div><b>Sư phụ:</b> ${escapeHtml(mentor?.name || 'Chưa bái sư')}</div>
            <div><b>Tình thân:</b> ${Math.max(0, Math.min(100, Number(m.familyBond) || 0))}/100</div>
            <div class="rounded-lg bg-amber-50 p-2"><b>🔗 Liên kết:</b> Thân nhân, đạo lữ và sư đồ cùng vào Bí Cảnh tăng hiệp lực chiến đấu, tối đa 6%. Phân công Trấn Thủ tại Cơ Nghiệp để hỗ trợ tu luyện hoặc chiến lợi phẩm.</div>
            ${s3f3ArcSummary()?`<div class="rounded-lg bg-amber-50 p-2"><b>📜 Gia tộc ký sự:</b> ${escapeHtml(s3f3ArcSummary())}</div>`:''}
          </div>
          ${s3c3FamilyStoryPanel(m)}
          ${s3f1BloodlinePanel(m)}
        </section>
        <section data-s3e4-panel="chronicle" role="tabpanel" class="hidden space-y-3">
          ${s3fLegacyPanel(m)}
          ${s3dMemberPanel(m)}
          ${s3aMemberChronicle(m)}
        </section>
        <section data-s3e4-panel="manage" role="tabpanel" class="hidden space-y-3">
          <div class="text-[11px] bg-amber-50 border border-amber-200 rounded-xl p-3">Chỉ chứa các thao tác quản lý chủ động. Cơ duyên định mệnh, lựa chọn nghề và giáo dưỡng không điều chỉnh ở đây.</div>
          ${actionButtons}
        </section>
      </div>`;
      openGenericModal(`Ngọc Giản • ${m.name}`,body);
      s3e4SelectMemberTab('overview');
    }

    function nurtureMemberWithStones(memberId) {
      if (gameState.spiritStones < 25) return showToast("Không đủ 25 Linh thạch để bồi dưỡng!");
      const m = getValidLivingMember(memberId);
      if (!m) return showToast("Không thể bồi dưỡng người đã tọa hóa.");
      gameState.spiritStones -= 25;
      m.bonusHp += 25;
      m.bonusAtk += 5;
      m.bonusDef += 3;
      m.bonusSpd += 2;
      m.crit = +(m.crit + 0.4).toFixed(1);
      m.lifesteal = +(m.lifesteal + 0.3).toFixed(1);
      recalcTeamMaxHp();
      updateAllUI();
      openMemberDetailModal(memberId);
      showToast(`✨ Đã dùng Linh thạch tẩy kinh phạt tủy cho ${m.name}!`);
    }

    function setAsActiveCultivator(memberId) {
      const member = getValidLivingMember(memberId);
      if (!member) return showToast("Không thể đưa người đã tọa hóa vào Động Phủ.");
      gameState.activeCultivatorId = member.id;
      closeGenericModal();
      switchTab("cave");
    }

    function trainMemberAlchemy(memberId) {
      if (gameState.spiritStones < 40) return showToast("Cần 40 Linh thạch để mua đan phương bồi dưỡng!");
      const m = getValidLivingMember(memberId);
      if (!m || m.alchemyLevel >= 5) return showToast("Nhân vật không hợp lệ hoặc đã đạt đỉnh phong Ngũ Phẩm Đan Sư!");
      gameState.spiritStones -= 40;
      m.alchemyLevel++;
      updateAllUI();
      openMemberDetailModal(memberId);
      showToast(`⚗️ ${m.name} tấn thăng Đan Sư Phẩm ${m.alchemyLevel}!`);
    }

    function appointElder(memberId) {
      const m = getValidLivingMember(memberId);
      if (!m) return showToast("Không thể bổ nhiệm người đã tọa hóa.");
      m.role = m.role === "Trưởng Lão" ? "Tộc Nhân" : "Trưởng Lão";
      updateAllUI();
      openMemberDetailModal(memberId);
      showToast(`🏛️ Đã cập nhật chức vị ${m.role} cho ${m.name}.`);
    }

    // =========================================================================
    // 11. HỆ THỐNG KẾT ĐẠO LỮ CHO THỦY TỔ VÀ TẤT CẢ ĐỜI CON CHÁU
    // =========================================================================
    function s3cPolicyControls(){return `<section class="bg-rose-50 border border-rose-200 rounded-xl p-3 text-[11px] text-rose-900 font-semibold">👑 Gia Chủ quyết định mọi hôn phối. Không có chế độ tự kết hôn. Mai mối 15 💎/lượt, ba ứng viên, chờ 6 tháng giữa hai lượt. Sinh con cũng phải xin phép từng lần qua Thiên Cơ.</section>`;}
    function s3cSetMarriagePolicy(){gameState.marriagePolicy='manual';showToast('Gia Chủ phải phê duyệt toàn bộ hôn nhân.');}
    function s3cSetBirthPolicy(policy){if(['balanced','slow'].includes(policy))gameState.birthPolicy=policy;showToast('Đã cập nhật nhịp xin phép cầu tự.');}
    function s3f41GenerateMatch(member){
      const gender=member.gender==='male'?'female':'male';
      return Array.from({length:3},()=>{
        const root=rollSpiritRoot(),age=Math.max(18,Math.min(55,member.age+Math.floor(Math.random()*7)-3));
        return {name:generateTwoCharName(gender),age,realmIdx:Math.max(1,Math.min(member.realmIdx+1,6)),rootId:root.id,
          harmony:Math.max(25,Math.min(95,Math.round(75-Math.abs(member.age-age)*1.5-Math.abs(root.xpMult-member.spiritRoot.xpMult)*12+(Math.random()*30-15)))),
          cost:root.xpMult>=1.5?90:root.xpMult>=1.2?45:20};
      });
    }
    function s3f41SearchMatch(memberId){
      const m=getValidLivingMember(Number(memberId));
      if(!m||m.isMarriedIn||m.spouseId||m.age<GAME_CONFIG.minMarriageAge)return showToast('Tộc nhân không đủ điều kiện mai mối.');
      const now=getMonthIndex(),old=gameState.familyMatchmaking[String(m.id)];
      if(old&&now-old.lastSearch<S3F41_MATCH_COOLDOWN)return showToast(`Mai mối cần chờ thêm ${S3F41_MATCH_COOLDOWN-(now-old.lastSearch)} tháng.`);
      if(gameState.spiritStones<S3F41_MATCH_FEE)return showToast('Không đủ 15 linh thạch để tìm nhân duyên.');
      gameState.spiritStones-=S3F41_MATCH_FEE;
      gameState.familyMatchmaking[String(m.id)]={lastSearch:now,expires:now+S3F41_MATCH_VALID,candidates:s3f41GenerateMatch(m)};
      addHistory(`Năm ${gameState.year}, tháng ${gameState.month}: Gia Chủ chi 15 linh thạch mai mối cho ${m.name}; nhận đúng ba ứng viên.`);
      markGameDirty();updateAllUI();saveGameToLocal({silent:true,closeModal:false});openMarriageModal(m.id);
    }
    function openMarriageModal(targetMemberId=null){
      const eligible=gameState.members.filter(m=>m.alive&&!m.spouseId&&!m.isMarriedIn&&m.age>=GAME_CONFIG.minMarriageAge);
      if(!eligible.length){marriageModalContext=null;return openGenericModal('Kết Đạo Lữ',`<p class="text-xs">Chưa có tộc nhân đủ tuổi để kết đạo lữ.</p>${s3cPolicyControls()}`);}
      const main=eligible.find(m=>m.id===Number(targetMemberId))||eligible[0],now=getMonthIndex();
      const record=gameState.familyMatchmaking[String(main.id)];
      const valid=record&&record.expires>=now&&Array.isArray(record.candidates)&&record.candidates.length===3;
      const cooldown=record?Math.max(0,S3F41_MATCH_COOLDOWN-(now-record.lastSearch)):0;
      const gender=main.gender==='male'?'female':'male';
      marriageModalContext=valid?{mainId:main.id,spouseGender:gender,candidates:record.candidates}:null;
      const body=`<div class="space-y-3">${s3cPolicyControls()}
        <label class="block text-xs font-extrabold">Chọn tộc nhân cần kết đạo lữ</label>
        <select onchange="openMarriageModal(Number(this.value))" class="w-full p-2 border-2 rounded-xl text-xs font-bold">${eligible.map(m=>`<option value="${m.id}" ${m.id===main.id?'selected':''}>Đời ${m.generation} • ${escapeHtml(m.name)} (${m.age} tuổi — ${REALMS[m.realmIdx].name})</option>`).join('')}</select>
        <div class="bg-amber-50 rounded-xl p-3 text-xs font-semibold">${valid?`Đang xem 3 ứng viên đã tìm. Danh sách còn hiệu lực ${Math.max(0,record.expires-now)} tháng.`:'Hiện chưa có danh sách ứng viên còn hiệu lực.'} ${cooldown?`Cần chờ thêm ${cooldown} tháng để tìm lượt mới.`:''}</div>
        <button type="button" ${cooldown||gameState.spiritStones<15?'disabled':''} onclick="s3f41SearchMatch(${main.id})" class="w-full p-3 rounded-xl font-extrabold text-xs ${cooldown||gameState.spiritStones<15?'bg-slate-300 text-slate-600':'bg-rose-700 text-white'}">🔎 Tìm 3 nhân duyên (15 💎)${cooldown?` — chờ ${cooldown} tháng`:''}</button>
        ${valid?`<div class="space-y-2">${record.candidates.map((c,i)=>{const root=SPIRIT_ROOTS.find(r=>r.id===c.rootId)||SPIRIT_ROOTS[0];return `<div class="bg-white border border-rose-300 rounded-xl p-2 flex gap-2 items-center justify-between">
          <div class="flex gap-2 items-center min-w-0">${getCharacterSvg({name:c.name,gender,age:c.age,spiritRoot:root},44)}<div class="text-[10px]"><b>${escapeHtml(c.name)} (${c.age} tuổi)</b><div>${REALMS[c.realmIdx].name} • ${root.name}</div><div>Hòa hợp ${c.harmony}/100</div></div></div>
          <button class="bg-rose-600 text-white p-2 rounded-xl text-xs font-extrabold shrink-0" onclick="confirmMarriage(${main.id},${i},'${gender}')">Xin cưới<br>${c.cost} 💎</button></div>`}).join('')}</div>`:''}
        <p class="text-[11px] text-slate-600">Mỗi lượt chỉ ba ứng viên. Mở lại danh sách không tốn linh thạch. Sính lễ chỉ trừ khi Gia Chủ xác nhận kết duyên.</p>
      </div>`;
      openGenericModal('💞 Mai Mối Tiên Duyên',body);
    }
    function confirmMarriage(mainId,index,spouseGender){
      const m=getValidLivingMember(Number(mainId)),context=marriageModalContext;
      const record=gameState.familyMatchmaking[String(mainId)],now=getMonthIndex();
      if(!m||m.spouseId||m.isMarriedIn||m.age<GAME_CONFIG.minMarriageAge||!context||context.mainId!==m.id||!record||record.expires<now)return showToast('Danh sách hôn phối đã hết hiệu lực.');
      if(context.spouseGender!==spouseGender||spouseGender!==(m.gender==='male'?'female':'male'))return showToast('Giới tính ứng viên không hợp lệ.');
      const c=record.candidates[index];if(!c||index<0||index>2)return showToast('Ứng viên không hợp lệ.');
      if(getAliveCount()>=getMaxAbodeCapacity())return showToast('Động Phủ đã chật, chưa thể tổ chức hôn lễ.');
      if(gameState.spiritStones<c.cost)return showToast(`Cần ${c.cost} linh thạch làm sính lễ.`);
      openDecisionModal({
        title:'💞 Gia Chủ Phê Chuẩn Hôn Lễ',
        message:`Gia Chủ xác nhận cho ${m.name} kết đạo lữ cùng ${c.name}?
Sính lễ ${c.cost} linh thạch. Sau khi chấp thuận mới tổ chức hôn lễ.`,
        confirmText:'Chuẩn hôn',
        cancelText:'Xem lại',
        confirmClass:'bg-rose-600 text-white',
        onConfirm:()=>{
          const root=SPIRIT_ROOTS.find(r=>r.id===c.rootId);if(!root)return;
          gameState.spiritStones-=c.cost;
          const spouse=createMember({name:c.name,gender:spouseGender,age:c.age,generation:m.generation,realmIdx:c.realmIdx,spouseId:m.id,isMarriedIn:true,rootOverride:root});
          m.spouseId=spouse.id;m.maritalHarmony=c.harmony;spouse.maritalHarmony=c.harmony;
          gameState.members.push(spouse);rebuildMemberIndex();delete gameState.familyMatchmaking[String(mainId)];marriageModalContext=null;
          addHistory(`Năm ${gameState.year}: Gia Chủ phê chuẩn hôn lễ ${m.name} và ${spouse.name} (sính lễ ${c.cost} linh thạch).`);
          setTicker(`💞 ${m.name} & ${spouse.name} kết duyên theo quyết định Gia Chủ!`);
          recalcTeamMaxHp();updateAllUI();saveGameToLocal({silent:true,closeModal:false});
        },
        onCancel:()=>{ openMarriageModal(mainId); }
      });
      return;
    }
    // Giữ tên hàm cho tương thích với sự kiện cũ nhưng tuyệt đối không tự tạo hôn nhân.
    function marryMemberWithRandomSpouse(){return false;}

    function openAdoptModal() {
      if (getAliveCount() >= getMaxAbodeCapacity()) {
        return showToast("Động phủ đã đầy người, không thể nhận thêm hậu duệ!");
      }
      const guardians = gameState.members.filter(m=>m.alive && !m.isMarriedIn && m.age>=18);
      if(!guardians.length) return showToast('Cần một tộc nhân trưởng thành để nhận nuôi.');
      const gender = Math.random() < 0.5 ? "male" : "female";
      const childName = generateTwoCharName(gender, gameState.clanSurname);
      const root = rollSpiritRoot();
      adoptCandidateContext = { name: childName, gender, rootId: root.id, parentId: guardians[0].id };
      const guardianOptions=guardians.map(m=>`<option value="${m.id}">${escapeHtml(m.name)} · Đời ${m.generation}</option>`).join('');
      const body = `
        <div class="text-center space-y-2">
          <div class="flex justify-center">${getCharacterSvg({ name: childName, gender, age: 6, spiritRoot: root }, 68)}</div>
          <div class="text-sm font-extrabold text-emerald-950">Cô Nhi Tu Tiên: ${escapeHtml(childName)} (6 tuổi)</div>
          <div class="text-xs font-bold text-purple-700">Tư chất: ${root.name}</div>
          <label class="block text-xs font-bold text-emerald-950">Tộc nhân nhận nuôi</label>
          <select class="w-full rounded-lg bg-white p-2 border border-emerald-300 text-xs" onchange="s3bSetAdoptiveParent(this.value)">${guardianOptions}</select>
          <p class="text-[11px] text-slate-600">Đứa trẻ mồ côi mang linh căn được phát hiện dưới chân núi. Gia phả sẽ ghi rõ là con nuôi; huyết thống không tự động gán cho cha mẹ nuôi.</p>
          <button onclick="confirmAdoptChild()" class="w-full bg-emerald-700 text-white font-extrabold py-2 rounded-xl text-xs shadow active:scale-95">
            ✨ Nhận Làm Hậu Duệ Gia Tộc (-40 💎)
          </button>
        </div>
      `;
      openGenericModal("Thu Nhận Hậu Duệ", body);
    }

    function s3bSetAdoptiveParent(id){
      if(!adoptCandidateContext)return;
      const m=getValidLivingMember(Number(id));
      if(m && !m.isMarriedIn && m.age>=18) adoptCandidateContext.parentId=m.id;
    }
    function confirmAdoptChild() {
      const candidate = adoptCandidateContext;
      if (!candidate) return showToast("Lựa chọn hậu duệ đã hết hiệu lực. Vui lòng mở lại.");
      if (getAliveCount() >= getMaxAbodeCapacity()) return showToast("Động phủ đã chật; không thể nhận thêm hậu duệ!");
      if (gameState.spiritStones < 40) return showToast("Cần 40 Linh thạch để làm lễ nhập tộc!");
      const guardian=getValidLivingMember(candidate.parentId);
      if(!guardian || guardian.age<18 || guardian.isMarriedIn) return showToast('Người nhận nuôi không còn đủ điều kiện.');
      const root = SPIRIT_ROOTS.find(item => item.id === candidate.rootId) || SPIRIT_ROOTS[0];
      const child = createMember({
        name: normalizePlayerName(candidate.name, "Trần Nhi"),
        gender: candidate.gender === "female" ? "female" : "male",
        age: 6,
        generation: guardian.generation + 1,
        realmIdx: 0,
        parentId: guardian.id,
        adoptiveParentId: guardian.id,
        biologicalFatherId: null,
        biologicalMotherId: null,
        lineageType: "adopted",
        rootOverride: root
      });
      gameState.spiritStones -= 40;
      gameState.members.push(child);
      rebuildMemberIndex();
      adoptCandidateContext = null;
      child.careGuardianId = guardian.id;
      addHistory(`Năm ${gameState.year}: ${guardian.name} nhận ${child.name} (${child.spiritRoot.name}) làm nghĩa tử, chính thức nhập tộc.`);
      closeGenericModal();
      updateAllUI();
      saveGameToLocal({ silent: true, closeModal: false });
    }

    // =========================================================================
    // 12. KỲ NGỘ CHO TOÀN BỘ THÀNH VIÊN & THÔNG BÁO THÀNH CÔNG / THẤT BẠI
    // =========================================================================
    const ADVENTURE_TEMPLATES = [
      {
        id: "co_dong_tan_bia",
        cooldownMonths: 24,
        title: "Cổ Động Tàn Bia",
        desc: (m) => `Khi du ngoạn hái thuốc, <b>${escapeHtml(m.name)}</b> tình cờ phát hiện một tấm bia đá khắc kiếm ý thượng cổ ẩn sau thác nước.`,
        choices: [
          {
            id: "linh_ngo_kiem_y",
            label: "Dùng thần thức lĩnh ngộ kiếm ý",
            baseRate: 62,
            onSuccess: (m) => {
              m.crit = +(m.crit + 2.2).toFixed(1);
              m.combo = +(m.combo + 1.8).toFixed(1);
              addXp(m, 35);
              return `${m.name} ngộ ra một tia Kiếm Ý! Bạo Kích +2.2%, Liên Kích +1.8%, +35 Tu Vi.`;
            },
            onFail: (m) => {
              m.innerDemon = Math.min(100, m.innerDemon + 18);
              gameState.spiritStones = Math.max(0, gameState.spiritStones - 15);
              return `Kiếm ý quá sắc bén phản phệ thần thức! ${m.name} tăng +18 Tâm Ma và tiêu hao 15 Linh thạch tĩnh dưỡng.`;
            }
          },
          {
            id: "sao_che_bi_van",
            label: "Cẩn thận sao chép mang về tộc",
            baseRate: 85,
            onSuccess: (m) => {
              gameState.spiritStones += 25;
              addXp(m, 15);
              return `${m.name} sao chép hoàn chỉnh bí văn, đổi được +25 Linh thạch và +15 Tu Vi.`;
            },
            onFail: (m) => {
              gameState.spiritStones = Math.max(0, gameState.spiritStones - 10);
              return `Tàn bia bất ngờ phong hóa sụp đổ, ${m.name} tay trắng trở về (-10 Linh thạch lộ phí).`;
            }
          }
        ]
      },
      {
        id: "huyet_dam_yeu_hoa",
        cooldownMonths: 24,
        title: "Huyết Đàm Yêu Hoa",
        desc: (m) => `Tại khe núi âm hàn, <b>${escapeHtml(m.name)}</b> bắt gặp một đóa Huyết Ngọc Liên đang nở rộ tỏa tinh khí nồng đậm.`,
        choices: [
          {
            id: "nuot_huyet_lien",
            label: "Nuốt sống tinh hoa Huyết Liên",
            baseRate: 58,
            onSuccess: (m) => {
              m.lifesteal = +(m.lifesteal + 2.5).toFixed(1);
              m.bonusHp += 45;
              return `Huyết mạch sôi trào! ${m.name} tăng +2.5% Hút HP và +45 HP vĩnh viễn.`;
            },
            onFail: (m) => {
              gameState.teamHp = Math.max(15, Math.round(gameState.teamHp * 0.75));
              m.innerDemon = Math.min(100, m.innerDemon + 15);
              return `Hàn độc xâm nhập kinh mạch! Sinh lực đội hình giảm 25% và ${m.name} tăng +15 Tâm Ma.`;
            }
          },
          {
            id: "hai_duoc_lieu",
            label: "Hái về làm dược liệu luyện đan",
            baseRate: 80,
            onSuccess: (m) => {
              gameState.herbs.ngoc_tuy_chi++;
              return `${m.name} thu hoạch thành công +1 Ngọc Tủy Chi cho Đan Đường!`;
            },
            onFail: (m) => {
              gameState.spiritStones = Math.max(0, gameState.spiritStones - 12);
              return `Bị yêu xà canh giữ tập kích, ${m.name} phải ném 12 Linh thạch bố trận mới thoát thân.`;
            }
          }
        ]
      },
      {
        id: "tan_tu_luan_dao",
        cooldownMonths: 24,
        title: "Tán Tu Luận Đạo",
        desc: (m) => `Một vị lão giả áo xám dừng chân trước sơn môn, ngỏ ý muốn tỷ thí thân pháp và luận đạo cùng <b>${escapeHtml(m.name)}</b>.`,
        choices: [
          {
            id: "ty_thi_than_phap",
            label: "Nhận lời tỷ thí thân pháp",
            baseRate: 65,
            onSuccess: (m) => {
              m.dodge = +(m.dodge + 2.4).toFixed(1);
              m.bonusSpd += 6;
              return `Lão giả khen ngợi không ngớt! ${m.name} lĩnh ngộ bộ pháp: +2.4% Né Tránh, +6 Tốc Độ.`;
            },
            onFail: (m) => {
              gameState.spiritStones = Math.max(0, gameState.spiritStones - 18);
              return `${m.name} thua kém một chiêu, đành dâng 18 Linh thạch lễ bái tạ lỗi.`;
            }
          },
          {
            id: "dang_tra_thinh_giao",
            label: "Dâng trà thỉnh giáo tâm đắc",
            baseRate: 88,
            onSuccess: (m) => {
              addXp(m, 30);
              m.bonusDef += 8;
              return `Lão giả chỉ điểm yếu quyết hộ thể: ${m.name} nhận +30 Tu Vi và +8 Phòng Thủ.`;
            },
            onFail: (m) => {
              gameState.spiritStones = Math.max(0, gameState.spiritStones - 8);
              return `Lão giả tính tình cổ quái bỏ đi giữa chừng, tốn 8 Linh thạch linh trà.`;
            }
          }
        ]
      }
    ];


    // SPRINT 3A: 60 sự kiện chia 5 nhóm; dữ liệu/callback không lưu vào save.
    const S3A_STORIES = [{"id":"tm_child_01","category":"child","title":"Linh Quang Đầu Ngón","text":"Một luồng linh quang bỗng lóe lên trong lòng bàn tay {name} khi em chơi ở sân tổ.","type":0},{"id":"tm_child_02","category":"child","title":"Cổ Thụ Lắng Nghe","text":"{name} thường ngồi dưới linh thụ cổ thụ, nghe tiếng lá ngân như câu kinh cổ.","type":1},{"id":"tm_child_03","category":"child","title":"Viên Ngọc Bên Suối","text":"{name} nhặt được viên ngọc lạnh bên suối, bên trong ẩn hiện một đốm sáng kỳ lạ.","type":2},{"id":"tm_child_04","category":"child","title":"Tiếng Sáo Đêm Trăng","text":"Đêm trăng, {name} nghe tiếng sáo từ núi vắng, dường như gọi tên mình.","type":3},{"id":"tm_child_05","category":"child","title":"Khách Nhỏ Lạc Đường","text":"Một linh thú non bị thương lạc vào sân, chỉ chịu đến gần {name}.","type":0},{"id":"tm_child_06","category":"child","title":"Bức Họa Trong Tàng Các","text":"{name} nhận ra một nét ấn pháp khác thường trong bức họa phủ bụi ở Tàng Kinh Các.","type":1},{"id":"tm_child_07","category":"child","title":"Giấc Mộng Linh Sơn","text":"{name} liên tiếp mơ thấy một ngọn núi phủ mây xanh và chiếc chuông cổ.","type":2},{"id":"tm_child_08","category":"child","title":"Trận Mưa Linh Khí","text":"Cơn mưa bất chợt mang theo linh khí khiến {name} muốn thử vận hành hơi thở.","type":3},{"id":"tm_child_09","category":"child","title":"Bóng Kiếm Trên Tường","text":"Đang chơi đùa, {name} nhìn bóng kiếm trên tường và bắt chước được một động tác rất lạ.","type":0},{"id":"tm_child_10","category":"child","title":"Hạt Giống Phát Quang","text":"Một hạt giống phát sáng rơi vào lòng bàn tay {name} ở vườn linh thảo.","type":1},{"id":"tm_child_11","category":"child","title":"Tiếng Gọi Trong Đá","text":"{name} áp tai vào một tảng đá cũ rồi nói mình nghe thấy tiếng kinh văn.","type":2},{"id":"tm_child_12","category":"child","title":"Lời Hứa Với Tổ Tiên","text":"Trước bài vị tổ tiên, {name} bỗng nghiêm túc xin được học cách bảo vệ gia tộc.","type":3},{"id":"tm_teen_01","category":"teen","title":"Kiếm Ý Đầu Đời","text":"Trong buổi tập, {name} bất ngờ chạm tới một tia kiếm ý còn rất non nớt.","type":0},{"id":"tm_teen_02","category":"teen","title":"Thư Mời Luận Đạo","text":"Một thiếu niên từ tông môn lân cận gửi thư mời {name} dự buổi luận đạo.","type":1},{"id":"tm_teen_03","category":"teen","title":"Dược Đỉnh Bất Ổn","text":"Lúc phụ việc Đan Các, {name} nhận thấy linh hỏa trong dược đỉnh dao động bất thường.","type":2},{"id":"tm_teen_04","category":"teen","title":"Bản Đồ Da Cũ","text":"{name} tìm thấy mảnh bản đồ da cũ kẹp trong một cuốn sách rách.","type":3},{"id":"tm_teen_05","category":"teen","title":"Một Chiêu Chưa Hiểu","text":"{name} luyện đi luyện lại một chiêu kiếm nhưng luôn thiếu một nhịp cuối.","type":0},{"id":"tm_teen_06","category":"teen","title":"Người Bạn Bên Suối","text":"Một tán tu đồng trang lứa muốn cùng {name} khám phá khe núi có sương độc.","type":1},{"id":"tm_teen_07","category":"teen","title":"Bài Khảo Hạch Linh Căn","text":"Trưởng lão đề nghị {name} thử một bài khảo hạch linh căn khó hơn thường lệ.","type":2},{"id":"tm_teen_08","category":"teen","title":"Thạch Bích Phản Chiếu","text":"Khi đứng trước thạch bích, {name} thấy bóng mình thực hiện một bộ thủ ấn khác lạ.","type":3},{"id":"tm_teen_09","category":"teen","title":"Nửa Trang Phù Chú","text":"{name} nhặt được nửa trang phù chú, nét mực vẫn còn lưu một chút linh lực.","type":0},{"id":"tm_teen_10","category":"teen","title":"Hỏa Diễm Thử Lòng","text":"Trong lúc canh linh hỏa, {name} phát hiện ngọn lửa đổi màu như đang thử ý chí.","type":1},{"id":"tm_teen_11","category":"teen","title":"Đường Tắt Bí Cảnh","text":"{name} nghe được tin có lối mòn tới cửa Bí Cảnh chưa ai thử nghiệm.","type":2},{"id":"tm_teen_12","category":"teen","title":"Cơ Duyên Dưới Mưa","text":"Một đạo sĩ che ô dừng lại, đề nghị truyền cho {name} một phép thổ nạp sơ cấp.","type":3},{"id":"tm_adult_01","category":"adult","title":"Cổ Kiếm Gọi Chủ","text":"Một thanh cổ kiếm rỉ sét bỗng rung lên khi {name} đi qua kho binh khí.","type":0},{"id":"tm_adult_02","category":"adult","title":"Trăng Máu Biên Sơn","text":"Đêm trăng đỏ, {name} phát hiện linh khí vùng biên sơn hỗn loạn.","type":1},{"id":"tm_adult_03","category":"adult","title":"Đan Phương Thất Truyền","text":"Một thương nhân chào bán cho {name} nửa quyển đan phương cổ.","type":2},{"id":"tm_adult_04","category":"adult","title":"Chấp Niệm Trong Mộng","text":"{name} liên tục mơ thấy một thất bại cũ, đạo tâm dường như bị thử thách.","type":3},{"id":"tm_adult_05","category":"adult","title":"Lời Thỉnh Cầu Của Tán Tu","text":"Một tán tu nghèo nhờ {name} giúp hộ tống linh thảo qua rừng sâu.","type":0},{"id":"tm_adult_06","category":"adult","title":"Bí Văn Trên Vách","text":"{name} thấy vách đá trong Linh Mỏ hiện những đường phù văn mới.","type":1},{"id":"tm_adult_07","category":"adult","title":"Linh Thú Canh Giữ","text":"Một linh thú lạ xuất hiện gần linh điền, vừa cảnh giác vừa muốn giao tiếp.","type":2},{"id":"tm_adult_08","category":"adult","title":"Đấu Giá Ngọc Giản","text":"{name} nhận được lời mời tới phiên đấu giá một quyển ngọc giản vô danh.","type":3},{"id":"tm_adult_09","category":"adult","title":"Thí Luyện Tâm Cảnh","text":"{name} cảm nhận một cánh cửa tâm cảnh mở ra khi tọa thiền tại Động Phủ.","type":0},{"id":"tm_adult_10","category":"adult","title":"Khí Tức Cổ Tu","text":"Một luồng khí tức của cổ tu lướt qua núi, chỉ {name} nhận ra dấu vết.","type":1},{"id":"tm_adult_11","category":"adult","title":"Đêm Trấn Giữ Linh Mạch","text":"Linh mạch rung chuyển, {name} có cơ hội ở lại trấn giữ trong đêm.","type":2},{"id":"tm_adult_12","category":"adult","title":"Tín Vật Không Chủ","text":"{name} tìm thấy một tín vật không chủ trên đường về gia tộc.","type":3},{"id":"tm_elder_01","category":"elder","title":"Di Huấn Trước Bình Minh","text":"{name} nghĩ đến việc ghi lại một bộ tâm pháp cho hậu bối trước khi trời sáng.","type":0},{"id":"tm_elder_02","category":"elder","title":"Cổ Đan Dưỡng Thọ","text":"Một chiếc hộp cũ chứa nguyên liệu có thể thử luyện đan an thần cho {name}.","type":1},{"id":"tm_elder_03","category":"elder","title":"Hồi Ức Trăm Năm","text":"{name} nhớ lại một trận chiến năm xưa và nhận ra điều mình từng bỏ sót.","type":2},{"id":"tm_elder_04","category":"elder","title":"Dư Âm Của Đạo","text":"Khi nghe chuông chiều, {name} bất ngờ lĩnh ngộ thêm một phần đạo lý.","type":3},{"id":"tm_elder_05","category":"elder","title":"Lời Nhờ Của Hậu Bối","text":"Một hậu bối xin {name} chỉ dạy cách vượt qua trở ngại trong tu luyện.","type":0},{"id":"tm_elder_06","category":"elder","title":"Bức Thư Chưa Gửi","text":"{name} tìm thấy bức thư đã viết từ rất lâu, mang theo một lời hứa cũ.","type":1},{"id":"tm_elder_07","category":"elder","title":"Thọ Nguyên Và Cơ Duyên","text":"{name} nghe tin có linh thảo quý ở vùng núi xa, nhưng hành trình khá hiểm nguy.","type":2},{"id":"tm_elder_08","category":"elder","title":"Đạo Hữu Tái Ngộ","text":"Một đạo hữu thuở trẻ tìm đến thăm {name}, mang theo chuyện cũ và cơ hội luận đạo.","type":3},{"id":"tm_elder_09","category":"elder","title":"Linh Trà Cổ Mộc","text":"Một ấm linh trà cổ mộc giúp {name} nhớ lại phương pháp dưỡng thần xa xưa.","type":0},{"id":"tm_elder_10","category":"elder","title":"Mảnh Ngọc Truyền Thừa","text":"{name} nhìn thấy trên mảnh ngọc gia truyền một dấu ấn chưa từng nhận ra.","type":1},{"id":"tm_elder_11","category":"elder","title":"Trăng Qua Mái Ngói","text":"Đêm yên tĩnh, {name} cân nhắc truyền lại bí quyết còn chưa trọn vẹn.","type":2},{"id":"tm_elder_12","category":"elder","title":"Một Kiếp Tâm An","text":"{name} đứng trước quyết định buông bỏ chấp niệm hoặc cố tìm thêm một cơ duyên.","type":3},{"id":"tm_clan_01","category":"clan","title":"Linh Mạch Xuất Hiện Vết Nứt","text":"Mọi người phát hiện một vết nứt phát sáng bên cạnh địa mạch gia tộc.","type":0},{"id":"tm_clan_02","category":"clan","title":"Khách Lạ Gõ Sơn Môn","text":"Một vị khách lạ xin vào nghỉ chân, mang theo chiếc rương bị phong ấn.","type":1},{"id":"tm_clan_03","category":"clan","title":"Mùa Linh Thảo Thất Thường","text":"Cả linh điền bỗng phát sáng lạ khi đến kỳ thu hoạch.","type":2},{"id":"tm_clan_04","category":"clan","title":"Tin Đồn Tà Tu","text":"Tin đồn về tà tu xuất hiện gần núi khiến các tộc nhân bất an.","type":3},{"id":"tm_clan_05","category":"clan","title":"Hội Luận Đạo Đầu Xuân","text":"Các gia tộc lân cận mời một đại diện tới hội luận đạo.","type":0},{"id":"tm_clan_06","category":"clan","title":"Linh Thạch Trong Mỏ","text":"Một nhánh linh khoáng mới được phát hiện ở khu vực khai thác.","type":1},{"id":"tm_clan_07","category":"clan","title":"Hộ Sơn Trận Dao Động","text":"Hộ sơn trận phát ra tiếng ngân không đều trong đêm.","type":2},{"id":"tm_clan_08","category":"clan","title":"Thương Đội Gặp Nạn","text":"Một thương đội cầu cứu ngay bên ngoài sơn môn của gia tộc.","type":3},{"id":"tm_clan_09","category":"clan","title":"Mưa Sao Trên Tổ Sơn","text":"Trận mưa sao khiến linh khí ở Tổ Sơn bất ổn nhưng cũng mang theo cơ duyên.","type":0},{"id":"tm_clan_10","category":"clan","title":"Lời Mời Từ Tông Môn","text":"Một tông môn gửi thư đề nghị giao lưu với gia tộc.","type":1},{"id":"tm_clan_11","category":"clan","title":"Tàn Tích Gần Linh Điền","text":"Một hốc đá cổ bỗng lộ ra khi người làm đất mở rộng linh điền.","type":2},{"id":"tm_clan_12","category":"clan","title":"Đêm Trăng Hộ Tộc","text":"Ánh trăng phủ lên tổ sơn, toàn tộc có thể tổ chức một đêm tụ linh.","type":3}];
    const S3A_GROUPS = {
      child:{min:0,max:11,label:'Ấu niên',risk:'Thử tìm hiểu cơ duyên',safe:'Nhờ người lớn chỉ dẫn'},
      teen:{min:12,max:17,label:'Thiếu niên',risk:'Tự mình thử thách',safe:'Thận trọng tìm hiểu'},
      adult:{min:18,max:54,label:'Trưởng thành',risk:'Dốc sức nắm cơ duyên',safe:'Suy xét rồi hành động'},
      elder:{min:55,max:1000,label:'Lão niên',risk:'Dốc đạo tâm lĩnh ngộ',safe:'Truyền dạy, giữ an toàn'},
      clan:{min:0,max:1000,label:'Gia tộc',risk:'Đứng ra xử lý ngay',safe:'Họp tộc, hành động thận trọng'}
    };
    function s3aEligible(t,m){
      if(!m || !m.alive)return false;
      if(t.category==='clan')return Number(m.age)>=16;
      const g=S3A_GROUPS[t.category];
      return !!g && Number(m.age)>=g.min && Number(m.age)<=g.max;
    }
    function s3aOneTimeKey(eventId,memberId){return `${eventId}:${memberId}`;}
    function s3aApplyReward(m,category,variant,isRisk,success){
      const x=Math.max(0,Math.min(3,Math.floor(variant)));
      const xp=success?(isRisk?22+x*2:10+x*2):0;
      const stones=success?(isRisk?9+x*2:4+x):-(isRisk?8+x*2:3+x);
      const demon=success?(isRisk?0:-1):(isRisk?5+x:1);
      const effects=[];
      addXp(m,xp);
      gameState.spiritStones=Math.max(0,Math.min(GAME_CONFIG.maxResource,gameState.spiritStones+stones));
      m.innerDemon=Math.max(0,Math.min(100,m.innerDemon+demon));
      if(success){
        if(x===0){
          m.bonusAtk=Math.min(GAME_CONFIG.maxResource,m.bonusAtk+(isRisk?3:1));
          effects.push('Tấn Công tăng');
        } else if(x===1){
          gameState.herbs.ngoc_tuy_chi=Math.min(GAME_CONFIG.maxResource,gameState.herbs.ngoc_tuy_chi+1);
          effects.push('+1 Ngọc Tủy Chi');
        } else if(x===2){
          m.bonusDef=Math.min(GAME_CONFIG.maxResource,m.bonusDef+(isRisk?4:2));
          effects.push('Phòng Thủ tăng');
        } else {
          m.bonusHp=Math.min(GAME_CONFIG.maxResource,m.bonusHp+(isRisk?8:4));
          effects.push('HP tăng');
        }
        if(category==='teen'&&isRisk){m.bonusSpd=Math.min(GAME_CONFIG.maxResource,m.bonusSpd+1);effects.push('Tốc Độ +1');}
        if(category==='elder'&&!isRisk){m.innerDemon=Math.max(0,m.innerDemon-2);effects.push('Tâm Ma -2');}
      }
      return `${m.name} ${success?'đã nắm được cơ duyên':'chưa nắm được cơ duyên'}: ${xp?`+${xp} Tu Vi, `:''}${stones>=0?'+':''}${stones} Linh thạch${demon?`, ${demon>0?'+':''}${demon} Tâm Ma`:''}${effects.length?', '+effects.join(', '):''}.`;
    }
    const S3A_TEMPLATES = S3A_STORIES.map(story=>{
      const group=S3A_GROUPS[story.category];
      return {
        id:story.id, title:story.title, category:story.category, isS3A:true,
        cooldownMonths:18,
        desc:m=>`<b>${escapeHtml(m.name)}</b> — ${escapeHtml(group.label)}. ${escapeHtml(story.text.replace('{name}',m.name))}`,
        choices:[
          {id:'dung_cam',label:group.risk,baseRate:53+(story.type*4),
           onSuccess:m=>s3aApplyReward(m,story.category,story.type,true,true),
           onFail:m=>s3aApplyReward(m,story.category,story.type,true,false)},
          {id:'than_trong',label:group.safe,baseRate:82-(story.type*2),
           onSuccess:m=>s3aApplyReward(m,story.category,story.type,false,true),
           onFail:m=>s3aApplyReward(m,story.category,story.type,false,false)}]
      };
    });
    ADVENTURE_TEMPLATES.push(...S3A_TEMPLATES);

    // Sprint 3D: tuyến Kỳ Ngộ đa hồi lưu vĩnh viễn vào gameState.
    // Các mốc tháng tuyệt đối cho phép lưu/tải giữa chừng, không phụ thuộc setTimeout.
    const S3D_STORIES = [
      {id:'kiem_y',name:'Kiếm Ý Vô Danh',min:8,kind:'mentor',focus:'attack',
        chapters:['Vách đá khắc kiếm quyết','Lời hẹn ba năm','Kiếm ý truyền đời'],
        scenes:['{name} bắt gặp nét kiếm cổ trên vách đá. Một người đi trước khuyên nên tìm hiểu nguồn gốc trước khi lĩnh ngộ.','Nét kiếm năm xưa bỗng xuất hiện trong mộng. {name} phải chọn giữa đối diện tâm ma hoặc nhờ người chỉ dẫn.','Sau nhiều năm, một trang kiếm phổ được mở ra; {name} quyết định hoàn thiện kiếm quyết cho gia tộc.']},
      {id:'dan_phuong',name:'Đan Phương Thất Lạc',min:16,kind:'mentor',focus:'alchemy',
        chapters:['Bài thuốc trong tro tàn','Đan lô nứt vỡ','Đan phương lưu danh'],
        scenes:['{name} nhặt được tờ đan phương cháy dở trong cổ trạch, nhưng thành phần dược liệu đã mờ.','Một đan lô thất bại khiến mọi người hoài nghi về bài thuốc cổ.','Đan phương cuối cùng có thể dùng để bảo toàn sức khỏe cho các đời hậu duệ.']},
      {id:'mau_tu',name:'Tình Thân Nơi Sơn Môn',min:8,kind:'family',focus:'bond',
        chapters:['Lời hứa với người thân','Thư nhà không đến','Đoàn tụ dưới trăng'],
        scenes:['{name} nghe chuyện về một di vật gia đình bị thất lạc, được người thân nhờ tìm kiếm.','Một bức thư muộn làm {name} nghi ngờ lời hứa năm xưa có còn được giữ.','Sự thật được sáng tỏ, {name} phải quyết định có khép lại vết thương tình thân hay không.']},
      {id:'dao_lu',name:'Đạo Lữ Đồng Tâm',min:18,kind:'spouse',focus:'bond',
        chapters:['Ước hẹn dưới gốc linh mộc','Một lần xa cách','Đồng tâm hộ đạo'],
        scenes:['{name} và đạo lữ tìm được nhánh linh mộc có thể giúp hai người hiểu nhau hơn.','Một biến cố tu hành khiến hai người không thống nhất cách bảo vệ gia tộc.','Hai người đứng trước lựa chọn cùng vượt khó hoặc đi con đường thận trọng riêng.']},
      {id:'su_do',name:'Sư Đồ Vấn Đạo',min:8,kind:'mentor',focus:'xp',
        chapters:['Một lời dạy cũ','Đạo lý trái ngược','Đạo thống tiếp nối'],
        scenes:['{name} tìm được ghi chép của tiền nhân, khiến lời dạy của sư phụ mang ý nghĩa khác.','{name} và sư phụ có quan điểm khác nhau về con đường đột phá.','Một buổi luận đạo cuối cùng quyết định cách truyền dạy cho thế hệ tiếp theo.']},
      {id:'linh_dien',name:'Mạch Sống Linh Điền',min:16,kind:'estate',focus:'stones',
        chapters:['Hạt giống kỳ lạ','Mùa linh khí cạn','Mùa gặt hồi sinh'],
        scenes:['{name} nhận thấy hạt giống cổ nảy mầm cạnh Linh Điền gia tộc.','Linh khí suy kiệt, mầm cây đứng trước nguy cơ khô héo.','Một mùa gặt mới đến; {name} quyết định chia sẻ hay tích trữ thành quả.']},
      {id:'linh_mach',name:'Linh Mạch Trong Núi',min:16,kind:'estate',focus:'defense',
        chapters:['Tiếng vọng từ địa mạch','Trận tuyến rạn nứt','Trấn sơn lập trận'],
        scenes:['{name} phát hiện dấu hiệu dịch chuyển dưới nền linh sơn.','Một trận pháp phòng hộ bị phá vỡ, khiến gia tộc đứng trước nguy cơ thất thoát linh khí.','Một mạch phụ hiển lộ, hứa hẹn bảo vệ cơ nghiệp nhiều năm.']},
      {id:'bi_canh',name:'Dấu Chân Bí Cảnh',min:16,kind:'adventure',focus:'speed',
        chapters:['Bản đồ rách','Đồng hành trong sương','Lối về cổ cảnh'],
        scenes:['{name} nhận được nửa tấm bản đồ từ một tu sĩ lữ hành.','Trong khu rừng sương, một người đồng hành bị lạc khỏi đội thám hiểm.','Cửa cổ cảnh mở ra lần cuối. {name} phải cân nhắc giữa bảo vật và an toàn đồng đội.']},
      {id:'an_nghia',name:'Một Đời Ân Nghĩa',min:16,kind:'family',focus:'bond',
        chapters:['Cứu người giữa mưa','Lời hứa chưa trọn','Đền đáp ân tình'],
        scenes:['{name} cứu một tu sĩ xa lạ, người để lại mảnh ngọc làm tín vật.','Một vị khách cũ trở lại xin gia tộc giúp đỡ trong lúc hoạn nạn.','Gia tộc có cơ hội nhận lại ân nghĩa, nhưng {name} phải tự quyết định cách đối đãi.']},
      {id:'huyet_mach',name:'Huyết Mạch Thức Tỉnh',min:8,kind:'family',focus:'hp',
        chapters:['Mộng về tổ tiên','Dấu ấn trên tay','Huyết thệ hộ tộc'],
        scenes:['{name} mơ thấy thủy tổ đứng bên cánh cổng phủ đầy phù văn.','Dấu ấn trong mơ hiện ra khi {name} luyện công và làm kinh mạch đau nhức.','Tộc nhân tìm được lời thề hộ tộc khắc trên gia bảo cũ.']},
      {id:'tinh_khong',name:'Tinh Tú Dẫn Lộ',min:16,kind:'adventure',focus:'xp',
        chapters:['Sao rơi phía bắc','Thiên tượng đổi dời','Một đêm ngộ đạo'],
        scenes:['{name} nhìn thấy một ngôi sao rơi gần ngọn núi của gia tộc.','Thiên tượng thay đổi khiến pháp môn đang nghiên cứu có dấu hiệu phản phệ.','Tinh tượng hội tụ lần nữa và mở ra cơ duyên ngộ đạo.']},
      {id:'co_nhan',name:'Bạn Cũ Giang Hồ',min:18,kind:'spouse_or_family',focus:'stones',
        chapters:['Khách ghé cửa sơn môn','Ân oán năm xưa','Chung tay hóa giải'],
        scenes:['Một người quen cũ đến tìm {name}, nhờ gia tộc giữ hộ túi linh thạch.','Người khách bị truy đuổi; {name} phải xác minh lời tố cáo trước khi ra tay.','Một cuộc hòa giải có thể đổi lại sự tin cậy hoặc khiến gia tộc mất danh dự.']}
    ];
    function s3dEligible(story, m) {
      if(!m || !m.alive || m.isMarriedIn || m.age < story.min) return false;
      if(story.kind==='spouse') return !!getValidLivingMember(m.spouseId);
      if(story.kind==='mentor') return !!(getValidLivingMember(m.mentorId) || m.age>=16);
      if(story.kind==='family') return !!(getValidLivingMember(m.careGuardianId) || getValidLivingMember(m.parentId) || m.isFounder || m.age>=16);
      return true;
    }
    function s3dChainId(storyId,memberId){return `${storyId}:${memberId}`;}
    function s3dChain(storyId,memberId){return (gameState.s3dChains||[]).find(c=>c.id===s3dChainId(storyId,memberId));}
    function s3dRelative(story,m){
      const person = story.kind==='spouse' ? getValidLivingMember(m.spouseId) :
        story.kind==='mentor' ? getValidLivingMember(m.mentorId) :
        getValidLivingMember(m.careGuardianId)||getValidLivingMember(m.parentId)||getValidLivingMember(m.spouseId);
      return person?.name || 'các tộc nhân';
    }
    function s3dApplyOutcome(story, stage, m, risk, success){
      const chain = s3dChain(story.id,m.id);
      // Tạo tuyến ở lúc mở hồi 1; callback nhận quyết định chỉ từ template tĩnh.
      if(!chain || chain.stage !== stage || chain.status!=='active')return 'Hồi truyện này đã được xử lý.';
      const good = success ? (risk ? 2:1):0;
      const bad = success ? 0 : (risk ? 2:1);
      const bondBefore = Number.isFinite(m.familyBond)?m.familyBond:40;
      let details = [];
      if(story.focus==='bond'){
        const delta = good?good*(stage+2):-(bad*2);
        m.familyBond=Math.max(0,Math.min(100,bondBefore+delta));
        details.push(`Tình thân ${delta>=0?'+':''}${delta}`);
        const spouse=getValidLivingMember(m.spouseId);
        if(spouse && stage===3){
          const harmony=success?2:-2;
          m.maritalHarmony=Math.max(0,Math.min(100,(m.maritalHarmony??55)+harmony));
          spouse.maritalHarmony=m.maritalHarmony;
          details.push(`Hòa hợp đạo lữ ${harmony>=0?'+':''}${harmony}`);
        }
      }else if(story.focus==='stones'){
        const delta=good?Math.min(22,3+good*stage*3):-Math.min(12,2+bad*stage*2);
        gameState.spiritStones=Math.max(0,Math.min(GAME_CONFIG.maxResource,gameState.spiritStones+delta));
        details.push(`Linh thạch ${delta>=0?'+':''}${delta}`);
      }else if(story.focus==='attack'){
        const delta=good?Math.min(3,good+stage-1):0;
        m.bonusAtk=(m.bonusAtk||0)+delta;
        details.push(delta?`Tấn công +${delta}`:'Không lĩnh ngộ được kiếm ý');
      }else if(story.focus==='defense'){
        const delta=good?Math.min(3,good+stage-1):0;
        m.bonusDef=(m.bonusDef||0)+delta;
        details.push(delta?`Phòng thủ +${delta}`:'Trận tuyến chưa vững');
      }else if(story.focus==='hp'){
        const delta=good?(4+stage*good):0;
        m.bonusHp=(m.bonusHp||0)+delta;
        details.push(delta?`Sinh lực +${delta}`:'Căn cơ cần nghỉ dưỡng');
      }else if(story.focus==='speed'){
        const delta=good?Math.min(3,good+Math.floor(stage/2)):0;
        m.bonusSpd=(m.bonusSpd||0)+delta;
        details.push(delta?`Tốc độ +${delta}`:'Không tìm được đường tắt');
      }else if(story.focus==='alchemy'){
        const delta=good?1:0;
        m.alchemyLevel=Math.max(0,Math.min(20,(m.alchemyLevel||0)+delta));
        details.push(delta?'Đan đạo +1':'Đan lô chưa thành công');
      }else{
        const xp=good?(8+4*stage*good):0;
        if(xp)addXp(m,xp);
        details.push(xp?`Tu vi +${xp}`:'Cần thêm thời gian lĩnh ngộ');
      }
      if(bad){
        const demon = risk ? 3 : 1;
        m.innerDemon=Math.min(100,(m.innerDemon||0)+demon);
        details.push(`Tâm Ma +${demon}`);
      }else if(success && stage===3){
        m.innerDemon=Math.max(0,(m.innerDemon||0)-2);
        details.push('Tâm Ma -2');
      }
      chain.decisions.push({stage, choice:risk?'mao_hiem':'than_trong',success, year:gameState.year, month:gameState.month});
      chain.stage=stage+1;
      chain.due = getMonthIndex() + (stage===1?12:18);
      if(stage===3){chain.status='complete'; chain.due=null;}
      gameState.s3dChronicle.push({storyId:story.id,memberId:m.id,name:m.name,stage,year:gameState.year,month:gameState.month,
        result:`${success?'Thành công':'Thất bại'} · ${details.join(', ')}`});
      if(gameState.s3dChronicle.length>180)gameState.s3dChronicle.splice(0,gameState.s3dChronicle.length-180);
      const next=stage===3?'Tuyến truyện đã khép lại.':`Hồi tiếp theo sẽ đến sau ${stage===1?12:18} tháng.`;
      return `${m.name}: ${details.join(', ')}. ${next}`;
    }
    const S3D_TEMPLATES=[];
    for(const story of S3D_STORIES){
      for(let stage=1;stage<=3;stage++){
        S3D_TEMPLATES.push({id:`s3d_${story.id}_${stage}`,title:`${story.name} · Hồi ${stage}: ${story.chapters[stage-1]}`,
          isS3D:true,storyId:story.id,storyStage:stage,cooldownMonths:24,
          desc:m=>{const c=s3dChain(story.id,m.id);
            const prior=c?.decisions?.[stage-2];
            return `<b>${escapeHtml(m.name)}</b> · ${escapeHtml(story.scenes[stage-1].replace('{name}',m.name))}<p class="mt-2 text-emerald-800">Liên hệ: ${escapeHtml(s3dRelative(story,m))}. ${prior?'Hồi trước: '+(prior.success?'thuận lợi':'gặp trở ngại')+'.':''}</p>`;},
          choices:[{id:'mao_hiem',label:stage===3?'Dốc sức hoàn thành tâm nguyện':'Mạo hiểm tìm cơ duyên',baseRate:55,
            onSuccess:m=>s3dApplyOutcome(story,stage,m,true,true),onFail:m=>s3dApplyOutcome(story,stage,m,true,false)},
           {id:'than_trong',label:stage===3?'Ổn định truyền thừa, bảo toàn gia tộc':'Thận trọng nhờ người đồng hành',baseRate:83,
            onSuccess:m=>s3dApplyOutcome(story,stage,m,false,true),onFail:m=>s3dApplyOutcome(story,stage,m,false,false)}]});
      }
    }
    ADVENTURE_TEMPLATES.push(...S3D_TEMPLATES);
    function s3dStart(storyId,memberId){
      return showToast('Thiên Mệnh Liên Hoàn nay xuất hiện tự nhiên theo đạo lịch.');
      const story=S3D_STORIES.find(s=>s.id===storyId),m=getValidLivingMember(memberId);
      if(!story||!s3dEligible(story,m))return showToast('Tộc nhân không đáp ứng điều kiện của tuyến truyện.');
      if(s3dChain(storyId,memberId))return showToast('Tộc nhân đã trải qua hoặc đang thực hiện tuyến truyện này.');
      if(gameState.pendingAdventure)return showToast('Cần giải quyết kỳ ngộ hiện tại trước.');
      if(gameState.spiritStones<12)return showToast('Cần 12 Linh thạch để bắt đầu hành trình.');
      const active=(gameState.s3dChains||[]).filter(c=>c.status==='active').length;
      if(active>=5)return showToast('Tối đa 5 tuyến truyện đang diễn ra cùng lúc.');
      gameState.spiritStones-=12;
      gameState.s3dChains.push({id:s3dChainId(storyId,memberId),storyId,memberId,stage:1,status:'active',due:getMonthIndex(),decisions:[]});
      s3dOpenChapter(storyId,memberId,1);
      updateAllUI();saveGameToLocal({silent:true,closeModal:false});
    }
    function s3dOpenChapter(storyId,memberId,stage){
      const c=s3dChain(storyId,memberId),m=getValidLivingMember(memberId);
      if(!c||!m||c.status!=='active'||c.stage!==stage||gameState.pendingAdventure)return false;
      const template=ADVENTURE_TEMPLATES.find(t=>t.id===`s3d_${storyId}_${stage}`);
      if(!template)return false;
      gameState.pendingAdventure={eventId:template.id,memberId,context:{},createdAtMonthIndex:getMonthIndex()};
      gameState.lastAdventureMonthIndex=getMonthIndex();
      gameState.lastAdventureById[template.id]=getMonthIndex();
      markGameDirty();renderAdventureModal();return true;
    }
    function s3dCheckDue(){
      if(gameState.pendingAdventure || battleState || gameState.clanExtinct)return false;
      for(const c of gameState.s3dChains||[]){
        if(c.status!=='active')continue;
        const m=getValidLivingMember(c.memberId);
        if(!m){
          c.status='unfinished';c.due=null;
          const s=S3D_STORIES.find(s=>s.id===c.storyId);
          addHistory(`Năm ${gameState.year}: Tuyến ${s?.name||c.storyId} khép lại dang dở vì nhân vật đã qua đời.`);
          continue;
        }
        if(c.due<=getMonthIndex() && s3dOpenChapter(c.storyId,c.memberId,c.stage))return true;
      }
      return false;
    }
    function s3dOpenStoryMenu(memberId){
      const m=getValidLivingMember(memberId);if(!m)return;
      if(gameState.pendingAdventure)return showToast('Hãy hoàn thành Kỳ Ngộ đang chờ trước.');
      const choices=S3D_STORIES.filter(s=>s3dEligible(s,m)&&!s3dChain(s.id,m.id));
      const running=(gameState.s3dChains||[]).filter(c=>c.memberId===m.id&&c.status==='active');
      openGenericModal('📜 Thiên Mệnh Liên Hoàn',`<div class="space-y-2 text-xs">
        <p class="text-slate-700">Chọn một hành trình cho <b>${escapeHtml(m.name)}</b>. Mỗi hành trình có 3 hồi, nối tiếp sau 12 và 18 tháng. Khởi hành tốn 12 Linh thạch; tối đa 5 tuyến đang diễn ra trong toàn gia tộc.</p>
        ${running.map(c=>`<p class="rounded-lg bg-amber-50 p-2">Đang diễn ra: <b>${escapeHtml(S3D_STORIES.find(s=>s.id===c.storyId)?.name||c.storyId)}</b>, chờ hồi ${c.stage}.</p>`).join('')}
        ${choices.map(s=>`<button class="w-full text-left p-2.5 rounded-xl border border-emerald-400 bg-white" onclick="s3dStart('${s.id}',${m.id})"><b>${escapeHtml(s.name)}</b><span class="block text-slate-600">${escapeHtml(s.chapters.join(' → '))}</span></button>`).join('')||'<p>Nhân vật đã trải qua các tuyến hiện có hoặc chưa đủ điều kiện.</p>'}
      </div>`);
    }
    function s3dMemberPanel(m){
      if(!m||m.isMarriedIn)return '';
      const rows=(gameState.s3dChains||[]).filter(c=>c.memberId===m.id).slice(-8);
      return `<details class="bg-amber-50 border border-amber-300 rounded-xl p-2.5 text-[11px]" open>
        <summary class="font-extrabold text-emerald-950 cursor-pointer">📜 Thiên Mệnh Liên Hoàn · ${rows.length} tuyến</summary>
        <div class="mt-2 space-y-1.5">${rows.map(c=>`<div class="bg-white rounded-lg border border-amber-100 p-2"><b>${escapeHtml(S3D_STORIES.find(s=>s.id===c.storyId)?.name||c.storyId)}</b> · ${c.status==='complete'?'Hoàn tất':c.status==='unfinished'?'Dang dở':`Chờ hồi ${c.stage}`}</div>`).join('')||'<p>Chưa có tuyến truyện nhiều hồi.</p>'}
        ${m.alive?'<p class="text-amber-800">Thiên Mệnh khởi phát tự nhiên; đã chọn thì không thể khởi động lại.</p>':''}</div></details>`;
    }


    function getEligibleAdventureTemplates() {
      const monthIndex = getMonthIndex();
      return ADVENTURE_TEMPLATES.filter(template => {
        if(template.isS3D || template.isS3E2)return false;
        const last = safeInteger(gameState.lastAdventureById?.[template.id], 0, 0, Number.MAX_SAFE_INTEGER);
        const cooldown = safeInteger(template.cooldownMonths, GAME_CONFIG.defaultAdventureCooldownMonths, 1, 120);
        return monthIndex - last >= cooldown;
      });
    }

    function canTriggerAdventure() {
      if (gameState.pendingAdventure || getAliveCount() === 0) return false;
      return getMonthIndex() - safeInteger(gameState.lastAdventureMonthIndex, 0, 0, Number.MAX_SAFE_INTEGER)
        >= GAME_CONFIG.adventureGlobalCooldownMonths && getEligibleAdventureTemplates().length > 0;
    }

    function triggerFamilyAdventure() {
      if (gameState.pendingAdventure) return renderAdventureModal();
      if (!canTriggerAdventure()) return;
      const aliveList = gameState.members.filter(member => member.alive);
      if (!aliveList.length) return;
      const unlocked = getEligibleAdventureTemplates();
      const pairs = [];
      for (const t of unlocked) for (const m of aliveList) {
        if(t.isS3D)continue;
        if(t.isS3A && (!s3aEligible(t,m) || gameState.s3aSeen?.[s3aOneTimeKey(t.id,m.id)]))continue;
        pairs.push({t,m});
      }
      if(!pairs.length)return;
      const selected = pairs[Math.floor(Math.random()*pairs.length)];
      const luckyMember = selected.m;
      const tpl = selected.t;
      const monthIndex = getMonthIndex();
      gameState.lastAdventureMonthIndex = monthIndex;
      gameState.lastAdventureById[tpl.id] = monthIndex;
      gameState.pendingAdventure = {
        eventId: tpl.id,
        memberId: luckyMember.id,
        context: {},
        createdAtMonthIndex: monthIndex
      };
      markGameDirty();
      renderAdventureModal();
    }

    function getAdventureChoiceRate(member, choice) {
      if (!member || !choice) return 0;
      return Math.max(5, Math.min(95, Math.round(
        choice.baseRate + member.realmIdx * 1.2 + (member.spiritRoot.xpMult - 1) * 10
      )));
    }

    function openRandomAdventure() {
      if (gameState.pendingAdventure) {
        return renderAdventureModal();
      }
      if (!canTriggerAdventure()) {
        return showToast("Kỳ ngộ đang trong thời gian hồi phục; hãy chờ thêm vài tháng đạo lịch.");
      }
      if (gameState.spiritStones < 15) {
        return showToast("Cần 15 Linh thạch lộ phí để phái người ra ngoài tìm kỳ ngộ!");
      }
      gameState.spiritStones -= 15;
      triggerFamilyAdventure();
      updateAllUI();
    }

    function renderAdventureModal() {
      const adv = gameState.pendingAdventure;
      if (!adv) return;
      const template = ADVENTURE_TEMPLATES.find(item => item.id === adv.eventId);
      const member = getValidLivingMember(adv.memberId);
      if (!template || !member) {
        gameState.pendingAdventure = null;
        markGameDirty();
        closeGenericModal();
        updateAllUI();
        return;
      }

      const body = `
        <div class="flex items-center gap-2.5 bg-amber-50 border border-amber-400 rounded-2xl p-2.5">
          ${getCharacterSvg(member, 52)}
          <div>
            <div class="text-[10px] font-extrabold text-amber-800 uppercase">${template.isS3D?'Thiên Mệnh Liên Hoàn':template.isS3A?'Thiên Mệnh · '+escapeHtml(S3A_GROUPS[template.category].label):'Kỳ Ngộ Tộc Nhân'} • Đời ${member.generation}</div>
            <div class="text-sm font-extrabold text-emerald-950">${escapeHtml(member.name)} (${REALMS[member.realmIdx].name})</div>
            <div class="text-[10px] text-purple-700 font-semibold">${member.spiritRoot.name}</div>
          </div>
        </div>

        <div class="bg-white rounded-2xl border border-slate-200 p-3 text-xs leading-relaxed text-slate-800">
          ${template.desc(member)}
        </div>

        <div class="space-y-2">
          ${template.choices.filter(choice=>(template.id!=='s3e2_mentor'||choice.id==='self'||Number(choice.id.split('_')[1])<s3e3MentorOptions(member).length) && (template.id!=='s3f41_birth'||choice.id==='normal'||(choice.id==='healer'?gameState.spiritStones>=20:gameState.anThaiPills>=1))).map(choice => {
            const finalRate = getAdventureChoiceRate(member, choice);
            return `
              <button onclick="resolveAdventureChoice('${choice.id}')"
                class="w-full text-left bg-emerald-800 hover:bg-emerald-700 text-white p-2.5 rounded-xl shadow active:scale-98 flex items-center justify-between gap-2">
                <span class="font-bold text-xs">${template.id==='s3e2_mentor'&&choice.id!=='self' ? `Bái ${escapeHtml(s3e3MentorOptions(member)[Number(choice.id.split('_')[1])]?.name||'Không rõ')}` : choice.label}</span>
                <span class="shrink-0 bg-amber-300 text-slate-950 font-extrabold text-[10px] px-2 py-0.5 rounded-full">
                  ${template.isS3E2?'Định mệnh':`Tỷ lệ: ${finalRate}%`}
                </span>
              </button>
            `;
          }).join("")}
        </div>
      `;
      gameState.paused = true;
      openGenericModal(`✨ ${template.title}`, body, false);
      markGameDirty();
    }

    // Chỉ lưu ID sự kiện/lựa chọn; callback luôn được tra cứu từ dữ liệu tĩnh.
    function resolveAdventureChoice(choiceId) {
      const pending = gameState.pendingAdventure;
      if (!pending) return;
      const template = ADVENTURE_TEMPLATES.find(item => item.id === pending.eventId);
      const member = getValidLivingMember(pending.memberId);
      const choice = template?.choices.find(item => item.id === choiceId);
      if (!template || !member || !choice) {
        gameState.pendingAdventure = null;
        markGameDirty();
        closeGenericModal();
        updateAllUI();
        return showToast("Kỳ ngộ không còn hợp lệ; sự kiện đã được đóng an toàn.");
      }

      const finalRate = getAdventureChoiceRate(member, choice);
      // Xóa pending trước khi áp hiệu ứng để click lặp không thể nhận thưởng hai lần.
      gameState.pendingAdventure = null;
      const isSuccess = template.isS3E2 ? true : Math.random() * 100 < finalRate;
      const resultMsg = isSuccess ? choice.onSuccess(member) : choice.onFail(member);
      addHistory(`Năm ${gameState.year}: [${template.title}] ${isSuccess ? "THÀNH CÔNG" : "THẤT BẠI"} — ${resultMsg}`);
      if(template.isS3A){
        gameState.s3aSeen[s3aOneTimeKey(template.id,member.id)]=true;
        gameState.s3aChronicle.push({year:gameState.year,month:gameState.month,memberId:member.id,
          name:member.name,title:template.title,success:isSuccess,result:String(resultMsg).slice(0,320)});
        if(gameState.s3aChronicle.length>200)gameState.s3aChronicle.splice(0,gameState.s3aChronicle.length-200);
      }
      recalcTeamMaxHp();
      gameState.paused = true;
      updateAllUI();

      const resultHtml = `
        <div class="text-center py-2 space-y-2.5">
          <div class="inline-block px-4 py-1 rounded-full font-black text-sm tracking-wide ${isSuccess ? 'bg-emerald-100 text-emerald-800 border-2 border-emerald-600' : 'bg-rose-100 text-rose-800 border-2 border-rose-600'}">
            ${template.isS3E2?"📜 ĐẠO LỘ ĐÃ ĐỊNH!":isSuccess ? "🎉 KỲ NGỘ THÀNH CÔNG!" : "💥 KỲ NGỘ THẤT BẠI!"}
          </div>
          <p class="text-xs font-semibold text-slate-800 leading-relaxed bg-white p-3 rounded-2xl border border-slate-200">
            ${escapeHtml(resultMsg)}
          </p>
          <button onclick="closeGenericModal(); resumeAfterAdventure()" class="w-full bg-emerald-700 text-white font-extrabold py-2 rounded-xl text-xs shadow active:scale-95">
            Xác Nhận
          </button>
        </div>
      `;
      openGenericModal("Kết Quả Kỳ Ngộ", resultHtml, false);
      markGameDirty();
      saveGameToLocal({ silent: true, closeModal: false });
    }

    function resumeAfterAdventure() {
      if (!gameState.clanExtinct) gameState.paused = false;
      markGameDirty();
      updateAllUI();
    }

    function getTreasureSpriteHtml(treasure, size = 48) {
      const spriteIndex = {
        trantoc_an: 0,
        pham_la_ban: 1,
        pham_kiem_quyet: 2,
        pham_ho_tam: 3,
        than_huyet_chau: 4,
        than_phong_dieu: 5,
        tuyet_chu_tien: 6,
        tuyet_cuu_dinh: 7
      }[treasure && treasure.id] ?? 8;
      const row = Math.floor(spriteIndex / 3);
      const col = spriteIndex % 3;
      const safeSize = Math.max(30, Math.min(90, Number(size) || 48));
      return `<span class="treasure-sprite" aria-hidden="true" style="width:${safeSize}px;height:${safeSize}px;background-position:${col * 50}% ${row * 50}%"></span>`;
    }

    function getEstateTypeIconHtml(type) {
      const iconClass = {
        field: "ui-icon-peach",
        mine: "ui-icon-crystal",
        alchemy: "ui-icon-cauldron",
        forge: "ui-icon-swords",
        library: "ui-icon-book",
        mountain: "ui-icon-compass"
      }[type] || "ui-icon-temple";
      return `<span class="ui-icon estate-type-icon ${iconClass}" aria-hidden="true"></span>`;
    }

    // =========================================================================
    // 13. BỘ SƯU TẬP BẢO VẬT (PHÀM - THẦN - TUYỆT + TRẤN TỘC CHI BẢO)
    // =========================================================================
    function openTreasureModal() {
      const tranToc = gameState.treasures.filter(t => t.tier === "trantoc");
      const normals = gameState.treasures.filter(t => t.tier !== "trantoc");

      const body = `
        <!-- Trấn Tộc Chi Bảo (Không thể thăng cấp) -->
        <div>
          <div class="text-[11px] font-extrabold text-emerald-900 uppercase mb-1.5">🛡️ Trấn Tộc Chi Bảo (Vĩnh Viễn Không Thể Thăng Cấp)</div>
          <div class="grid grid-cols-1 gap-2">
            ${tranToc.map(t => `
              <div onclick="openTreasureDetail('${t.id}')" class="tier-trantoc rounded-2xl p-2.5 flex items-center justify-between cursor-pointer active:scale-98">
                <div class="flex items-center gap-2.5">
                  <div class="treasure-art-box">${getTreasureSpriteHtml(t, 44)}</div>
                  <div>
                    <div class="text-xs font-extrabold text-emerald-950">${t.name} <span class="text-[9px] bg-emerald-800 text-white px-1.5 py-0.5 rounded">Không thể thăng cấp</span></div>
                    <div class="text-[10px] font-bold text-emerald-800 mt-0.5">${t.effectDesc}</div>
                  </div>
                </div>
                <span class="text-xs font-black text-emerald-900">Chi tiết ›</span>
              </div>
            `).join("")}
          </div>
        </div>

        <!-- Kho Bảo Vật Phàm / Thần / Tuyệt Phẩm -->
        <div>
          <div class="flex items-center justify-between mb-1.5">
            <span class="text-[11px] font-extrabold text-slate-800 uppercase">📦 Kho Bảo Vật (Chạm để xem chi tiết)</span>
            <span class="text-[10px] font-bold text-amber-800">Pity: ${gameState.pityThan}/15 Thần • ${gameState.pityTuyet}/35 Tuyệt</span>
          </div>
          <div class="grid grid-cols-2 gap-2">
            ${normals.map(t => {
              const reqShards = t.tier === "tuyet" ? (t.level + 1) * 35 : (t.tier === "than" ? (t.level + 1) * 25 : (t.level + 1) * 20);
              const tierClass = t.tier === "tuyet" ? "tier-tuyet" : (t.tier === "than" ? "tier-than" : "tier-pham");
              const iconEmoji = t.tier === "tuyet" ? "🗡️" : (t.tier === "than" ? "🔮" : "🧭");
              return `
                <div onclick="openTreasureDetail('${t.id}')" class="${tierClass} rounded-2xl p-2 flex flex-col justify-between cursor-pointer active:scale-98">
                  <div class="flex items-center justify-between">
                    <span class="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-white/85" style="color:${t.color}">${t.tierLabel}</span>
                    <span class="text-[10px] font-black text-slate-800">${t.owned ? `Lv.${t.level}` : "Chưa mở"}</span>
                  </div>
                  <div class="my-1.5 text-center">
                    <div class="treasure-art-box mx-auto">${getTreasureSpriteHtml(t, 50)}</div>
                    <div class="text-[11px] font-extrabold text-slate-900 truncate mt-0.5">${t.name}</div>
                  </div>
                  <div class="w-full bg-white/80 rounded-full h-3.5 p-0.5 border border-slate-400/50 relative flex items-center justify-center">
                    <div class="bg-emerald-600 h-full rounded-full absolute left-0 top-0" style="width:${Math.min(100, (t.shards / reqShards) * 100)}%"></div>
                    <span class="relative z-10 text-[9px] font-extrabold text-slate-950">${t.shards}/${reqShards} mảnh</span>
                  </div>
                </div>
              `;
            }).join("")}
          </div>
        </div>

        <!-- Rương Bảo Vật -->
        <div class="bg-amber-50 border-2 border-amber-500/70 rounded-2xl p-2.5 flex items-center justify-between">
          <div>
            <div class="text-xs font-extrabold text-amber-950">🎁 Khai Mở Bảo Rương Thượng Cổ</div>
            <div class="text-[10px] text-amber-800">15 lần chắc chắn Thần Phẩm • 35 lần chắc chắn Tuyệt Phẩm</div>
          </div>
          <button onclick="openTreasureChest()" class="bg-rose-600 hover:bg-rose-500 text-white font-extrabold px-3 py-2 rounded-xl text-xs shadow active:scale-95 shrink-0">
            Mở Rương (50 💎)
          </button>
        </div>
      `;

      openGenericModal("Bộ Sưu Tập Bảo Vật", body);
    }

    function openTreasureDetail(treasureId) {
      const t = gameState.treasures.find(x => x.id === treasureId);
      if (!t) return;
      const reqShards = t.tier === "tuyet" ? (t.level + 1) * 35 : (t.tier === "than" ? (t.level + 1) * 25 : (t.level + 1) * 20);
      const canUpgrade = !t.cannotUpgrade && t.shards >= reqShards;

      const body = `
        <div class="text-center space-y-2">
          <span class="inline-block px-3 py-0.5 rounded-full text-[10px] font-extrabold bg-white border" style="color:${t.color};border-color:${t.color}">
            ${t.tierLabel}
          </span>
          <h4 class="font-serif-title text-base font-bold text-slate-900">${t.name}</h4>
          <p class="text-[11px] text-slate-600 italic bg-white p-2.5 rounded-xl border border-slate-200">"${t.lore}"</p>
          <div class="bg-emerald-50 border border-emerald-600/40 rounded-xl p-2.5 text-left">
            <div class="text-[10px] font-extrabold text-emerald-900 uppercase">Hiệu Quả Gia Trì Toàn Tộc:</div>
            <div class="text-xs font-bold text-emerald-950 mt-0.5">${t.effectDesc}</div>
            <div class="text-[10px] text-slate-600 mt-1">
              Trạng thái hiện tại: <b>${t.cannotUpgrade ? "Bảo vật truyền thừa (Không thể thăng cấp)" : (t.owned ? `Cấp ${t.level}` : "Chưa kích hoạt")}</b>
            </div>
          </div>

          ${!t.cannotUpgrade ? `
            <button onclick="upgradeTreasure('${t.id}')" ${canUpgrade ? "" : "disabled"}
              class="w-full py-2 rounded-xl font-extrabold text-xs shadow ${canUpgrade ? 'bg-emerald-700 text-white active:scale-95' : 'bg-slate-300 text-slate-500'}">
              ${t.owned ? `Thăng Cấp (${t.shards}/${reqShards} mảnh)` : `Ghép Bảo Vật (${t.shards}/${reqShards} mảnh)`}
            </button>
          ` : `
            <div class="py-2 rounded-xl bg-slate-200 text-slate-600 font-extrabold text-xs">
              🔒 Trấn Tộc Chi Bảo Không Thể Thăng Cấp
            </div>
          `}

          <button onclick="openTreasureModal()" class="w-full py-1.5 text-xs font-bold text-emerald-800 underline">
            ‹ Quay lại Bộ Sưu Tập
          </button>
        </div>
      `;
      openGenericModal(`Chi Tiết Bảo Vật`, body);
    }

    function upgradeTreasure(treasureId) {
      const t = gameState.treasures.find(x => x.id === treasureId);
      if (!t || t.cannotUpgrade) return;
      const reqShards = t.tier === "tuyet" ? (t.level + 1) * 35 : (t.tier === "than" ? (t.level + 1) * 25 : (t.level + 1) * 20);
      if (t.shards < reqShards) return;
      t.shards -= reqShards;
      t.owned = true;
      t.level++;
      invalidateAggregateBonuses();
      recalcTeamMaxHp();
      updateAllUI();
      openTreasureDetail(treasureId);
      showToast(`✨ ${t.name} đã thăng lên Cấp ${t.level}!`);
    }

    function openTreasureChest() {
      if (gameState.spiritStones < 50) return showToast("Cần 50 Linh thạch để khai mở Bảo Rương!");
      gameState.spiritStones -= 50;
      gameState.pityThan++;
      gameState.pityTuyet++;

      let chosenTier = "pham";
      if (gameState.pityTuyet >= 35 || Math.random() < 0.03) {
        chosenTier = "tuyet";
        gameState.pityTuyet = 0;
      } else if (gameState.pityThan >= 15 || Math.random() < 0.14) {
        chosenTier = "than";
        gameState.pityThan = 0;
      }

      const pool = gameState.treasures.filter(t => t.tier === chosenTier);
      const item = pool[Math.floor(Math.random() * pool.length)];
      const gainShards = chosenTier === "tuyet" ? 6 : (chosenTier === "than" ? 8 : 12);
      item.shards += gainShards;

      updateAllUI();
      openTreasureModal();
      showToast(`🎁 Mở rương nhận +${gainShards} mảnh [${item.tierLabel}] ${item.name}!`);
    }

    // =========================================================================
    // 14. ĐỘNG PHỦ TU LUYỆN, ĐỘ LÔI KIẾP & ĐAN ĐƯỜNG
    // =========================================================================
    function renderCaveView() {
      s3f2ShowPanel("caveVeinName","cave");
      const m = getValidLivingMember(gameState.activeCultivatorId) || gameState.members.find(x => x.alive);
      if (!m) return;
      gameState.activeCultivatorId = m.id;
      const realm = REALMS[m.realmIdx];
      const nextRealm = REALMS[Math.min(m.realmIdx + 1, REALMS.length - 1)];

      const sel = document.getElementById("selectCultivator");
      if (sel) {
        sel.innerHTML = gameState.members.filter(x => x.alive).map(x =>
          `<option value="${x.id}" ${x.id === m.id ? "selected" : ""}>${escapeHtml(x.name)} (${REALMS[x.realmIdx].name})</option>`
        ).join("");
      }

      document.getElementById("caveVeinName").textContent = `⛰️ Linh Mạch Cấp ${gameState.veinLevel} (+${(gameState.veinLevel * 1.2).toFixed(1)} Tu Vi/thg)`;
      document.getElementById("btnUpgradeVein").textContent = `Nâng Mạch (${gameState.veinLevel * 120} 💎)`;
      document.getElementById("caveAvatarBox").innerHTML = getCultivatorArtHtml(m);
      const identityCard = document.getElementById("caveIdentityCard");
      if (identityCard) {
        const shownAge = Math.floor(Number(m.age) || 0);
        identityCard.innerHTML = `<div class="s2k-identity-portrait">${getCharacterSvg(m, 54)}</div>
          <div class="s2k-identity-info">
            <div class="s2k-identity-name">${escapeHtml(m.name)}</div>
            <div class="s2k-identity-sub">${shownAge} tuổi · ${escapeHtml(realm.name)}</div>
            <div class="s2k-identity-tag">Chân dung cùng tộc nhân trong Gia Phả</div>
          </div>`;
      }
      document.getElementById("caveCharRealm").textContent = realm.name;
      document.getElementById("caveDemonText").textContent = `${m.innerDemon} / 100`;
      document.getElementById("caveXpText").textContent = `${m.xp} / ${realm.maxXp}`;
      document.getElementById("caveXpBar").style.width = `${Math.min(100, (m.xp / realm.maxXp) * 100)}%`;

      const successRate = calcTribulationChance(m);
      const tribButton = document.getElementById("caveTribButton");
      const major = s3e3IsMajorBoundary(m);
      const pillObj = major ? PILLS_DB.find(p => p.id === realm.pillReq) : null;
      const ownedPill = major ? (gameState.pills[realm.pillReq] || 0) : 0;
      if (tribButton) {
        tribButton.disabled = !major || m.xp < realm.maxXp || ownedPill < 1;
        tribButton.style.opacity = major ? "1" : "0.65";
        tribButton.style.cursor = tribButton.disabled ? "default" : "pointer";
      }
      const tribTitle = document.getElementById("caveTribTitle");
      if (tribTitle) tribTitle.textContent = major ? "Độ Đại Kiếp" : "Tự Hành Tu Luyện";
      document.getElementById("caveBreakChance").textContent = major ? `Đại kiếp: ${successRate}%` :
        (m.realmIdx >= REALMS.length - 1 ? "Đã tới đỉnh cảnh giới" : "Tự đột phá khi đủ tu vi");
      document.getElementById("cavePillReq").textContent = major
        ? `Cần ${pillObj ? pillObj.name : "Đan Dược"} (${ownedPill}/1) · ${nextRealm.name}`
        : "Tiểu cảnh giới tự tiến, có thể thất bại / tụt tầng";

      const abodeNames = ["Hàn Môn Động Phủ", "Thanh Vân Linh Phủ", "Tử Khí Tiên Phủ", "Thái Cổ Thánh Địa"];
      document.getElementById("abodeLevelBadge").textContent = `${abodeNames[Math.min(gameState.abodeLevel - 1, 3)]} (${getMaxAbodeCapacity()} chỗ)`;
      document.getElementById("btnUpgradeAbode").textContent = `🏯 Mở Động Phủ (${gameState.abodeLevel * 90} 💎)`;
      document.getElementById("caveHpDetail").textContent = `${gameState.teamHp}/${gameState.teamMaxHp}`;
      document.getElementById("uiHealPillCount").textContent = gameState.healPills;
    }

    function changeActiveCultivator(id) {
      const member = getValidLivingMember(Number(id));
      if (!member) return showToast("Không thể chọn tộc nhân đã tọa hóa.");
      gameState.activeCultivatorId = member.id;
      updateAllUI();
    }

    // Đại cảnh giới được biểu diễn bằng ngưỡng phải dùng đan dược trong REALMS.
    // Không dựa vào số tầng cố định để tránh nhầm Trúc Cơ Sơ/Trung/Hậu.
    function s3e3IsMajorBoundary(m) {
      return !!(m && m.alive && m.realmIdx < REALMS.length - 1 && REALMS[m.realmIdx].pillReq);
    }

    // Tiểu cảnh giới tự vận hành: khi đầy tu vi, mỗi tháng có một lần thử.
    // Thành công: sang tầng kế. Thất bại: mất một phần tu vi. Hiếm khi tụt một tầng nhỏ.
    // Không tụt xuyên đại cảnh giới, không tự vượt ngưỡng bắt buộc dùng đan.
    function s3e3TryMinorBreakthrough(m) {
      if (!m || !m.alive || m.realmIdx >= REALMS.length - 1) return false;
      const current = REALMS[m.realmIdx];
      if (current.pillReq || m.xp < current.maxXp) return false;
      const spiritBonus = Math.round((Number(m.spiritRoot?.xpMult) || 1) * 8);
      const success = Math.max(38, Math.min(88, 65 + spiritBonus - Math.floor((m.innerDemon || 0) * 0.30)));
      const roll = Math.random() * 100;
      if (roll < success) {
        m.realmIdx++;
        m.xp = 0;
        if (m.id === gameState.activeCultivatorId) {
          setTicker(`✨ ${m.name} tự hành tu luyện, đột phá ${REALMS[m.realmIdx].name}!`);
        }
        // Chỉ lưu cột mốc, tránh spam gia phả ở gia tộc đông người.
        return true;
      }
      const regress = roll > 96 && m.realmIdx > 1 &&
        !REALMS[m.realmIdx - 1].pillReq;
      if (regress) {
        m.realmIdx--;
        m.xp = Math.round(REALMS[m.realmIdx].maxXp * 0.55);
        m.innerDemon = Math.min(100, (m.innerDemon || 0) + 10);
        addHistory(`Năm ${gameState.year}: ${m.name} tu hành gặp phản phệ, rơi về ${REALMS[m.realmIdx].name}.`);
      } else {
        m.xp = Math.round(current.maxXp * 0.72);
        m.innerDemon = Math.min(100, (m.innerDemon || 0) + 3);
      }
      return false;
    }

    function calcTribulationChance(m) {
      if (!m || !m.alive) return 0;
      const realm = REALMS[m.realmIdx];
      if (!s3e3IsMajorBoundary(m) || m.xp < realm.maxXp) return 0;
      const base = 78 - m.realmIdx * 3 - m.spiritRoot.tribPenalty - Math.floor(m.innerDemon * 0.4);
      // Huyền Vũ: +10 điểm phần trăm tỷ lệ thành công độ kiếp.
      return Math.max(12, Math.min(95, Math.round(base + getClanAggregateBonuses().tribSave)));
    }

    function getBestAlchemist() {
      return gameState.members
        .filter(member => member.alive && member.alchemyLevel > 0)
        .sort((a, b) => b.alchemyLevel - a.alchemyLevel)[0] || null;
    }

    function getAlchemySuccessChance(pillId) {
      const pill = PILLS_DB.find(item => item.id === pillId);
      if (!pill) return 0;
      const alchemist = getBestAlchemist();
      const alchemistBonus = alchemist ? alchemist.alchemyLevel * 10 : 0;
      return Math.max(0, Math.min(95, Math.round(
        pill.baseRate + alchemistBonus + getClanAggregateBonuses().alchemyPct
      )));
    }

    function absorbSpiritStones() {
      const m = getValidLivingMember(gameState.activeCultivatorId);
      if (!m) return;
      if (gameState.spiritStones < 20) return showToast("Cần 20 Linh thạch để xung mạch tu luyện!");
      gameState.spiritStones -= 20;

      const realm = REALMS[m.realmIdx];
      // Có tỷ lệ tẩu hỏa nhẹ nếu Tâm Ma cao
      if (Math.random() < 0.12 + m.innerDemon * 0.002) {
        m.innerDemon = Math.min(100, m.innerDemon + 12);
        updateAllUI();
        return showToast(`⚠️ Linh khí bạo động! ${m.name} hấp thụ thất bại, Tâm Ma +12.`);
      }

      const gain = Math.round((28 + gameState.veinLevel * 10) * m.spiritRoot.xpMult);
      m.xp = Math.min(realm.maxXp, m.xp + gain);
      m.innerDemon = Math.min(100, m.innerDemon + 4);
      updateAllUI();
      showToast(`✨ ${m.name} hấp thụ Linh thạch nhận +${gain} Tu Vi!`);
    }

    function suppressInnerDemon() {
      const m = getValidLivingMember(gameState.activeCultivatorId);
      if (!m || m.innerDemon <= 0) return showToast("Đạo tâm đang thanh tịnh, không có Tâm Ma!");
      if (gameState.spiritStones < 15) return showToast("Cần 15 Linh thạch thắp thanh tâm hương!");
      gameState.spiritStones -= 15;
      m.innerDemon = Math.max(0, m.innerDemon - 30);
      updateAllUI();
      showToast(`☯️ ${m.name} tĩnh tọa thanh tâm, Tâm Ma giảm 30 điểm.`);
    }

    function attemptTribulation() {
      const m = getValidLivingMember(gameState.activeCultivatorId);
      if (!m) return;
      const realm = REALMS[m.realmIdx];
      if (m.realmIdx >= REALMS.length - 1) return showToast("Đã đạt đỉnh phong cảnh giới hiện tại!");
      if (!s3e3IsMajorBoundary(m)) return showToast("Tiểu cảnh giới tự đột phá theo tháng. Chỉ đại cảnh giới mới cần Độ Kiếp!");
      if (m.xp < realm.maxXp) return showToast(`Chưa đủ Tu Vi (${m.xp}/${realm.maxXp}) để dẫn động Đại Kiếp!`);

      // Kiểm tra đan dược nếu đột phá đại cảnh giới
      if (realm.pillReq) {
        const pillObj = PILLS_DB.find(p => p.id === realm.pillReq);
        if ((gameState.pills[realm.pillReq] || 0) <= 0) {
          return showToast(`Đột phá đại cảnh giới bắt buộc phải có [${pillObj.name}]! Hãy vào Đan Đường luyện chế.`);
        }
        gameState.pills[realm.pillReq]--;
      }

      // Hiệu ứng thiên lôi giáng xuống
      const flash = document.getElementById("lightningEffect");
      if (flash) {
        flash.classList.remove("hidden");
        setTimeout(() => flash.classList.add("hidden"), 500);
      }

      const chance = calcTribulationChance(m);
      if (Math.random() * 100 < chance) {
        m.realmIdx++;
        m.xp = 0;
        m.innerDemon = Math.max(0, m.innerDemon - 20);
        recalcTeamMaxHp();
        gameState.teamHp = gameState.teamMaxHp;
        s3f3FinishAtTribulation(m);
        addHistory(`Năm ${gameState.year}: ${m.name} vượt qua Cửu Thiên Lôi Kiếp, đột phá lên ${REALMS[m.realmIdx].name}!`);
        setTicker(`⚡ Chúc mừng ${m.name} độ kiếp thành công, tấn thăng ${REALMS[m.realmIdx].name}!`);
        updateAllUI();
        showToast(`⚡ ĐỘ KIẾP THÀNH CÔNG! ${m.name} đã đạt ${REALMS[m.realmIdx].name}!`);
      } else {
        m.xp = Math.round(realm.maxXp * 0.65);
        m.innerDemon = Math.min(100, m.innerDemon + 25);
        gameState.teamHp = Math.max(15, Math.round(gameState.teamHp * 0.6));
        updateAllUI();
        showToast(`💥 ĐỘ KIẾP THẤT BẠI! Thiên lôi đánh trọng thương ${m.name}, tổn thất 35% Tu Vi!`);
      }
    }

    function upgradeSpiritVein() {
      const cost = gameState.veinLevel * 120;
      if (gameState.spiritStones < cost) return showToast(`Cần ${cost} Linh thạch để khai thông Linh Mạch!`);
      gameState.spiritStones -= cost;
      gameState.veinLevel++;
      updateAllUI();
      showToast(`⛰️ Linh Mạch gia tộc thăng lên Cấp ${gameState.veinLevel}!`);
    }

    function upgradeAbodeCapacity() {
      const cost = gameState.abodeLevel * 90;
      if (gameState.spiritStones < cost) return showToast(`Cần ${cost} Linh thạch để mở rộng Động Phủ!`);
      gameState.spiritStones -= cost;
      gameState.abodeLevel++;
      updateAllUI();
      showToast(`🏯 Động phủ mở rộng sức chứa lên ${getMaxAbodeCapacity()} tộc nhân!`);
    }

    function useHealingPill() {
      recalcTeamMaxHp();
      if (gameState.teamHp >= gameState.teamMaxHp) return showToast("Sinh lực đội hình đã đầy; không cần dùng Hồi Xuân Đan.");
      if (gameState.healPills <= 0) {
        if (gameState.spiritStones < 25) return showToast("Hết Hồi Xuân Đan và không đủ 25 Linh thạch mua khẩn cấp!");
        gameState.spiritStones -= 25;
        gameState.teamHp = gameState.teamMaxHp;
        updateAllUI();
        return showToast("💊 Đã mua và dùng Hồi Xuân Đan, hồi đầy 100% Sinh Lực!");
      }
      gameState.healPills--;
      gameState.teamHp = gameState.teamMaxHp;
      updateAllUI();
      showToast("💊 Đã dùng Hồi Xuân Đan, Sinh Lực hồi phục 100%!");
    }

    // Đan Đường: Luyện đan từ linh thảo Bí Cảnh + Đan sư bồi dưỡng từ cây gia phả
    function openAlchemyModal() {
      const bestAlchemist = getBestAlchemist();
      const alchemistBonus = bestAlchemist ? bestAlchemist.alchemyLevel * 10 : 0;
      const treasureBonus = getClanAggregateBonuses().alchemyPct;

      const body = `
        <div class="bg-emerald-50 border border-emerald-600/40 rounded-2xl p-2.5">
          <div class="text-xs font-extrabold text-emerald-950">
            Đan Sư Chủ Trì: ${bestAlchemist ? `${escapeHtml(bestAlchemist.name)} (Phẩm ${bestAlchemist.alchemyLevel} • +${alchemistBonus} điểm %)` : "Chưa có (Bồi dưỡng từ Cây Gia Phả)"}
          </div>
          <div class="text-[10px] text-amber-800 font-bold mt-1">Bonus bảo vật: +${treasureBonus} điểm % • Tỷ lệ tối đa: 95%</div>
          <div class="mt-1.5 flex flex-wrap gap-1.5 text-[10px] font-bold">
            <span class="bg-white px-2 py-0.5 rounded border border-slate-300">🌿 Ngọc Tủy Chi: ${gameState.herbs.ngoc_tuy_chi}</span>
            <span class="bg-white px-2 py-0.5 rounded border border-slate-300">🌸 Thiên Tinh Thảo: ${gameState.herbs.thien_tinh_thao}</span>
            <span class="bg-white px-2 py-0.5 rounded border border-slate-300">🌱 Cửu Khúc Tham: ${gameState.herbs.cuu_khuc_tham}</span>
          </div>
        </div>

        <div class="space-y-2">
          ${PILLS_DB.map(p => {
            const herb = HERBS_DB[p.herbId];
            const finalRate = getAlchemySuccessChance(p.id);
            return `
              <div class="bg-white border border-slate-300 rounded-2xl p-2.5 flex items-center justify-between gap-2">
                <div>
                  <div class="text-xs font-extrabold text-slate-900">${p.name} <span class="text-[10px] text-emerald-700">(Đang có: ${gameState.pills[p.id] || 0})</span></div>
                  <div class="text-[10px] text-slate-600">${p.desc}</div>
                  <div class="text-[10px] font-bold text-amber-800 mt-0.5">Cần: ${p.herbCost} ${herb.name} + ${p.stoneCost} 💎 • Tỷ lệ: ${finalRate}%</div>
                </div>
                <button onclick="craftBreakthroughPill('${p.id}')" class="bg-amber-500 text-slate-950 font-extrabold px-3 py-1.5 rounded-xl text-[11px] shadow shrink-0 active:scale-95">
                  Khai Lò
                </button>
              </div>
            `;
          }).join("")}
        </div>
      `;
      openGenericModal("⚗️ Đan Đường Gia Tộc", body);
    }

    function craftBreakthroughPill(pillId) {
      const pill = PILLS_DB.find(item => item.id === pillId);
      if (!pill) return;
      const successRate = getAlchemySuccessChance(pillId);
      if ((gameState.herbs[pill.herbId] || 0) < pill.herbCost) return showToast("Không đủ linh thảo hiếm từ Bí Cảnh!");
      if (gameState.spiritStones < pill.stoneCost) return showToast(`Cần ${pill.stoneCost} Linh thạch để duy trì địa hỏa luyện đan!`);

      // Giá và tỷ lệ được tính lại từ state tại thời điểm xác nhận.
      gameState.herbs[pill.herbId] -= pill.herbCost;
      gameState.spiritStones -= pill.stoneCost;
      if (Math.random() * 100 < successRate) {
        gameState.pills[pillId] = (gameState.pills[pillId] || 0) + 1;
        addHistory(`Năm ${gameState.year}: Luyện chế thành công ${pill.name} (${successRate}% tỷ lệ).`);
        updateAllUI();
        openAlchemyModal();
        showToast(`🎉 KHAI LÒ THÀNH ĐAN! Nhận được 1 viên ${pill.name}!`);
      } else {
        addHistory(`Năm ${gameState.year}: Luyện chế thất bại ${pill.name} (${successRate}% tỷ lệ).`);
        updateAllUI();
        openAlchemyModal();
        showToast("💥 Nổ lò thất bại! Linh thảo hóa thành tro bụi.");
      }
      saveGameToLocal({ silent: true, closeModal: false });
    }

    // ===== Sprint 3F.4.1: Gia Tộc Phong Vân + lịch luyện tự động =====
    function s3f4Policy(){return gameState.s3f4Expedition||(gameState.s3f4Expedition={enabled:false,permittedIds:[],minHpPct:60,everyMonths:5,realmId:'',lastMonth:-100,total:0,victories:0,deaths:0});}
    function s3f4Politics(){return gameState.s3f4Politics||(gameState.s3f4Politics={lastMonth:-100,nextType:0,marks:{},feud:0,alliance:0,school:0,recorded:[]});}
    function s3f4SetPermit(id){
      const m=getValidLivingMember(Number(id)),p=s3f4Policy();
      if(!m||m.age<18)return showToast('Chỉ chọn tộc nhân từ 18 tuổi.');
      if(p.permittedIds.includes(m.id))p.permittedIds=p.permittedIds.filter(x=>x!==m.id);
      else p.permittedIds.push(m.id);
      if(p.enabled&&!p.permittedIds.length)p.enabled=false;
      markGameDirty();updateAllUI();
    }
    function s3f4ExpeditionToggle(){
      const p=s3f4Policy();
      if(!p.enabled&&!p.permittedIds.some(id=>{const m=getValidLivingMember(id);return m&&m.age>=18;}))return showToast('Gia chủ phải cho phép ít nhất một tộc nhân từ 18 tuổi.');
      p.enabled=!p.enabled;p.lastMonth=getMonthIndex();markGameDirty();updateAllUI();
      showToast(p.enabled?'Đã bật lịch luyện tự động, tối đa một chuyến mỗi kỳ.':'Đã tắt lịch luyện tự động.');
    }
    function s3f4SetExpeditionSetting(key,value){
      const p=s3f4Policy();
      if(key==='realmId' && (value===''||SECRET_REALMS.some(r=>r.id===value)))p.realmId=value;
      if(key==='minHpPct')p.minHpPct=Math.max(30,Math.min(90,Number(value)||60));
      if(key==='everyMonths')p.everyMonths=Math.max(3,Math.min(12,Number(value)||5));
      markGameDirty();updateAllUI();
    }
    function s3f4ExpeditionPanel(){
      const p=s3f4Policy(),adults=gameState.members.filter(m=>m.alive&&m.age>=18);
      const opts=adults.map(m=>`<button type="button" onclick="s3f4SetPermit(${m.id})" class="text-[10px] rounded-lg border px-2 py-1.5 ${p.permittedIds.includes(m.id)?'bg-emerald-100 border-emerald-600':'bg-white border-slate-300'}">${p.permittedIds.includes(m.id)?'✅':'⬜'} ${escapeHtml(m.name)} · ${REALMS[m.realmIdx].name}</button>`).join('');
      return `<section class="p-3 mb-3 rounded-xl border-2 border-emerald-600 bg-emerald-50 space-y-2" data-s3f4-auto>
        <div class="font-extrabold text-xs text-emerald-950">🧭 Tự Lịch Luyện · Gia Chủ Phê Chuẩn</div>
        <div class="text-[10px] text-slate-700">Chỉ người ≥18 tuổi đã được duyệt. Hệ thống tự chọn tối đa 4 người mạnh nhất trong danh sách đủ điều kiện. Thua trận có thể thoát thân hoặc tử nạn. Mặc định TẮT.</div>
        <div class="flex flex-wrap gap-1">${opts||'<span class="text-[10px]">Chưa có tộc nhân trưởng thành.</span>'}</div>
        <label class="text-[10px] block">Bí Cảnh: <select class="border rounded p-1 max-w-full" onchange="s3f4SetExpeditionSetting('realmId',this.value)"><option value="">Tự chọn Bí Cảnh phù hợp</option>${SECRET_REALMS.map(r=>`<option value="${r.id}" ${p.realmId===r.id?'selected':''}>${escapeHtml(r.name)}</option>`).join('')}</select></label>
        <div class="flex flex-wrap gap-2 text-[10px]"><label>Máu tối thiểu <select class="border rounded" onchange="s3f4SetExpeditionSetting('minHpPct',this.value)">${[40,50,60,70,80,90].map(n=>`<option value="${n}" ${p.minHpPct===n?'selected':''}>${n}%</option>`).join('')}</select></label>
        <label>Chu kỳ <select class="border rounded" onchange="s3f4SetExpeditionSetting('everyMonths',this.value)">${[3,4,5,6,9,12].map(n=>`<option value="${n}" ${p.everyMonths===n?'selected':''}>${n} tháng</option>`).join('')}</select></label></div>
        <button onclick="s3f4ExpeditionToggle()" class="rounded-lg px-3 py-2 text-xs font-extrabold ${p.enabled?'bg-rose-700 text-white':'bg-emerald-800 text-white'}">${p.enabled?'⏹ TẮT tự lịch luyện':'▶ BẬT tự lịch luyện'}</button>
        <div class="text-[10px]">Đã đi ${p.total} chuyến · Thắng ${p.victories} · Tử nạn ${p.deaths}. Thủ công có thể xuất chinh từ 20% máu.</div>
      </section>`;
    }
    // Mỗi đòn kiểm tra né → bạo → sát thương riêng. Liên kích chỉ có tối đa 2 đòn.
    function s3f4RollAttack(atk,def,crit,combo,dodge,mult=1,minDmg=8,defFactor=.45,critMult=1.75){
      const chance=x=>Math.max(0,Math.min(100,Number(x)||0));
      const strikes=Math.random()*100<chance(combo)?2:1;
      let damage=0,crits=0,evades=0;
      for(let i=0;i<strikes;i++){
        if(Math.random()*100<chance(dodge)){evades++;continue;}
        const critical=Math.random()*100<chance(crit);if(critical)crits++;
        const base=Math.max(minDmg,atk*mult-def*defFactor);
        damage+=Math.max(1,Math.round(base*(critical?critMult:1)*(.9+Math.random()*.2)));
      }
      return {damage,strikes,crits,evades};
    }
    function s3f4KillMember(m){
      if(!m||!m.alive)return;
      m.alive=false;m.deathYear=gameState.year;
      addHistory(`Năm ${gameState.year}: ${m.name} tử nạn khi lịch luyện Bí Cảnh, gia phả ghi nhớ hậu quả này.`);
      if(m.id===gameState.clanLeaderId){s3fSealLeaderLegacy(m);gameState.clanLeaderId=null;}
      if(m.id===gameState.heirId)gameState.heirId=null;
      if(m.id===gameState.activeCultivatorId)gameState.activeCultivatorId=null;
      gameState.squadIds=gameState.squadIds.filter(id=>id!==m.id);
      gameState.estates.forEach(e=>{if(e.guardianId===m.id)e.guardianId=null;});
    }
    function s3f4ResolveDefeat(ids,heroSpd,enemySpd,auto){
      let escaped=0,dead=0;
      for(const id of ids){
        const m=getValidLivingMember(id);if(!m)continue;
        const dodge=getMemberStats(m).dodge;
        // Bảo toàn hầu hết thành viên, nhưng rủi ro tử vong thực sự phụ thuộc thân pháp.
        const chance=Math.max(42,Math.min(93,67+(heroSpd-enemySpd)*.025+dodge*.18));
        if(Math.random()*100<chance){escaped++;m.innerDemon=Math.min(100,(m.innerDemon||0)+2);}
        else{s3f4KillMember(m);dead++;}
      }
      ensureClanLeadership();
      if(!gameState.members.some(m=>m.alive))gameState.clanExtinct=true;
      if(auto)s3f4Policy().deaths+=dead;
      addHistory(`Năm ${gameState.year}: Bí Cảnh thảm bại; ${escaped} người đào thoát, ${dead} người thân tử đạo tiêu.`);
      return {escaped,dead};
    }
    function s3f4AutoExpeditionMonth(){
      const p=s3f4Policy();
      if(!p.enabled||gameState.pendingAdventure||battleState||gameState.clanExtinct||!gameState.started)return;
      const now=getMonthIndex();if(now-p.lastMonth<p.everyMonths)return;
      const eligible=p.permittedIds.map(id=>getValidLivingMember(id)).filter(m=>m&&m.age>=18)
        .sort((a,b)=>getMemberStats(b).power-getMemberStats(a).power).slice(0,4);
      if(!eligible.length){p.enabled=false;return;}
      // Không phá đội thủ công đang cấu hình: tự mô phỏng trên đội đã duyệt.
      const totalMax=eligible.reduce((n,m)=>n+getMemberStats(m).hp,0);
      const hpPct=gameState.teamHp/Math.max(1,gameState.teamMaxHp);
      if(hpPct<p.minHpPct/100)return;
      const tier=Math.max(...eligible.map(m=>m.realmIdx));
      const realm=(p.realmId?SECRET_REALMS.find(r=>r.id===p.realmId):null) ||
        [...SECRET_REALMS].filter(r=>r.minRealm<=tier&&tier<=r.maxRealm).sort((a,b)=>b.minRealm-a.minRealm)[0]||SECRET_REALMS[0];
      if(!realm)return;
      const strongest=eligible[0],n=eligible.length;
      const st=eligible.map(getMemberStats),atk=st.reduce((x,s)=>x+s.atk,0)*(1+s3f2FamilySquadBonus(eligible)),def=st.reduce((x,s)=>x+s.def,0),spd=st.reduce((x,s)=>x+s.spd,0);
      const avg=k=>st.reduce((x,s)=>x+s[k],0)/n;
      const enemyIdx=Math.min(REALMS.length-1,Math.max(realm.minRealm,tier+(Math.random()<.4?1:0)));
      const e=REALMS[enemyIdx],tpl=realm.enemyPool[Math.floor(Math.random()*realm.enemyPool.length)];
      const enemy={hp:Math.round(e.baseHp*tpl.hpMult*(1+(n-1)*.55)),atk:Math.round(e.baseAtk*tpl.atkMult*(1+(n-1)*.35)),def:Math.round(e.baseDef*tpl.defMult),spd:Math.round(e.baseSpd*1.05),dodge:6+enemyIdx*.6,crit:8+enemyIdx*.7,combo:Math.min(25,4+enemyIdx*1.1)};
      const foeMax=enemy.hp,heroMax=Math.max(80,totalMax);let hp=Math.max(1,Math.round(heroMax*hpPct));
      let rounds=0;for(;rounds<60&&hp>0&&enemy.hp>0;rounds++){
        const heroAttack=()=>{const r=s3f4RollAttack(atk,enemy.def,avg('crit'),avg('combo'),enemy.dodge);enemy.hp=Math.max(0,enemy.hp-r.damage);hp=Math.min(heroMax,hp+Math.round(r.damage*avg('lifesteal')/100));};
        const enemyAttack=()=>{const r=s3f4RollAttack(enemy.atk,def,enemy.crit,enemy.combo,avg('dodge'),1,6,.42,1.6);hp=Math.max(0,hp-r.damage);};
        if(spd>=enemy.spd){heroAttack();if(enemy.hp>0)enemyAttack();}
        else{enemyAttack();if(hp>0)heroAttack();}
      }
      p.lastMonth=now;p.total++;
      if(enemy.hp<=0){
        p.victories++;
        const stone=realm.stoneReward[0]+Math.floor(Math.random()*(realm.stoneReward[1]-realm.stoneReward[0]+1));
        const gain=tier>realm.maxRealm?0:Math.round(stone*(1+s3f2LinkBonuses().allyStonePct));
        gameState.spiritStones=safeNumber(gameState.spiritStones+gain,0,0,GAME_CONFIG.maxResource);
        const herb=HERBS_DB[realm.herbDrop];
        if(herb&&Math.random()<herb.rate)gameState.herbs[herb.id]=(gameState.herbs[herb.id]||0)+1;
        // Phục hồi/hao sinh lực được giữ trong thanh máu đội khi đang sử dụng đội tương ứng.
        gameState.teamHp=Math.max(1,Math.round(gameState.teamMaxHp*(hp/heroMax)));
        s3f3DiscoverFromVictory({overleveled:tier>realm.maxRealm});
        addHistory(`Năm ${gameState.year} tháng ${gameState.month}: Tự lịch luyện ${realm.name} thắng sau ${rounds+1} hiệp; thu ${gain} linh thạch.`);
        setTicker(`🏆 Đội tự lịch luyện thắng tại ${realm.name}, +${gain} linh thạch.`);
      }else{
        const fate=s3f4ResolveDefeat(eligible.map(m=>m.id),spd,enemy.spd,true);
        gameState.teamHp=Math.max(1,Math.round(gameState.teamMaxHp*.1));
        setTicker(`⚠️ Tự lịch luyện thất bại: ${fate.escaped} người thoát, ${fate.dead} người tử nạn.`);
      }
      markGameDirty();
    }
    function s3f4PoliticalOutcome(kind,route,member){
      const p=s3f4Politics(),f=gameState.factions[0];
      p.marks[kind]=true;
      let result='';
      if(kind==='resource'){
        if(route==='negotiate'){
          if(gameState.spiritStones>=30){gameState.spiritStones-=30;f.relation=Math.min(100,f.relation+8);p.alliance=Math.min(6,p.alliance+1);result='Nhượng 30 linh thạch, lập hòa ước thương mại. Cơ Nghiệp được hỗ trợ.';}
          else{p.feud=Math.min(6,p.feud+1);result='Không đủ linh thạch hòa giải, tranh chấp trở nên căng thẳng.';}
        }else{f.relation=Math.max(0,f.relation-12);gameState.spiritStones+=45;p.feud=Math.min(6,p.feud+1);result='Giành được mỏ (+45 linh thạch) nhưng để lại huyết cừu với thế lực ngoài.';}
      }else if(kind==='marriage'){
        if(route==='accept'){
          const candidate=gameState.members.filter(m=>m.alive&&m.age>=18&&!m.spouseId&&!m.isMarriedIn&&m.id!==member.id)[0]||
            (member.age>=18&&!member.spouseId&&!member.isMarriedIn?member:null);
          f.relation=Math.min(100,f.relation+6);p.alliance=Math.min(6,p.alliance+1);
          result=candidate?`Gia Chủ chấp thuận đề nghị liên minh (+6 hảo cảm). ${candidate.name} có thể được mai mối ở mục Kết Đạo Lữ; chưa tự phát sinh hôn nhân.`:'Gia Chủ lập minh ước ngoại giao (+6 hảo cảm), chưa có ứng viên phù hợp hoặc chưa đủ sức chứa để kết hôn.';
        }
        else{f.relation=Math.max(0,f.relation-5);member.familyBond=Math.min(100,(member.familyBond??40)+5);result='Giữ quyền tự định hôn duyên cho hậu duệ (+5 tình thân); quan hệ đối ngoại giảm nhẹ.';}
      }else{
        if(route==='reconcile'){p.school=Math.min(6,p.school+1);member.familyBond=Math.min(100,(member.familyBond??40)+6);result='Hòa giải sư môn, hậu duệ được nâng tình thân và lưu lại lời giáo huấn.';}
        else{member.innerDemon=Math.min(100,(member.innerDemon||0)+4);member.xp+=35;p.feud=Math.min(6,p.feud+1);result='Tranh luận đạo pháp gay gắt, +35 tu vi nhưng +4 Tâm Ma; gieo mầm ân oán.';}
      }
      p.recorded.push(`Năm ${gameState.year}: ${result}`);p.recorded=p.recorded.slice(-30);
      addHistory(`Năm ${gameState.year}: [Gia Tộc Phong Vân] ${result}`);return result;
    }
    ADVENTURE_TEMPLATES.push(
      {id:'s3f41_request',title:'Gia Đạo · Xin Phép Cầu Tự',isS3E2:true,
        desc:m=>{const c=s3f41Couple(m);return c?`<b>${escapeHtml(c.father.name)}</b> và <b>${escapeHtml(c.mother.name)}</b> xin Gia Chủ chuẩn y một lần mang thai. Động Phủ còn ${Math.max(0,getMaxAbodeCapacity()-getAliveCount()-gameState.familyPregnancies.length)} chỗ. Không có con nào được tạo nếu chưa phê duyệt.`:'Cặp đạo lữ không còn đủ điều kiện.';},
        choices:[{id:'approve',label:'Chuẩn y cầu tự — dự sinh sau 9 tháng',baseRate:100,onSuccess:m=>s3f41ApproveConception(m,true),onFail:m=>s3f41ApproveConception(m,true)},
        {id:'delay',label:'Hoãn cầu tự — ít nhất 12 tháng sau mới xin lại',baseRate:100,onSuccess:m=>s3f41ApproveConception(m,false),onFail:m=>s3f41ApproveConception(m,false)}]},
      {id:'s3f41_birth',title:'Gia Đạo · Huyết Mạch Giáng Sinh',isS3E2:true,
        desc:m=>`<b>${escapeHtml(m.name)}</b> đến ngày lâm bồn. Gia Chủ chọn cách hộ sản. An Thai Đan hiện có: <b>${gameState.anThaiPills||0}</b>. Tỷ lệ gốc: thuận tự nhiên 90% bình an, mời y sư 96%, An Thai Đan 98%; tu vi cao có thể hỗ trợ thêm.`,
        choices:[{id:'normal',label:'Thuận tự nhiên — không tốn linh thạch',baseRate:100,onSuccess:m=>s3f41PregnancyResult(m.id,'normal'),onFail:m=>s3f41PregnancyResult(m.id,'normal')},
        {id:'healer',label:'Mời y sư hộ sản — 20 linh thạch',baseRate:100,onSuccess:m=>s3f41PregnancyResult(m.id,'healer'),onFail:m=>s3f41PregnancyResult(m.id,'healer')},
        {id:'pill',label:'Dùng An Thai Đan — 1 viên',baseRate:100,onSuccess:m=>s3f41PregnancyResult(m.id,'pill'),onFail:m=>s3f41PregnancyResult(m.id,'pill')}]}
    );

    const S3F4_POLITICS=[
      {id:'resource',title:'Linh Mỏ Tranh Phong',desc:'Linh khoáng ở biên địa bị thế lực láng giềng đòi chia phần. Nội Chính phải chọn ngoại giao hay tranh đoạt.',choices:[['negotiate','Hòa giải bằng 30 linh thạch; giữ thương lộ'],['seize','Giành quyền khai mỏ; nhận 45 linh thạch nhưng gây thù']]},
      {id:'marriage',title:'Minh Ước Thông Gia',desc:'Một thế lực lớn ngỏ lời liên minh bằng hôn ước. Gia chủ quyết định có thiết lập minh ước danh nghĩa hay giữ quyền lựa chọn cho hậu duệ.',choices:[['accept','Chấp nhận thông gia nếu có người độc thân và chỗ ở; nếu không lập minh ước'],['decline','Khước từ, để hậu duệ tự chọn đạo lữ']]},
      {id:'school',title:'Sư Môn Bất Hòa',desc:'Hai nhánh truyền đạo tranh luận công pháp; nếu không hòa giải, Tâm Ma và ân oán có thể kéo dài nhiều thế hệ.',choices:[['reconcile','Hòa giải sư môn, ổn định tình thân'],['challenge','Cho phép đấu luận đạo pháp, chấp nhận rủi ro Tâm Ma']]}
    ];
    ADVENTURE_TEMPLATES.push(...S3F4_POLITICS.map(c=>({
      id:'s3f4_'+c.id,title:'Gia Tộc Phong Vân · '+c.title,isS3E2:true,
      desc:m=>`<b>${escapeHtml(m.name)}</b> thay mặt gia tộc quyết định: ${c.desc} Những hệ quả sẽ còn được ghi nhận qua các đời.`,
      choices:c.choices.map(([id,label])=>({id,label,baseRate:100,
        onSuccess:m=>s3f4PoliticalOutcome(c.id,id,m),onFail:m=>s3f4PoliticalOutcome(c.id,id,m)}))
    })));
    function s3f4DispatchPolitics(){
      if(!gameState.started||gameState.pendingAdventure||battleState||gameState.clanExtinct)return false;
      const p=s3f4Politics(),now=getMonthIndex();
      if(now-p.lastMonth<18)return false;
      const leader=getValidLivingMember(gameState.clanLeaderId);if(!leader)return false;
      for(let d=0;d<3;d++){
        const idx=(p.nextType+d)%3,c=S3F4_POLITICS[idx];
        if(p.marks[c.id])continue;
        if(c.id==='resource'&&!gameState.estates.some(e=>e.id==='linh_mo'&&e.level>=2))continue;
        if(c.id==='school'&&!gameState.members.some(m=>m.alive&&m.mentorId))continue;
        p.nextType=(idx+1)%3;p.lastMonth=now;
        gameState.pendingAdventure={eventId:'s3f4_'+c.id,memberId:leader.id,context:{},createdAtMonthIndex:now};
        markGameDirty();renderAdventureModal();return true;
      }
      return false;
    }

    // =========================================================================
    // 15. BÍ CẢNH & CHIẾN ĐẤU THỦY MẶC (8 CHỈ SỐ + AUTO + ĐÁNH TRƯỢT/BẠO/LIÊN)
    // =========================================================================
    function renderSecretRealmsView() {
      s3f2ShowPanel("secretRealmsList","secret");
      recalcTeamMaxHp();
      const isFullHp = gameState.teamHp >= gameState.teamMaxHp;
      const badge = document.getElementById("secretHpBadge");
      if (badge) {
        badge.textContent = `❤️ Sinh lực ${gameState.teamHp}/${gameState.teamMaxHp} (${Math.round(gameState.teamHp/Math.max(1,gameState.teamMaxHp)*100)}%) — từ 20% được xuất chinh`;
        badge.className = gameState.teamHp/gameState.teamMaxHp>=.2 ? 'text-xs font-extrabold text-emerald-700' : 'text-xs font-extrabold text-rose-600';
      }
      document.getElementById("uiHealPillCount2").textContent = gameState.healPills;

      // Danh sách chọn thành viên tổ đội
      const aliveMembers = gameState.members.filter(m => m.alive && m.age>=18);
      let totalPower = 0;
      const squadHtml = aliveMembers.map(m => {
        const selected = gameState.squadIds.includes(m.id);
        const st = getMemberStats(m);
        if (selected) totalPower += st.power;
        return `
          <button onclick="toggleSquadMember(${m.id})"
            class="flex items-center gap-1.5 p-1.5 rounded-xl border text-left transition ${selected ? 'bg-emerald-100 border-emerald-700' : 'bg-slate-50 border-slate-300 opacity-75'}">
            ${getCharacterSvg(m, 30)}
            <div class="min-w-0 flex-1">
              <div class="text-[10px] font-extrabold text-slate-900 truncate">${escapeHtml(m.name)}</div>
              <div class="text-[9px] text-emerald-800 font-semibold">${REALMS[m.realmIdx].name} • CL ${st.power}</div>
            </div>
            <span class="text-xs font-black">${selected ? "✅" : "⬜"}</span>
          </button>
        `;
      }).join("");
      document.getElementById("squadSelectorList").innerHTML = squadHtml;
      document.getElementById("squadPowerBadge").textContent = `Chiến lực: ${totalPower}`;

      // Danh sách Bí Cảnh
      const realmsHtml = SECRET_REALMS.map(r => {
        const herb = HERBS_DB[r.herbDrop];
        return `
          <div class="bg-white/95 rounded-2xl border-2 border-emerald-700/50 p-3 shadow-sm flex items-center justify-between gap-2">
            <div>
              <div class="text-xs font-extrabold text-emerald-950">${r.name}</div>
              <div class="text-[10px] font-bold text-amber-700">${r.tierLabel}</div>
              <div class="text-[10px] text-slate-600 mt-0.5">
                Thưởng: ${r.stoneReward[0]}–${r.stoneReward[1]} 💎 • Rơi hiếm: <b>${herb.name} (${(herb.rate * 100).toFixed(1)}%)</b>
              </div>
            </div>
            <button onclick="enterSecretRealm('${r.id}')"
              class="px-3 py-2 rounded-xl font-extrabold text-xs shadow shrink-0 active:scale-95 ${gameState.teamHp/gameState.teamMaxHp>=.2 ? 'bg-emerald-700 text-white' : 'bg-slate-300 text-slate-600'}">
              Xuất Chinh
            </button>
          </div>
        `;
      }).join("");
      document.getElementById("secretRealmsList").innerHTML = s3f4ExpeditionPanel()+realmsHtml;
    }

    function toggleSquadMember(id) {
      const memberId = Number(id);
      const chosen=getValidLivingMember(memberId);
      if (!chosen||chosen.age<18) return showToast('Chỉ tộc nhân từ 18 tuổi còn sống mới được đi lịch luyện.');
      const idx = gameState.squadIds.indexOf(memberId);
      if (idx >= 0) {
        if (gameState.squadIds.length <= 1) return showToast("Tổ đội phải có ít nhất 1 tu sĩ!");
        gameState.squadIds.splice(idx, 1);
      } else {
        if (gameState.squadIds.length >= GAME_CONFIG.maxSquadSize) return showToast("Tối đa 4 tu sĩ trong một tổ đội!");
        gameState.squadIds.push(memberId);
      }
      recalcTeamMaxHp();
      gameState.teamHp = Math.min(gameState.teamHp, gameState.teamMaxHp);
      updateAllUI();
    }

    function enterSecretRealm(realmId) {
      recalcTeamMaxHp();
      if(gameState.teamHp<=0)return showToast('Tổ đội đã kiệt sức; cần dưỡng thương trước khi vào Bí Cảnh.');
      if(gameState.teamHp/gameState.teamMaxHp<0.2)return showToast('Sinh lực dưới 20%, quá nguy hiểm. Hãy hồi phục thêm.');

      const realmCfg = SECRET_REALMS.find(r => r.id === realmId);
      const squad = gameState.squadIds
        .map(id => getValidLivingMember(id))
        .filter(Boolean);
      if (squad.length === 0) return;

      // Tổng hợp 8 chỉ số của tổ đội
      let totalAtk = 0, totalDef = 0, totalSpd = 0;
      let avgLifesteal = 0, avgDodge = 0, avgCrit = 0, avgCombo = 0;
      let highestRealm = 0;

      squad.forEach(m => {
        const st = getMemberStats(m);
        totalAtk += st.atk;
        totalDef += st.def;
        totalSpd += st.spd;
        avgLifesteal += st.lifesteal;
        avgDodge += st.dodge;
        avgCrit += st.crit;
        avgCombo += st.combo;
        if (m.realmIdx > highestRealm) highestRealm = m.realmIdx;
      });

      const n = squad.length;
      avgLifesteal = +(avgLifesteal / n).toFixed(1);
      avgDodge = +(avgDodge / n).toFixed(1);
      avgCrit = +(avgCrit / n).toFixed(1);
      avgCombo = +(avgCombo / n).toFixed(1);

      // Sinh Yêu Thú / Tà Tu cấp ngang hoặc hơn 1 cấp so với đội hình, máu trâu
      const enemyRealmIdx = Math.min(REALMS.length - 1, Math.max(realmCfg.minRealm, highestRealm + (Math.random() < 0.45 ? 1 : 0)));
      const enemyBase = REALMS[enemyRealmIdx];
      const tpl = realmCfg.enemyPool[Math.floor(Math.random() * realmCfg.enemyPool.length)];

      const enemyMaxHp = Math.round(enemyBase.baseHp * tpl.hpMult * (1 + (n - 1) * 0.55));
      const enemyAtk = Math.round(enemyBase.baseAtk * tpl.atkMult * (1 + (n - 1) * 0.35));
      const enemyDef = Math.round(enemyBase.baseDef * tpl.defMult);
      const enemySpd = Math.round(enemyBase.baseSpd * 1.05);

      const leadHero = squad[0];
      const isOverleveled = highestRealm > realmCfg.maxRealm;
      const cross=s3f2LinkBonuses();
      const attackMultiplier=1+cross.forgeAtkPct+s3f2FamilySquadBonus(squad);

      battleState = {
        realmCfg,
        turn: 1,
        auto: false,
        overleveled: isOverleveled,
        heroName: squad.length > 1 ? `${leadHero.name} (+${squad.length - 1})` : leadHero.name,
        heroObj: leadHero,
        heroHp: gameState.teamHp,
        heroMaxHp: gameState.teamMaxHp,
        heroAtk: Math.round(totalAtk*attackMultiplier),
        heroDef: totalDef,
        heroSpd: totalSpd,
        heroLifesteal: avgLifesteal,
        heroDodge: avgDodge,
        heroCrit: avgCrit,
        heroCombo: avgCombo,
        enemyName: `${tpl.name} (${enemyBase.name})`,
        enemyType: tpl.type,
        enemyHp: enemyMaxHp,
        enemyMaxHp: enemyMaxHp,
        enemyAtk,
        enemyDef,
        enemySpd,
        enemyDodge: 6 + enemyRealmIdx * 0.6,
        enemyCrit: 8 + enemyRealmIdx * 0.7,
        enemyCombo: Math.min(25,4+enemyRealmIdx*1.1),
        squadIds:squad.map(m=>m.id)
      };

      document.getElementById("battleScreen").classList.remove("hidden");
      document.getElementById("battleRealmTitle").textContent = `${realmCfg.name} • ${realmCfg.tierLabel}`;
      document.getElementById("battleHeroSprite").innerHTML = getCharacterSvg(leadHero, 96);
      document.getElementById("battleEnemySprite").innerHTML = getEnemyBeastSvg(tpl.type, 108, tpl.name);
      document.getElementById("battleLogBox").innerHTML = `<div class="font-bold text-emerald-900">⚔️ Tiến nhập ${realmCfg.name}! Chạm trán ${battleState.enemyName} (HP ${enemyMaxHp}).</div>`;
      updateBattleUI();
    }

    function getEnemyBeastSvg(type, size = 96, enemyName = "") {
      const name = String(enemyName || "");
      let row = 2, col = 2; // Bạch Hổ mặc định
      if (type === "rogue") {
        if (name.includes("U Minh")) { row = 1; col = 2; }
        else { row = 1; col = 0; }
      } else if (name.includes("Huyết Lang")) { row = 0; col = 0; }
      else if (name.includes("Xích Hỏa")) { row = 0; col = 2; }
      else if (name.includes("Thái Cổ Lôi Viên")) { row = 1; col = 1; }
      else if (name.includes("Thanh Long")) { row = 2; col = 0; }
      else if (name.includes("Chu Tước")) { row = 2; col = 1; }
      const posX = col * 50;
      const posY = row * 50;
      const safeSize = Math.max(48, Math.min(180, Number(size) || 96));
      return `<span class="monster-sprite" role="img" aria-label="${escapeHtml(name || "Yêu thú bí cảnh")}" style="width:${safeSize}px;height:${safeSize}px;background-position:${posX}% ${posY}%"></span>`;
    }

    function updateBattleUI() {
      if (!battleState) return;
      document.getElementById("battleTurnText").textContent = `Hiệp ${battleState.turn} • Tốc độ: ${battleState.heroSpd} vs ${battleState.enemySpd}`;
      document.getElementById("battleHeroName").textContent = battleState.heroName;
      document.getElementById("battleHeroHpNum").textContent = `${Math.max(0, battleState.heroHp)}/${battleState.heroMaxHp}`;
      document.getElementById("battleHeroHpBar").style.width = `${Math.max(0, (battleState.heroHp / battleState.heroMaxHp) * 100)}%`;

      document.getElementById("battleEnemyName").textContent = battleState.enemyName;
      document.getElementById("battleEnemyHpNum").textContent = `${Math.max(0, battleState.enemyHp)}/${battleState.enemyMaxHp}`;
      document.getElementById("battleEnemyHpBar").style.width = `${Math.max(0, (battleState.enemyHp / battleState.enemyMaxHp) * 100)}%`;

      const autoBtn = document.getElementById("btnBattleAuto");
      if (autoBtn) {
        autoBtn.textContent = battleState.auto ? "🤖 Auto: BẬT" : "🤖 Auto: TẮT";
        autoBtn.className = battleState.auto
          ? "px-2.5 py-1 rounded-lg bg-amber-400 text-slate-950 text-[11px] font-black border border-amber-200"
          : "px-2.5 py-1 rounded-lg bg-slate-700 text-white text-[11px] font-extrabold border border-white/30";
      }
    }

    function toggleBattleAuto() {
      if (!battleState) return;
      battleState.auto = !battleState.auto;
      if (battleAutoTimer) {
        clearInterval(battleAutoTimer);
        battleAutoTimer = null;
      }
      updateBattleUI();
      if (battleState.auto) {
        battleAutoTimer = setInterval(() => {
          if (!battleState || !battleState.auto) {
            if (battleAutoTimer) clearInterval(battleAutoTimer);
            battleAutoTimer = null;
            return;
          }
          executeBattleRound("normal", "auto");
        }, 850);
      }
    }

    function appendBattleLog(text, colorClass = "text-slate-800") {
      const box = document.getElementById("battleLogBox");
      if (!box) return;
      const line = document.createElement("div");
      line.className = colorClass;
      line.innerHTML = text;
      box.appendChild(line);
      box.scrollTop = box.scrollHeight;
    }

    function executeBattleRound(mode, source = "manual") {
      if (!battleState || battleActionLock) return;
      if (source === "auto" && (!battleState.auto || !battleAutoTimer)) return;
      if (battleAutoTimer && source !== "auto") {
        return showToast("Đang tự động chiến đấu; hãy tắt Auto trước khi thao tác thủ công.");
      }
      battleActionLock = true;
      try {
        let skillMult = 1;
        if (mode === "skill") {
          if (gameState.spiritStones < 12) {
            showToast("Không đủ 12 Linh thạch để tế Pháp Bảo!");
            return;
          }
          gameState.spiritStones -= 12;
          skillMult = 1.65;
        }

        const heroFirst = battleState.heroSpd >= battleState.enemySpd;
        if (heroFirst) {
          performHeroAttack(skillMult);
          if (battleState && battleState.enemyHp > 0) performEnemyAttack();
        } else {
          performEnemyAttack();
          if (battleState && battleState.heroHp > 0) performHeroAttack(skillMult);
        }

        if (!battleState) return;
        battleState.turn++;
        updateBattleUI();
      } finally {
        battleActionLock = false;
      }
    }

    function performHeroAttack(skillMult) {
      if (!battleState) return;
      // Mỗi đòn (kể cả liên kích) đều thử né tránh, bạo kích và biến thiên sát thương riêng.
      const roll=s3f4RollAttack(battleState.heroAtk,battleState.enemyDef,
        battleState.heroCrit,battleState.heroCombo,battleState.enemyDodge,skillMult,8);
      const strikes=roll.strikes,totalDmg=roll.damage,isCrit=roll.crits>0;
      if(roll.evades)appendBattleLog(`💨 Yêu thú né được ${roll.evades}/${strikes} đòn.`, 'text-slate-500');

      battleState.enemyHp = Math.max(0, battleState.enemyHp - totalDmg);
      // Hút HP
      const healAmt = Math.round(totalDmg * (battleState.heroLifesteal / 100));
      if (healAmt > 0) {
        battleState.heroHp = Math.min(battleState.heroMaxHp, battleState.heroHp + healAmt);
      }

      const heroSprite = document.getElementById("battleHeroSprite");
      heroSprite.classList.remove("animate-lunge-right");
      void heroSprite.offsetWidth;
      heroSprite.classList.add("animate-lunge-right");

      document.getElementById("battleEnemyPop").textContent = `${isCrit ? "💥 BẠO " : "-"}${totalDmg}${strikes > 1 ? " (Liên Kích x2)" : ""}`;
      appendBattleLog(
        `⚔️ Tổ đội xuất chiêu gây <b>-${totalDmg} HP</b>${isCrit ? " (Bạo Kích)" : ""}${strikes > 1 ? " (Liên Kích)" : ""}${healAmt > 0 ? `, Hút +${healAmt} HP` : ""}.`,
        "text-emerald-900"
      );

      if (battleState.enemyHp <= 0) {
        finishBattleVictory();
      }
    }

    function performEnemyAttack() {
      if (!battleState) return;
      const attack=s3f4RollAttack(battleState.enemyAtk,battleState.heroDef,
        battleState.enemyCrit,battleState.enemyCombo||0,battleState.heroDodge,1,6,0.42,1.6);
      const dmg=attack.damage,critHit=attack.crits>0;
      if(attack.evades)appendBattleLog(`🍃 Tổ đội né được ${attack.evades}/${attack.strikes} đòn.`, 'text-teal-700');
      battleState.heroHp = Math.max(0, battleState.heroHp - dmg);

      const enemySprite = document.getElementById("battleEnemySprite");
      enemySprite.classList.remove("animate-lunge-left");
      void enemySprite.offsetWidth;
      enemySprite.classList.add("animate-lunge-left");

      document.getElementById("battleHeroPop").textContent = `${critHit ? "💥 -" : "-"}${dmg}`;
      appendBattleLog(`👹 ${battleState.enemyName} phản kích gây <b>-${dmg} HP</b>${critHit ? " (Chí Mạng)" : ""}!`, "text-rose-800");

      if (battleState.heroHp <= 0) {
        finishBattleDefeat();
      }
    }

    function finishBattleVictory() {
      const b = battleState;
      stopBattleCleanup();

      // Lưu lại số máu còn lại sau trận (không tự đầy)
      gameState.teamHp = Math.max(1, b.heroHp);

      let stoneGain = 0;
      let msg = "";
      if (b.overleveled) {
        msg = "Tu vi vượt quá cấm chế Bí cảnh nhỏ nên không thu được Linh thạch!";
      } else {
        const [minS, maxS] = b.realmCfg.stoneReward;
        stoneGain = minS + Math.floor(Math.random() * (maxS - minS + 1));
        stoneGain=Math.round(stoneGain*(1+s3f2LinkBonuses().allyStonePct));
        gameState.spiritStones += stoneGain;
        msg = `Thu hoạch +${stoneGain} Linh thạch!`;
      }

      // Kiểm tra rơi linh thảo hiếm (<10%)
      const herb = HERBS_DB[b.realmCfg.herbDrop];
      if (herb && Math.random() < herb.rate) {
        gameState.herbs[herb.id] = (gameState.herbs[herb.id] || 0) + 1;
        msg += ` May mắn hái được linh thảo cực hiếm: [${herb.name}]!`;
      }
      const links=s3f2LinkBonuses();
      if(!b.overleveled && Math.random()<links.herbChance){
        gameState.herbs.ngoc_tuy_chi=(gameState.herbs.ngoc_tuy_chi||0)+1;
        msg+=' Linh Điền thuần hóa thêm 1 Ngọc Tủy Chi từ chiến lợi phẩm!';
      }
      // Chiến lợi phẩm và ghi chép thực địa giúp người trấn thủ chuyên môn tiến bộ.
      for(const id of ['dan_cac','tang_kinh']){
        if(s3f2EstateReady(id)){
          const e=s3f2Estate(id),worker=getValidGuardian(e);
          if(worker&&worker.craftPath===id) worker.craftXp=Math.min(2000,(worker.craftXp||0)+2);
        }
      }

      s3f3DiscoverFromVictory(b);
      addHistory(`Năm ${gameState.year}: Chinh phạt ${b.realmCfg.name} thắng lợi! ${msg}`);
      updateAllUI();
      showToast(`🏆 CHIẾN THẮNG! ${msg}`);
    }

    function finishBattleDefeat() {
      const b=battleState,team=b?.squadIds||[...gameState.squadIds];
      stopBattleCleanup();
      const fate=s3f4ResolveDefeat(team,b?.heroSpd||0,b?.enemySpd||0,false);
      gameState.teamHp=Math.max(1,Math.round(gameState.teamMaxHp*0.12));
      recalcTeamMaxHp();updateAllUI();
      showToast(`💀 Bí Cảnh thất bại: ${fate.escaped} người thoát, ${fate.dead} tộc nhân tử nạn.`);
    }

    function fleeBattle() {
      if (!battleState) return;
      gameState.teamHp = Math.max(10, battleState.heroHp);
      stopBattleCleanup();
      updateAllUI();
      showToast("🏳️ Đã rút lui khỏi Bí Cảnh, giữ nguyên số Sinh lực hiện tại.");
    }

    function stopBattleCleanup() {
      if (battleAutoTimer) clearInterval(battleAutoTimer);
      battleAutoTimer = null;
      battleState = null;
      battleActionLock = false;
      document.getElementById("battleScreen")?.classList.add("hidden");
    }

    // =========================================================================
    // 16. CƠ NGHIỆP BẢN ĐỒ CỔ TRANG 2D & NỘI CHÍNH
    // =========================================================================
    function getEstateBuildingSvg(type, active) {
      const roof = active ? "#2d4c3e" : "#78857e";
      const wall = active ? "#fbf9f2" : "#e5e7eb";
      const detail = {
        field: `<path d="M25 49l-4-12m4 12l5-14m-5 14l-2-8m18 8l-3-13m3 13l5-15m-5 15l-2-7m17 7l-3-12m3 12l5-14" stroke="#4d9a65" stroke-width="2" stroke-linecap="round"/><path d="M18 53h54" stroke="#9a7b43" stroke-width="2"/>`,
        mine: `<path d="M27 45l10-14 8 10 7-17 13 21z" fill="#8b9295" stroke="#4b5563" stroke-width="1.5"/><path d="M47 39l5-7 6 8" stroke="#e5e7eb" stroke-width="2"/>`,
        alchemy: `<path d="M39 31h12l-2 7h-8z" fill="#d6a23a" stroke="#78350f" stroke-width="1.5"/><path d="M35 39h20l-3 14H38z" fill="#64748b" stroke="#334155" stroke-width="1.8"/><path d="M42 47q3-5 6 0" stroke="#a7f3d0" stroke-width="2" fill="none"/>`,
        forge: `<path d="M28 46h34l-5 7H33z" fill="#64748b" stroke="#334155" stroke-width="1.5"/><path d="M43 43l4-12 4 12" stroke="#d97706" stroke-width="3" stroke-linecap="round"/><path d="M51 28l3-5m-12 5l-3-5" stroke="#f59e0b" stroke-width="2"/>`,
        library: `<rect x="29" y="39" width="9" height="14" rx="1" fill="#b45309"/><rect x="40" y="35" width="9" height="18" rx="1" fill="#0f766e"/><rect x="51" y="40" width="9" height="13" rx="1" fill="#7c3aed"/><path d="M31 43h5m6-4h5m6 5h5" stroke="#fef3c7" stroke-width="1.2"/>`,
        mountain: `<path d="M21 51l14-22 8 12 8-18 18 28z" fill="#7c9b87" stroke="#365b47" stroke-width="1.6"/><path d="M43 34l8-11 8 11" stroke="#f8fafc" stroke-width="2" fill="none"/>`
      }[type] || "";
      return `
        <svg width="78" height="62" viewBox="0 0 90 70" fill="none" aria-hidden="true">
          <ellipse cx="45" cy="60" rx="38" ry="8" fill="#b7cda9"/>
          <rect x="20" y="34" width="50" height="24" fill="${wall}" stroke="#3f594c" stroke-width="2"/>
          <path d="M10 35Q45 14 80 35L72 38Q45 22 18 38Z" fill="${roof}" stroke="#1f3329" stroke-width="1.8"/>
          <path d="M22 22Q45 8 68 22L62 25Q45 14 28 25Z" fill="${roof}" stroke="#1f3329" stroke-width="1.6"/>
          ${detail}
          <rect x="39" y="42" width="12" height="16" fill="#92400e" stroke="#451a03" stroke-width="1.4"/>
        </svg>
      `;
    }

    // Sprint 3E — Bách Nghệ: một chuyên môn cho mỗi tộc nhân, kinh nghiệm tích lũy khi trực cơ nghiệp.
    const S3E_CRAFTS = Object.freeze([
      {id:'linh_dien',name:'Linh Thực Sư',icon:'🌿',desc:'Chăm sóc linh dược, khai mở linh điền'},
      {id:'linh_mo',name:'Khám Khoáng Sư',icon:'⛏️',desc:'Khảo sát linh quặng, khai thác địa mạch'},
      {id:'dan_cac',name:'Đan Sư',icon:'⚗️',desc:'Điều chế linh đan, nuôi dưỡng căn cơ'},
      {id:'khi_phuong',name:'Luyện Khí Sư',icon:'🔨',desc:'Luyện chế pháp khí, tăng cường sản nghiệp'},
      {id:'tang_kinh',name:'Đạo Học Sư',icon:'📚',desc:'Khảo cứu công pháp, truyền thụ kinh văn'},
      {id:'to_son',name:'Trận Pháp Sư',icon:'🛡️',desc:'Bố trí trận đồ, bảo vệ linh mạch'}
    ]);
    function s3eCraftOf(member){
      return S3E_CRAFTS.find(c=>c.id===member?.craftPath)||null;
    }
    function s3eRank(member){
      const xp = Math.max(0,Number(member?.craftXp)||0);
      return xp>=360?5:xp>=180?4:xp>=80?3:xp>=24?2:1;
    }
    function s3eEstateBonus(estate, guardian){
      if(!guardian || Number(estate?.level)<2)return 0;
      const rank=s3eRank(guardian);
      // Phái đúng nghề: +5%..25%, trái nghề: +2%..6%; không có chuyên môn: 0%.
      if(!s3eCraftOf(guardian))return 0;
      return guardian.craftPath===estate.id ? rank*0.05 : 0.01+rank*0.01;
    }
    function s3eProcessMonthlyCraft(){
      for(const estate of gameState.estates){
        if(estate.level<2)continue;
        const worker=getValidGuardian(estate);
        if(!worker || worker.age<16 || !s3eCraftOf(worker))continue;
        const prev=s3eRank(worker);
        // Chuyên môn phù hợp phát triển nhanh hơn; XP nghề không làm tăng tu vi chiến đấu.
        worker.craftXp=Math.min(2000,(worker.craftXp||0)+(worker.craftPath===estate.id?3:1));
        if(s3eRank(worker)>prev){
          addHistory(`Năm ${gameState.year}: ${worker.name} đạt Bách Nghệ bậc ${s3eRank(worker)} (${s3eCraftOf(worker).name}).`);
        }
      }
    }
    function s3eSetCraft(memberId,craftId){
      return showToast('Đạo nghề đã định theo Thiên Cơ; chỉ kỳ ngộ đặc biệt mới có thể chuyển nghề.');
      const m=getValidLivingMember(memberId),craft=S3E_CRAFTS.find(c=>c.id===craftId);
      if(!m||m.age<16||!craft)return showToast('Chỉ tộc nhân trưởng thành mới được nhập môn Bách Nghệ.');
      if(m.craftPath===craftId)return showToast('Tộc nhân đã tu luyện nghề này.');
      if(m.craftLastSwitchYear===gameState.year)return showToast('Mỗi năm chỉ được chuyển nghề một lần.');
      const cost=m.craftPath==='none'?25:45;
      if(gameState.spiritStones<cost)return showToast(`Cần ${cost} linh thạch để nhập môn/chuyển nghề.`);
      gameState.spiritStones-=cost;
      // Khi đổi nghề kinh nghiệm không được chuyển nguyên vẹn, tránh lợi dụng xoay nghề.
      m.craftXp=m.craftPath==='none'?0:Math.floor((m.craftXp||0)*0.25);
      m.craftPath=craftId;
      m.craftLastSwitchYear=gameState.year;
      addHistory(`Năm ${gameState.year}: ${m.name} theo nghề ${craft.name}.`);
      updateAllUI();openMemberDetailModal(m.id);
      showToast(`✅ ${m.name} đã nhập môn ${craft.name}.`);
    }
    function s3eOpenCraftPicker(memberId){
      const m=getValidLivingMember(memberId);if(!m||m.age<16)return;
      const html=`<div class="space-y-2 text-[11px]"><p class="text-slate-700">Mỗi tộc nhân chọn một nghề. Nhập môn 25 💎, đổi nghề 45 💎, tối đa một lần/năm. Khi trấn thủ cơ nghiệp đúng nghề, tay nghề tăng nhanh và sản lượng tăng tối đa 25%.</p>
        ${S3E_CRAFTS.map(c=>`<button type="button" onclick="s3eSetCraft(${m.id},'${c.id}')" class="w-full text-left p-3 bg-white border border-emerald-200 rounded-xl flex gap-2 items-center"><span class="text-xl">${c.icon}</span><span class="flex-1"><b>${c.name}</b><small class="block text-slate-500">${c.desc}</small></span><span>${m.craftPath===c.id?'✓ Đã chọn':'Chọn ›'}</span></button>`).join('')}
        <button type="button" class="w-full p-2 bg-emerald-800 text-white rounded-xl" onclick="openMemberDetailModal(${m.id})">← Trở về Ngọc Giản</button></div>`;
      openGenericModal(`Bách Nghệ · ${m.name}`,html);
    }
    // Sprint 3E.1: thực hành nghề gắn trực tiếp với Cơ Nghiệp và tài nguyên thật.
    // Không ghi đè luyện đan đột phá hiện có: Đan Sư chỉ làm Hồi Xuân Đan hỗ trợ.
    const S3E1_RECIPES = Object.freeze({
      linh_dien: {name:'Ươm Dược Thảo', icon:'🌱', cost:12, description:'Thu hoạch 2 Ngọc Tủy Chi cho Đan Đường.'},
      linh_mo: {name:'Khai Mạch Tinh Hoa', icon:'⛏️', cost:18, description:'Khai thác địa mạch, thu 27–35 linh thạch.'},
      dan_cac: {name:'Luyện Hồi Xuân Đan', icon:'⚗️', cost:20, description:'Chế tạo 1–2 Hồi Xuân Đan phục hồi đội Bí Cảnh.'},
      khi_phuong: {name:'Tôi Luyện Pháp Khí', icon:'🔨', cost:42, description:'Tăng +3 Tấn Công cá nhân, tối đa bốn lần.'},
      tang_kinh: {name:'Tham Ngộ Kinh Văn', icon:'📚', cost:24, description:'Nhận tu vi theo bậc nghề, có thể giúp đột phá.'},
      to_son: {name:'Khắc Hộ Thân Trận', icon:'🛡️', cost:42, description:'Tăng +3 Phòng Thủ cá nhân, tối đa bốn lần.'}
    });
    function s3e1WorkStatus(m){
      if (!m || !m.alive || m.age<16) return 'Tộc nhân cần trưởng thành và còn sống.';
      if (!s3eCraftOf(m)) return 'Cần nhập môn một nghề trước.';
      const estate=gameState.estates.find(e=>e.id===m.craftPath);
      if (!estate || estate.level<2) return 'Cần xây công trình đúng nghề đến cấp 2.';
      if (Number(estate.guardianId)!==m.id || getValidGuardian(estate)?.id!==m.id) return 'Cần phân công tộc nhân trấn thủ đúng công trình.';
      const now=getMonthIndex();
      const last=Number.isFinite(m.s3e1LastWorkMonth)?m.s3e1LastWorkMonth:-1;
      if(last>=0 && now-last<3) return `Cần chờ ${3-(now-last)} tháng để thực hành tiếp.`;
      if(m.craftPath==='khi_phuong'&&(m.s3e1ForgeCount||0)>=4) return 'Đã đạt giới hạn tôi luyện pháp khí (+12 Tấn Công).';
      if(m.craftPath==='to_son'&&(m.s3e1WardCount||0)>=4) return 'Đã đạt giới hạn khắc trận (+12 Phòng Thủ).';
      const recipe=S3E1_RECIPES[m.craftPath];
      if(!recipe) return 'Nghề chưa có công thức thực hành.';
      if(gameState.spiritStones<recipe.cost) return `Cần ${recipe.cost} linh thạch để thực hành.`;
      return '';
    }
    function s3e1OpenWorkshop(memberId){
      const m=getMemberById(memberId);
      if(!m)return;
      const craft=s3eCraftOf(m), recipe=craft&&S3E1_RECIPES[craft.id];
      if(!recipe)return showToast('Hãy chọn chuyên môn cho tộc nhân trước.');
      const status=s3e1WorkStatus(m), rank=s3eRank(m);
      const body=`<div class="space-y-3 text-[11px]">
        <div class="bg-emerald-50 rounded-xl p-3 border border-emerald-200"><b>${recipe.icon} ${recipe.name}</b><p class="mt-1 text-slate-700">${recipe.description}</p>
        <p class="mt-1">Tộc nhân: <b>${escapeHtml(m.name)}</b> · Bậc nghề <b>${rank}/5</b></p>
        <p>Chi phí: <b>${recipe.cost} 💎</b> · Thưởng nghề: <b>+8 XP</b> · Hồi chiêu: <b>3 tháng</b></p>
        <p class="mt-1 text-slate-600">Đã thực hành: ${m.s3e1WorkCount||0} lần${craft.id==='khi_phuong'?` · Tôi luyện ${m.s3e1ForgeCount||0}/4`:''}${craft.id==='to_son'?` · Khắc trận ${m.s3e1WardCount||0}/4`:''}</p></div>
        ${status?`<p class="text-amber-800 font-bold bg-amber-50 p-2 rounded-lg">⚠️ ${escapeHtml(status)}</p>`:''}
        ${m.craftPath==='dan_cac'?`<button type="button" ${status||gameState.spiritStones<25||(gameState.herbs.ngoc_tuy_chi||0)<1?'disabled':''} onclick="s3f41CraftAnThai(${m.id})" class="w-full rounded-xl p-3 text-xs font-bold bg-rose-100 text-rose-900 border border-rose-300">🌿 Luyện 1 An Thai Đan (25 💎 + 1 Ngọc Tủy Chi) · Kho: ${gameState.anThaiPills||0}</button>`:''}
        <button type="button" ${status?'disabled':''} onclick="s3e1PerformWork(${m.id})" class="w-full p-3 text-white font-bold rounded-xl ${status?'bg-slate-400':'bg-emerald-800'}">Thực hành ${recipe.name}</button>
        <button type="button" onclick="openMemberDetailModal(${m.id})" class="w-full p-2 rounded-xl border border-emerald-300">← Về Ngọc Giản</button>
      </div>`;
      openGenericModal('Bách Nghệ · Xưởng Thực Hành',body);
    }
    function s3f41CraftAnThai(memberId){
      const m=getValidLivingMember(memberId),status=s3e1WorkStatus(m);
      if(!m||m.craftPath!=='dan_cac'||status)return showToast(status||'Cần Đan Sư hợp lệ.');
      if(gameState.spiritStones<25||(gameState.herbs.ngoc_tuy_chi||0)<1)return showToast('Cần 25 linh thạch và 1 Ngọc Tủy Chi.');
      gameState.spiritStones-=25;gameState.herbs.ngoc_tuy_chi--;gameState.anThaiPills++;
      m.craftXp=Math.min(2000,(m.craftXp||0)+8);m.s3e1LastWorkMonth=getMonthIndex();m.s3e1WorkCount=(m.s3e1WorkCount||0)+1;
      addHistory(`Năm ${gameState.year}: ${m.name} luyện thành 1 An Thai Đan phục vụ gia đạo.`);
      markGameDirty();updateAllUI();saveGameToLocal({silent:true,closeModal:false});s3e1OpenWorkshop(memberId);showToast('🌿 Luyện thành An Thai Đan.');
    }
    function s3e1PerformWork(memberId){
      const m=getValidLivingMember(memberId);
      const status=s3e1WorkStatus(m);
      if(status){showToast(status); if(m)s3e1OpenWorkshop(m.id);return false;}
      const recipe=S3E1_RECIPES[m.craftPath];
      // Kiểm tra toàn bộ điều kiện trước khi trừ tài nguyên, tránh thất thoát khi thất bại.
      gameState.spiritStones-=recipe.cost;
      const rank=s3eRank(m);
      let outcome='';
      switch(m.craftPath){
        case 'linh_dien':
          gameState.herbs.ngoc_tuy_chi=(gameState.herbs.ngoc_tuy_chi||0)+2+(rank>=4?1:0);
          outcome=`thu ${2+(rank>=4?1:0)} Ngọc Tủy Chi`;
          break;
        case 'linh_mo': {
          const oreGain=26+rank*2;
          gameState.spiritStones+=oreGain;
          outcome=`khai mạch thu ${oreGain} linh thạch (sau chi phí: +${oreGain-recipe.cost})`;
          break;
        }
        case 'dan_cac':
          gameState.healPills+=rank>=4?2:1;
          outcome=`luyện thành ${rank>=4?2:1} Hồi Xuân Đan`;
          break;
        case 'khi_phuong':
          m.bonusAtk=(m.bonusAtk||0)+3;
          m.s3e1ForgeCount=(m.s3e1ForgeCount||0)+1;
          outcome=`tôi luyện pháp khí, +3 Tấn Công (${m.s3e1ForgeCount}/4)`;
          break;
        case 'tang_kinh': {
          const gained=addXp(m,20+rank*10);
          outcome=`tham ngộ kinh văn, +${gained} Tu Vi`;
          break;
        }
        case 'to_son':
          m.bonusDef=(m.bonusDef||0)+3;
          m.s3e1WardCount=(m.s3e1WardCount||0)+1;
          outcome=`khắc trận hộ thân, +3 Phòng Thủ (${m.s3e1WardCount}/4)`;
          break;
        default: return false;
      }
      const oldRank=rank;
      m.craftXp=Math.min(2000,(m.craftXp||0)+8);
      m.s3e1LastWorkMonth=getMonthIndex();
      m.s3e1WorkCount=(m.s3e1WorkCount||0)+1;
      if(s3eRank(m)>oldRank)outcome+=` · thăng Bách Nghệ bậc ${s3eRank(m)}`;
      addHistory(`Năm ${gameState.year}, tháng ${gameState.month}: ${m.name} ${outcome}.`);
      markGameDirty();markAllViewsDirty();updateAllUI();
      saveGameToLocal({silent:true,closeModal:false});
      s3e1OpenWorkshop(m.id);
      showToast(`${recipe.icon} ${m.name}: ${outcome}`);
      return true;
    }

    function s3eMemberPanel(m){
      const craft=s3eCraftOf(m);
      const assignment=gameState.estates.find(e=>Number(e.guardianId)===m.id&&e.level>=2);
      if(m.age<16&&!craft)return '';
      const rank=craft?s3eRank(m):0;
      return `<section class="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-[11px] space-y-2">
        <div class="flex justify-between items-center"><b class="text-emerald-950">🔨 Bách Nghệ Tu Tiên</b><span class="text-emerald-800">${craft?`Bậc ${rank}/5`:'Chưa nhập môn'}</span></div>
        <div>${craft?`${craft.icon} <b>${craft.name}</b> · Thuần thục ${Math.floor(m.craftXp||0)} XP`:'Chưa định đạo nghề; cơ duyên sẽ xuất hiện theo thời gian.'}</div>
        <div class="text-slate-600">${assignment?`Đang trấn thủ <b>${escapeHtml(assignment.name)}</b> · cộng ${(s3eEstateBonus(assignment,m)*100).toFixed(0)}% sản lượng. ${craft?'Tăng XP nghề mỗi tháng.':''}`:'Chưa được phân công trấn thủ công trình cấp 2 trở lên.'}</div>
        ${m.alive&&m.age>=16?`<p class="text-emerald-800 font-semibold">${craft?'Đạo nghề đã định, chỉ biến cố đặc biệt mới có thể thay đổi.':'Cơ duyên nghề nghiệp sẽ xuất hiện theo thời gian.'}</p>`:''}
        ${m.alive&&m.age>=16&&craft?`<button onclick="s3e1OpenWorkshop(${m.id})" class="w-full bg-amber-100 text-amber-950 border border-amber-400 rounded-lg p-2 font-bold">⚒️ Thực hành nghề · ${S3E1_RECIPES[craft.id]?.name||'Xưởng'}</button>`:''}
      </section>`;
    }

    function getEstateProductionAtLevel(estate, level = estate?.level, context = null) {
      if (!estate || !Number.isFinite(Number(level)) || Number(level) <= 0) return 0;
      const bonuses = context?.bonuses || getClanAggregateBonuses();
      const discBonus = Number.isFinite(context?.discBonus)
        ? context.discBonus
        : gameState.outerDisciples.reduce((sum, disciple) =>
            sum + safeNumber(disciple.proficiency, 0, 0, 100) / 100, 0
          );
      const guardian = typeof context?.guardianOverride === "boolean"
        ? (context.guardianOverride ? true : null)
        : getValidGuardian(estate);
      let multiplier = 1 + (Number(level) - 1) * 0.45;
      if (Number(level) >= 2 && !guardian) multiplier *= 0.6;
      const craftBonus = typeof context?.guardianOverride === "boolean" ? 0 : s3eEstateBonus(estate,guardian);
      const elderBonus=s3f2LinkBonuses().elderIncomePct;
      return Number((estate.baseIncome * multiplier * (1 + discBonus * 0.4 + bonuses.incomePct / 100) * (1 + craftBonus) * (1+elderBonus)).toFixed(1));
    }

    function getCostOfEstateUpgrade(estate) {
      if (!estate) return 0;
      return safeNumber(Math.round(estate.upgradeCost * Math.pow(1.55, estate.level)), 0, 0, GAME_CONFIG.maxResource);
    }

    const ESTATE_MAP_POSITIONS = Object.freeze({
      to_son:   { x: 57, y: 23 },
      tang_kinh:{ x: 79, y: 39 },
      dan_cac:  { x: 34, y: 43 },
      khi_phuong:{ x: 71, y: 61 },
      linh_dien:{ x: 22, y: 87 },
      linh_mo:  { x: 78, y: 84 }
    });

    function getEstateIncomeContext() {
      return {
        bonuses: getClanAggregateBonuses(),
        discBonus: gameState.outerDisciples.reduce((sum, disciple) =>
          sum + safeNumber(disciple.proficiency, 0, 0, 100) / 100, 0
        )
      };
    }

    function getEstateGuardianBadgeHtml(estate, guardian) {
      if (estate.level < 2) return "";
      return `
        <button type="button" class="estate-guardian-badge ${guardian ? "is-assigned" : "is-empty"}"
          onclick="event.stopPropagation();openAssignGuardianModal('${escapeHtml(estate.id)}')"
          aria-label="${guardian ? `Đổi trấn thủ ${escapeHtml(guardian.name)}` : "Phái tộc nhân trấn thủ"}"
          title="${guardian ? `Trấn thủ: ${escapeHtml(guardian.name)}` : "Chạm để phái trấn thủ"}">
          ${guardian ? getCharacterSvg(guardian, 27) : "+"}
        </button>`;
    }

    function openEstateMapGuide(){
      openGenericModal('🏯 Tiên Sơn · Chú Giải', `<div class="space-y-3 text-xs text-slate-800">
        <div class="rounded-xl border border-amber-200 bg-amber-50 p-3"><b>🏯 Cơ Nghiệp</b><p class="mt-1">Chạm biển tên gỗ để xem cấp công trình, sản lượng, chi phí khai phá hoặc nâng cấp. Các hành động chỉ xuất hiện trong bảng chi tiết.</p></div>
        <div class="rounded-xl border border-emerald-200 bg-white p-3 space-y-2">
          <p><b>🟢 Ấn Trấn Thủ:</b> Công trình từ cấp 2 có thể phân công một tộc nhân. Ấn có chân dung khi đã có người.</p>
          <p><b>⊕ Viền đỏ nét đứt:</b> Công trình đang thiếu Trấn Thủ. Chạm trực tiếp để chọn người.</p>
          <p><b>🌫️ Chờ khai phá:</b> Công trình chưa xây dựng, phải mở trong bảng chi tiết.</p>
          <p><b>💎 /thg:</b> Thu nhập ước tính của từng cơ nghiệp theo cấp, Trấn Thủ và các hiệu ứng liên kết.</p>
        </div>
        <p class="text-[11px] text-slate-600">Đọc thêm hiệu ứng giữa các tab bằng nút 🔗 Liên kết phía trên bản đồ.</p>
      </div>`);
    }

    function renderEstateMap() {
      s3f2ShowPanel("estateMapStage","estate");
      const grid = document.getElementById("estateMapGrid");
      if (!grid) return;
      const totalIncome = getNetMonthlyIncome();
      const incomeLabel = document.getElementById("estateTotalIncome");
      if (incomeLabel) {
        incomeLabel.textContent = `${formatSigned(totalIncome)} 💎/thg`;
        incomeLabel.style.color = totalIncome >= 0 ? "#176448" : "#a43e43";
      }
      const builtCount = gameState.estates.filter(estate => estate.level > 0).length;
      const builtLabel = document.getElementById("estateBuiltCount");
      if (builtLabel) builtLabel.textContent = `${builtCount} / ${gameState.estates.length} cơ nghiệp đã khai mở`;

      const context = getEstateIncomeContext();
      grid.innerHTML = gameState.estates.map(estate => {
        const isBuilt = estate.level > 0;
        const guardian = getValidGuardian(estate);
        const position = ESTATE_MAP_POSITIONS[estate.id] || { x: 50, y: 50 };
        const production = getEstateProductionAtLevel(estate, estate.level, context);
        const incomeText = isBuilt ? `${formatSigned(production)} 💎/thg` : "Chờ khai phá";
        const levelText = isBuilt ? `Lv.${estate.level}` : "";
        return `
          <div class="estate-node ${isBuilt ? "is-built" : "is-locked"} ${estate.level >= 2 && !guardian ? "needs-guardian" : ""}"
            style="left:${position.x}%;top:${position.y}%">
            <span class="estate-ruin-fog" aria-hidden="true"></span>
            <button type="button" class="estate-node-main" onclick="openEstateDetailModal('${escapeHtml(estate.id)}')"
              aria-label="Mở chi tiết ${escapeHtml(estate.name)}" title="${escapeHtml(estate.name)} · ${incomeText}">
              <span class="estate-node-plaque">
                ${getEstateTypeIconHtml(estate.type)}
                <span class="estate-node-name">${escapeHtml(estate.name)}</span>
                <span class="estate-node-level">${levelText}</span>
              </span>
              <span class="estate-node-income">${incomeText}</span>
            </button>
            ${getEstateGuardianBadgeHtml(estate, guardian)}
          </div>`;
      }).join("");
    }

    function openEstateDetailModal(estateId) {
      const estate = gameState.estates.find(item => item.id === estateId);
      if (!estate) return;
      const overlay = document.getElementById("estateDetailOverlay");
      const title = document.getElementById("estateDetailTitle");
      const body = document.getElementById("estateDetailBody");
      if (!overlay || !title || !body) return;

      const isBuilt = estate.level > 0;
      const guardian = getValidGuardian(estate);
      const context = getEstateIncomeContext();
      const currentProduction = getEstateProductionAtLevel(estate, estate.level, context);
      const nextLevel = Math.min(30, estate.level + 1);
      const nextProduction = getEstateProductionAtLevel(estate, nextLevel, context);
      const nextProductionWithGuardian = getEstateProductionAtLevel(estate, nextLevel, { ...context, guardianOverride: true });
      const cost = getCostOfEstateUpgrade(estate);
      const isMaxLevel = estate.level >= 30;
      const statusText = !isBuilt ? "Chưa khai phá" : (estate.level >= 2 && !guardian ? "Thiếu trấn thủ · giảm sản lượng" : "Đang vận hành");
      title.textContent = estate.name;

      const guardianBlock = estate.level >= 2 ? `
        <div class="estate-guardian-card">
          <div class="estate-guardian-person">
            <div class="estate-guardian-avatar">${guardian ? getCharacterSvg(guardian, 34) : "＋"}</div>
            <div class="min-w-0">
                <div class="estate-detail-label">TỘC NHÂN TRẤN THỦ · BÁCH NGHỆ</div>
              <div class="estate-detail-value">${guardian ? `${escapeHtml(guardian.name)} · ${escapeHtml(REALMS[guardian.realmIdx]?.name || "Phàm Nhân")}` : "Chưa phân công"}</div>
              <div class="text-[9px] ${guardian ? "text-emerald-800" : "text-amber-800"} font-bold">${guardian ? `${escapeHtml(s3eCraftOf(guardian)?.name||"Chưa có chuyên môn")} · Bậc ${s3eCraftOf(guardian)?s3eRank(guardian):0} · Thưởng +${Math.round(s3eEstateBonus(estate,guardian)*100)}%` : "Hiệu suất hiện tại: 60%"}</div>
            </div>
          </div>
        </div>` : `
        <div class="estate-guardian-card">
          <div>
            <div class="estate-detail-label">TRẤN THỦ CƠ NGHIỆP</div>
            <div class="estate-detail-value">Mở khóa từ cấp 2</div>
          </div>
          <span class="text-[10px] text-emerald-800 font-bold">Chưa cần điều động</span>
        </div>`;

      body.innerHTML = `
        <div class="estate-detail-status">
          <div><div class="estate-detail-label">TRẠNG THÁI</div><strong>${statusText}</strong></div>
          <div class="text-right"><div class="estate-detail-label">CẤP CÔNG TRÌNH</div><strong>${estate.level} / 30</strong></div>
        </div>
        <div class="estate-detail-grid">
          <div class="estate-detail-stat"><div class="estate-detail-label">SẢN LƯỢNG HIỆN TẠI</div><strong>${formatSigned(currentProduction)} 💎/tháng</strong></div>
          <div class="estate-detail-stat"><div class="estate-detail-label">CẤP KẾ TIẾP DỰ KIẾN</div><strong>${isMaxLevel ? "Đã tối đa" : `${formatSigned(nextProduction)} 💎/tháng`}</strong></div>
          <div class="estate-detail-stat"><div class="estate-detail-label">CHI PHÍ ĐẦU TƯ</div><strong>${isMaxLevel ? "—" : `${cost.toLocaleString("vi-VN")} 💎`}</strong></div>
          <div class="estate-detail-stat"><div class="estate-detail-label">TÀI NGUYÊN HIỆN CÓ</div><strong>${Math.floor(gameState.spiritStones).toLocaleString("vi-VN")} 💎</strong></div>
        </div>
        ${guardianBlock}
        <div class="estate-action-row">
          <button type="button" class="estate-action-btn upgrade" ${isMaxLevel ? "disabled" : ""}
            onclick="buildOrUpgradeEstate('${escapeHtml(estate.id)}')">${!isBuilt ? `Khai Phá · ${cost.toLocaleString("vi-VN")} 💎` : `Nâng Cấp · ${cost.toLocaleString("vi-VN")} 💎`}</button>
          <button type="button" class="estate-action-btn guardian" ${estate.level < 2 ? "disabled" : ""}
            onclick="openAssignGuardianModal('${escapeHtml(estate.id)}')">${estate.level < 2 ? "Trấn Thủ · Mở khóa Lv.2" : (guardian ? "Đổi Trấn Thủ" : "Phái Trấn Thủ")}</button>
        </div>
        <p class="mt-3 text-[9px] leading-relaxed text-slate-600">${!isBuilt ? "Khai phá khu vực này để mở nguồn sản lượng mới cho gia tộc." : "Sản lượng được tính theo cấp công trình, hiệu suất trấn thủ, đệ tử ký danh và các bonus gia tộc."}${!isMaxLevel && nextLevel >= 2 && !guardian ? ` Ở cấp kế tiếp, nếu có trấn thủ sản lượng có thể đạt ${formatSigned(nextProductionWithGuardian)} 💎/tháng thay vì ${formatSigned(nextProduction)} 💎/tháng.` : ""}</p>
      `;
      overlay.classList.remove("hidden");
      overlay.setAttribute("aria-hidden", "false");
    }

    function closeEstateDetailModal() {
      const overlay = document.getElementById("estateDetailOverlay");
      if (!overlay) return;
      overlay.classList.add("hidden");
      overlay.setAttribute("aria-hidden", "true");
    }

    function buildOrUpgradeEstate(estateId) {
      const estate = gameState.estates.find(item => item.id === estateId);
      if (!estate) return;
      const cost = getCostOfEstateUpgrade(estate);
      if (gameState.spiritStones < cost) return showToast(`Cần ${cost} Linh thạch để đầu tư cơ nghiệp này!`);
      if (estate.level >= 30) return showToast("Cơ nghiệp đã đạt cấp tối đa hiện tại.");
      gameState.spiritStones -= cost;
      estate.level++;
      addHistory(`Năm ${gameState.year}: ${estate.name} được nâng lên cấp ${estate.level}, chi phí ${cost} Linh thạch.`);
      updateAllUI();
      saveGameToLocal({ silent: true, closeModal: false });
      showToast(`🏯 ${estate.name} đã đạt Cấp ${estate.level}!`);
      openEstateDetailModal(estateId);
    }

    function openAssignGuardianModal(estateId) {
      const estate = gameState.estates.find(item => item.id === estateId);
      if (!estate || estate.level < 2) return;
      const availableMembers = gameState.members.filter(member =>
        member.alive && member.age >= GAME_CONFIG.guardianMinAge &&
        (!gameState.estates.some(other => other.id !== estateId && Number(other.guardianId) === member.id) ||
          Number(estate.guardianId) === member.id)
      );
      const title = document.getElementById("estateDetailTitle");
      const body = document.getElementById("estateDetailBody");
      const overlay = document.getElementById("estateDetailOverlay");
      if (!title || !body || !overlay) return;
      title.textContent = `Trấn Thủ · ${estate.name}`;
      body.innerHTML = `
        <p class="text-[10px] leading-relaxed text-slate-600">Mỗi tộc nhân chỉ trấn thủ một cơ nghiệp. Người có chuyên môn phù hợp được thưởng sản lượng và tăng thuần thục mỗi tháng.</p>
        <div class="estate-picker-list">
          ${availableMembers.length ? availableMembers.map(member => `
            <button type="button" class="estate-picker-member" onclick="assignGuardian('${escapeHtml(estateId)}',${Number(member.id)})">
              <span class="flex items-center gap-2 min-w-0">
                <span class="estate-guardian-avatar">${getCharacterSvg(member, 34)}</span>
                <span class="min-w-0"><strong class="block text-[11px] truncate">${escapeHtml(member.name)}</strong><small class="block text-[9px] text-slate-600">${escapeHtml(REALMS[member.realmIdx]?.name || "Phàm Nhân")} · ${member.age} tuổi · ${escapeHtml(s3eCraftOf(member)?.name||"Chưa có nghề")} ${member.craftPath===estate.id?"✓ Phù hợp":""}</small></span>
              </span>
              <span class="text-[9px] font-extrabold text-emerald-800">${Number(estate.guardianId) === member.id ? "Đang trấn thủ" : "Điều động ›"}</span>
            </button>`).join("") : `<div class="rounded-xl border border-dashed border-amber-500/60 bg-amber-50 p-4 text-center text-[10px] font-bold text-amber-900">Chưa có tộc nhân trưởng thành đang rảnh để điều động.</div>`}
        </div>
        <button type="button" class="mt-3 w-full min-h-[42px] rounded-xl border border-emerald-800/40 bg-white/80 text-[10px] font-extrabold text-emerald-900" onclick="openEstateDetailModal('${escapeHtml(estateId)}')">← Quay lại chi tiết công trình</button>
      `;
      overlay.classList.remove("hidden");
      overlay.setAttribute("aria-hidden", "false");
    }

    function assignGuardian(estateId, memberId) {
      const estate = gameState.estates.find(item => item.id === estateId);
      const member = getValidLivingMember(memberId);
      if (!estate || estate.level < 2 || !member || member.age < GAME_CONFIG.guardianMinAge) {
        return showToast("Tộc nhân không đủ điều kiện trấn thủ.");
      }
      const alreadyAssigned = gameState.estates.some(item =>
        item.id !== estateId && Number(item.guardianId) === member.id
      );
      if (alreadyAssigned) return showToast("Tộc nhân này đang trấn thủ cơ nghiệp khác.");
      gameState.estates.forEach(item => {
        if (item.id !== estateId && Number(item.guardianId) === member.id) item.guardianId = null;
      });
      estate.guardianId = member.id;
      updateAllUI();
      saveGameToLocal({ silent: true, closeModal: false });
      showToast(`✅ ${member.name} đã được phân công trấn thủ ${estate.name}.`);
      openEstateDetailModal(estateId);
    }

    // Nội Chính: Đệ tử ký danh & Trưởng Lão Viện
    function renderAffairsView() {
      s3f2ShowPanel("disciplesList","affairs");
      const discList = document.getElementById("disciplesList");
      if (discList) {
        if (gameState.outerDisciples.length === 0) {
          discList.innerHTML = `<div class="text-center text-[11px] text-slate-500 py-2">Chưa có đệ tử ký danh. Chiêu mộ để hỗ trợ sản xuất cơ nghiệp.</div>`;
        } else {
          discList.innerHTML = gameState.outerDisciples.map(d => `
            <div class="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-xl p-2">
              <div>
                <div class="text-xs font-extrabold text-slate-900">${escapeHtml(d.name)} <span class="text-[9px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-900">${d.tier}</span></div>
                <div class="text-[10px] text-emerald-800 font-semibold">Thông thạo sản xuất: +${d.proficiency}%</div>
              </div>
              <button onclick="dismissOuterDisciple(${d.id})" class="bg-rose-100 text-rose-700 font-extrabold px-2 py-1 rounded-lg text-[10px]">
                Đuổi
              </button>
            </div>
          `).join("");
        }
      }

      const pol=s3f4Politics();
      const politicalBadge=`<div class="text-[10px] rounded-lg bg-amber-50 border border-amber-300 p-2 mb-2"><b>🏯 Phong Vân Gia Tộc</b> · Hòa ước ${pol.alliance} · Ân oán ${pol.feud} · Sư môn ${pol.school}. Những quyết định được lưu qua các đời.</div>`;
      const facList = document.getElementById("factionsList");
      if (facList) {
        facList.innerHTML = politicalBadge+gameState.factions.map(f => `
          <div class="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-xl p-2">
            <div>
              <div class="text-xs font-extrabold text-slate-900">${f.name}</div>
              <div class="text-[10px] text-slate-600">Hảo cảm: <b>${f.relation}/100</b> • Thực lực: ${f.power}</div>
            </div>
            <button onclick="giftFaction('${f.id}')" class="bg-emerald-700 text-white font-extrabold px-2.5 py-1 rounded-xl text-[10px] active:scale-95">
              Tặng Lễ (30 💎)
            </button>
          </div>
        `).join("");
      }
    }

    function recruitOuterDisciple() {
      if (gameState.spiritStones < 35) return showToast("Cần 35 Linh thạch để mở sơn môn chiêu mộ!");
      gameState.spiritStones -= 35;

      const r = Math.random() * 100;
      let tier = "Phàm Cấp", prof = 6 + Math.floor(Math.random() * 7);
      if (r < 2) { tier = "Kỳ Tài"; prof = 70 + Math.floor(Math.random() * 25); }
      else if (r < 12) { tier = "Thượng Phẩm"; prof = 35 + Math.floor(Math.random() * 20); }
      else if (r < 38) { tier = "Trung Phẩm"; prof = 16 + Math.floor(Math.random() * 15); }

      const gender = Math.random() < 0.5 ? "male" : "female";
      const d = {
        id: Date.now() + Math.random(),
        name: generateTwoCharName(gender),
        tier,
        proficiency: prof
      };
      gameState.outerDisciples.push(d);
      updateAllUI();
      showToast(`🎓 Chiêu mộ được đệ tử ký danh [${d.tier}] ${d.name} (+${d.proficiency}% thông thạo)!`);
    }

    function dismissOuterDisciple(id) {
      gameState.outerDisciples = gameState.outerDisciples.filter(d => d.id !== id);
      updateAllUI();
      showToast("Đã cho đệ tử ký danh hạ sơn.");
    }

    function giftFaction(factionId) {
      if (gameState.spiritStones < 30) return showToast("Cần 30 Linh thạch chuẩn bị lễ vật!");
      const f = gameState.factions.find(x => x.id === factionId);
      if (!f) return;
      if (f.relation >= 100) return showToast("Quan hệ thế lực này đã đạt tối đa 100/100.");
      gameState.spiritStones -= 30;
      f.relation = Math.min(100, f.relation + 12);
      updateAllUI();
      showToast(`🤝 Hảo cảm với ${f.name} tăng lên ${f.relation}/100!`);
    }

    function openElderModal() {
      const elders = gameState.members.filter(m => m.alive && m.role === "Trưởng Lão");
      const body = `
        <p class="text-xs text-slate-600">Bổ nhiệm tộc nhân thành <b>Trưởng Lão</b> từ Cây Gia Phả để trợ giúp quản lý tông môn.</p>
        ${elders.length === 0
          ? `<div class="text-center py-4 text-slate-500 font-semibold">Chưa có Trưởng Lão nào được bổ nhiệm.</div>`
          : elders.map(e => `
            <div class="bg-white border border-emerald-600/50 rounded-xl p-2.5 flex items-center justify-between">
              <div>
                <div class="text-xs font-extrabold text-emerald-950">${escapeHtml(e.name)} • Trưởng Lão</div>
                <div class="text-[10px] text-slate-600">${REALMS[e.realmIdx].name} • Trung thành: ${e.elderSatisfaction}%</div>
              </div>
              <button onclick="pacifyElder(${e.id})" class="bg-amber-500 text-slate-950 font-extrabold px-2.5 py-1 rounded-lg text-[10px]">
                Ban Thưởng (20 💎)
              </button>
            </div>
          `).join("")
        }
      `;
      openGenericModal("🏛️ Trưởng Lão Viện", body);
    }

    function pacifyElder(id) {
      if (gameState.spiritStones < 20) return showToast("Cần 20 Linh thạch để ban thưởng!");
      const e = getValidLivingMember(id);
      if (!e || e.role !== "Trưởng Lão") return showToast("Trưởng lão không còn hợp lệ.");
      if (e.elderSatisfaction >= 100) return showToast("Trưởng lão đã hoàn toàn hài lòng; không cần ban thưởng thêm.");
      gameState.spiritStones -= 20;
      e.elderSatisfaction = Math.min(100, e.elderSatisfaction + 15);
      openElderModal();
      updateAllUI();
    }

    function openHistoryModal() {
      const body = `
        <div class="space-y-1.5">
          ${gameState.historyLog.slice().reverse().map(line => `
            <div class="bg-white border border-slate-200 rounded-xl p-2 text-[11px] text-slate-700 leading-snug">${escapeHtml(line)}</div>
          `).join("")}
        </div>
      `;
      openGenericModal("📜 Gia Tộc Biên Niên Sử", body);
    }

    function openSettingsModal() {
      const body = `
        <div class="space-y-2.5">
          <button onclick="saveGameToLocal()" class="w-full bg-emerald-700 text-white font-extrabold py-2.5 rounded-xl text-xs shadow">
            💾 Lưu Tiến Trình Gia Tộc
          </button>
          <button onclick="exportSaveFile()" class="w-full bg-sky-700 text-white font-extrabold py-2.5 rounded-xl text-xs shadow">
            📤 Xuất Save JSON
          </button>
          <button onclick="document.getElementById('settingsImportSave').click()" class="w-full bg-indigo-700 text-white font-extrabold py-2.5 rounded-xl text-xs shadow">
            📥 Nhập Save JSON
          </button>
          <input id="settingsImportSave" type="file" accept=".json,application/json" class="hidden" onchange="importSaveFromInput(this)" />
          <button onclick="resetAndOpenStartup()" class="w-full bg-amber-500 text-slate-950 font-extrabold py-2.5 rounded-xl text-xs shadow">
            🔄 Lập Lại Gia Tộc Mới
          </button>
          <button onclick="confirmDeleteProgress()" class="w-full bg-rose-700 text-white font-extrabold py-2.5 rounded-xl text-xs shadow">
            🗑️ Xóa Tiến Trình Đã Lưu
          </button>
          <p class="text-[10px] leading-relaxed text-slate-500">Bản lưu mới dùng schema v2. Save v5 cũ được sao lưu trước khi chuyển đổi; không tự xóa nếu tải lỗi.</p>
        </div>
      `;
      openGenericModal("⚙️ Cài Đặt Tông Môn", body);
    }

    function resetAndOpenStartup() {
      if (!beginNewClanFlow()) return;
      closeGenericModal();
      document.getElementById("startupModal")?.classList.remove("hidden");
    }

    // =========================================================================
    // 17. ĐIỀU HƯỚNG TAB, MODAL & CẬP NHẬT GIAO DIỆN TỔNG THỂ
    // =========================================================================
    function switchTab(tabName) {
      const allowedTabs = ["family", "cave", "secret", "estate", "affairs"];
      if (!allowedTabs.includes(tabName)) return;
      currentTab = tabName;
      allowedTabs.forEach(tab => {
        const view = document.getElementById(`view-${tab}`);
        const button = document.getElementById(`tab-${tab}`);
        if (view) view.classList.toggle("hidden", tab !== tabName);
        if (button) button.classList.toggle("active", tab === tabName);
      });
      dirtyViews.add(tabName);
      updateAllUI();
    }

    function openGenericModal(title, bodyHtml, showClose = true) {
      document.getElementById("modalTitle").textContent = title;
      document.getElementById("modalBody").innerHTML = bodyHtml;
      document.getElementById("modalCloseBtn").classList.toggle("hidden", !showClose);
      document.getElementById("genericModal").classList.remove("hidden");
    }

    function closeGenericModal() {
      document.getElementById("genericModal")?.classList.add("hidden");
      marriageModalContext = null;
      adoptCandidateContext = null;
    }

    let modalDecisionSeed = 1;
    const modalDecisionCallbacks = {};
    function escapeDecisionText(text) {
      return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\n/g, "<br>");
    }
    function openDecisionModal({title='📜 Gia Chủ Quyết Định', message='', confirmText='Xác nhận', cancelText='Hủy', confirmClass='bg-emerald-700 text-white', cancelClass='bg-slate-200 text-slate-700', onConfirm=null, onCancel=null, showClose=false}={}) {
      const id = modalDecisionSeed++;
      modalDecisionCallbacks[id] = { onConfirm, onCancel };
      const body = `
        <div class="space-y-3 text-xs leading-5 text-slate-800">
          <div class="rounded-2xl border border-emerald-200 bg-emerald-50/80 p-3 shadow-inner">
            <div class="font-serif-title text-sm text-emerald-900 mb-1">${escapeHtml(title)}</div>
            <p>${escapeDecisionText(message)}</p>
          </div>
          <div class="grid grid-cols-2 gap-2 pt-1">
            <button onclick="resolveDecisionModal(${id}, false)" class="${cancelClass} font-bold py-2.5 rounded-2xl text-xs shadow-sm active:scale-95">${escapeHtml(cancelText)}</button>
            <button onclick="resolveDecisionModal(${id}, true)" class="${confirmClass} font-extrabold py-2.5 rounded-2xl text-xs shadow-sm active:scale-95">${escapeHtml(confirmText)}</button>
          </div>
        </div>`;
      openGenericModal(title, body, showClose);
      return id;
    }
    function resolveDecisionModal(id, accepted) {
      const ctx = modalDecisionCallbacks[id];
      if (!ctx) return closeGenericModal();
      delete modalDecisionCallbacks[id];
      closeGenericModal();
      try {
        if (accepted) ctx.onConfirm && ctx.onConfirm();
        else ctx.onCancel && ctx.onCancel();
      } catch (error) {
        console.error('Decision modal callback failed', error);
        showToast('Không thể xử lý lựa chọn vừa rồi.');
      }
    }

    function addHistory(text) {
      gameState.historyLog.push(String(text ?? "").slice(0, 2000));
      if (gameState.historyLog.length > GAME_CONFIG.maxHistoryEntries) gameState.historyLog.shift();
      markGameDirty();
    }

    function setTicker(text) {
      const el = document.getElementById("uiTicker");
      if (el) el.textContent = text;
    }

    function showToast(msg) {
      setTicker(msg);
      const existing = document.getElementById("floatingToast");
      if (existing) existing.remove();
      const toast = document.createElement("div");
      toast.id = "floatingToast";
      toast.className = "absolute top-24 left-1/2 -translate-x-1/2 z-50 bg-emerald-950/95 text-amber-200 border border-amber-400/70 px-3.5 py-2 rounded-2xl text-xs font-bold shadow-xl text-center max-w-[340px]";
      toast.textContent = msg;
      document.getElementById("appShell").appendChild(toast);
      setTimeout(() => toast.remove(), 2600);
    }

    function renderCurrentTab() {
      if (!dirtyViews.has(currentTab)) return;
      const renderers = {
        family: renderFamilyTree,
        cave: renderCaveView,
        secret: renderSecretRealmsView,
        estate: renderEstateMap,
        affairs: renderAffairsView
      };
      const renderer = renderers[currentTab];
      if (renderer) renderer();
      dirtyViews.delete(currentTab);
    }

    function updateAllUI() {
      rebuildMemberIndex();
      clampGameStateResources();
      recalcTeamMaxHp();
      document.getElementById("uiStones").textContent = Math.floor(gameState.spiritStones);
      const net = getNetMonthlyIncome();
      const incEl = document.getElementById("uiIncome");
      incEl.textContent = `${formatSigned(net)}/thg`;
      incEl.className = `text-[9px] font-bold ${net >= 0 ? "text-emerald-700" : "text-rose-600"}`;

      const hpPct = Math.round((gameState.teamHp / Math.max(1, gameState.teamMaxHp)) * 100);
      document.getElementById("uiHpText").textContent = `${Math.floor(gameState.teamHp)} / ${Math.floor(gameState.teamMaxHp)}`;
      document.getElementById("uiPopText").textContent = `${getAliveCount()}/${getMaxAbodeCapacity()}`;

      const maxGen = Math.max(1, ...gameState.members.map(member => member.generation));
      document.getElementById("uiClanTitle").textContent = `${gameState.clanSurname} Gia Tiên Tộc`;
      const lineageNames = ["Hàn Môn Linh Mạch", "Thanh Vân Linh Mạch", "Tử Khí Linh Mạch", "Thái Cổ Linh Mạch"];
      document.getElementById("uiClanSub").textContent = `Đời ${maxGen} • ${lineageNames[Math.min(3, Math.max(0, gameState.veinLevel - 1))]}`;
      document.getElementById("uiYearText").textContent = `Năm ${gameState.year}`;
      document.getElementById("uiMonthText").textContent = `Tháng ${gameState.month}`;
      const timeButton = document.getElementById("btnToggleTime");
      if (timeButton) timeButton.textContent = gameState.paused ? "▶️" : "⏸";

      const hasSingle = gameState.members.some(member =>
        member.alive && !member.spouseId && member.age >= GAME_CONFIG.minMarriageAge && !member.isMarriedIn
      );
      document.getElementById("badgeMarriage").classList.toggle("hidden", !hasSingle);
      document.getElementById("badgeEvent").classList.toggle("hidden", !gameState.pendingAdventure);

      const canUpgradeAnyTreasure = gameState.treasures.some(treasure => {
        if (treasure.cannotUpgrade) return false;
        const requiredShards = treasure.tier === "tuyet"
          ? (treasure.level + 1) * 35
          : (treasure.tier === "than" ? (treasure.level + 1) * 25 : (treasure.level + 1) * 20);
        return treasure.shards >= requiredShards;
      });
      document.getElementById("badgeTreasure").classList.toggle("hidden", !canUpgradeAnyTreasure);

      markAllViewsDirty();
      renderCurrentTab();
      markGameDirty();
    }

    // Khởi chạy: khôi phục save trước khi quyết định hiển thị màn tạo mới.
    window.addEventListener("DOMContentLoaded", () => {
      initTreePanZoom();
      const result = loadGameFromLocal();
      if (result.loaded) {
        showStartupSaveMenu(result.warning || "Đã tìm thấy tiến trình hợp lệ. Chọn Tiếp Tục để khôi phục gia tộc.");
      } else if (result.foundAny || result.error) {
        showStartupSaveMenu(result.error
          ? `Không thể tải save hiện có: ${result.error} Dữ liệu gốc vẫn được giữ; hãy nhập file backup hoặc xuất bản lưu thô.`
          : "Đã tìm thấy dữ liệu lưu nhưng chưa thể khôi phục.");
      } else {
        showStartupCreatePanel();
      }
      renderStartupModalOptions();
      startAutosaveLoop();
    });

    document.addEventListener("visibilitychange", () => {
      if (document.hidden && gameState.started) {
        if (battleState) suspendBattleForSave();
        if (gameIsDirty) saveGameToLocal({ silent: true, closeModal: false });
      }
    });

    window.addEventListener("pagehide", () => {
      if (gameState.started) {
        if (battleState) suspendBattleForSave();
        if (gameIsDirty) saveGameToLocal({ silent: true, closeModal: false });
      }
    });

    window.addEventListener("storage", event => {
      if (event.key === GAME_CONFIG.saveKey && event.newValue && gameState.started) {
        showToast("⚠️ Tiến trình được thay đổi ở tab trình duyệt khác. Hãy tải lại trước khi tiếp tục để tránh ghi đè.");
      }
    });
  

    // ========================================================================
    // Sprint 3E.2 — THIÊN CƠ ĐIỀU PHỐI
    // Điều phối hàng chờ ba nhóm lựa chọn định mệnh, không phụ thuộc Ngọc Giản.
    // Công việc quản lý thường nhật (trấn thủ/xưởng) vẫn được thao tác chủ động.
    // ========================================================================
    const S3E2_CAREER_TEMPLATE = {
      id:'s3e2_career',title:'Đạo Lộ Sơ Khai',isS3E2:true,cooldownMonths:120,
      desc:m=>`<b>${escapeHtml(m.name)}</b> đã đến lúc định chuyên môn Bách Nghệ. Con đường này sẽ theo tộc nhân suốt cuộc đời, trừ khi sau này gặp một biến cố hiếm có.`,
      choices:[...S3E_CRAFTS.map(c=>({
        id:c.id,label:`${c.icon} ${c.name} — ${c.desc}`,baseRate:95,
        onSuccess:m=>s3e2CommitCareer(m,c.id),onFail:m=>s3e2CommitCareer(m,c.id)
      })),{
        id:'free',label:'Chỉ chuyên tâm tu luyện — không nhập môn nghề',baseRate:95,
        onSuccess:m=>s3e2CommitCareer(m,'free'),onFail:m=>s3e2CommitCareer(m,'free')
      }]
    };
    const S3E2_TRIAL_TEMPLATE = {
      id:'s3e2_trial',title:'Gia Sự Tuổi Thiếu Niên',isS3E2:true,cooldownMonths:120,
      desc:m=>{const carer=getValidLivingMember(m.careGuardianId)||s3c2FindGuardian(m);
        return `<b>${escapeHtml(m.name)}</b> (tuổi ${m.age}) đứng trước một ngã rẽ trưởng thành. ${carer?'Người giám hộ '+escapeHtml(carer.name)+' đang chờ quyết định.':'Gia tộc trực tiếp chăm nom hậu duệ.'} Lựa chọn sẽ có hậu quả khi đủ 16 tuổi.`;},
      choices:Object.entries(S3C3_CHOICES).map(([id,c])=>({
        id,label:`${c.title} — ${c.description}`,baseRate:95,
        onSuccess:m=>s3e2CommitTrial(m,id),onFail:m=>s3e2CommitTrial(m,id)
      }))
    };
    const S3E2_STORY_TEMPLATES = S3D_STORIES.map(st=>({
      id:`s3e2_story_${st.id}`,title:`Thiên Mệnh Khởi Duyên · ${st.name}`,isS3E2:true,cooldownMonths:120,
      desc:m=>`<b>${escapeHtml(m.name)}</b> gặp cơ duyên mới: ${escapeHtml(st.scenes[0].replace('{name}',m.name))} Nếu nhận duyên, một hành trình ba hồi sẽ diễn ra qua nhiều năm.`,
      choices:[{
        id:'accept',label:`Đón nhận cơ duyên ${st.name}`,baseRate:95,
        onSuccess:m=>s3e2CommitStory(m,st.id,true),onFail:m=>s3e2CommitStory(m,st.id,true)
      },{
        id:'decline',label:'Khước từ cơ duyên, giữ đạo tâm yên ổn',baseRate:95,
        onSuccess:m=>s3e2CommitStory(m,st.id,false),onFail:m=>s3e2CommitStory(m,st.id,false)
      }]
    }));
    ADVENTURE_TEMPLATES.push(S3E2_CAREER_TEMPLATE,S3E2_TRIAL_TEMPLATE,...S3E2_STORY_TEMPLATES);

    ADVENTURE_TEMPLATES.push({
      id:'s3f3_council',title:'Nhân Quả Liên Điện · Hội Nghị Bí Phương',isS3E2:true,cooldownMonths:120,
      desc:m=>`Tộc nhân <b>${escapeHtml(m.name)}</b> mang Tàn Quyển Huyền Đan từ Bí Cảnh về. Nội Chính cần chọn: đầu tư Đan Các hoặc trao lại cho Dược Vương Cốc. Nghiên cứu có thể lâu nếu chưa có Đan Sư trấn thủ.`,
      choices:[
        {id:'fund',label:'Giao Đan Các nghiên cứu (35 linh thạch nếu đủ; thiếu tiền nghiên cứu chậm)',baseRate:95,
          onSuccess:m=>s3f3CommitCouncil(m,'fund'),onFail:m=>s3f3CommitCouncil(m,'fund')},
        {id:'shelved',label:'Trao tàn quyển cho Dược Vương Cốc (+6 hảo cảm), khép lại nhân quả',baseRate:95,
          onSuccess:m=>s3f3CommitCouncil(m,'shelved'),onFail:m=>s3f3CommitCouncil(m,'shelved')}
      ]
    },{
      id:'s3f3_formula',title:'Nhân Quả Liên Điện · Huyền Đan Thành Phẩm',isS3E2:true,cooldownMonths:120,
      desc:m=>`Đan Các đã giải mã bí phương. Nội Chính chọn đan dược để trở lại hỗ trợ Động Phủ hoặc đội Bí Cảnh. Chỉ nhận một thành quả.`,
      choices:[
        {id:'truc_co_dan',label:'Luyện 1 Trúc Cơ Đan, chuẩn bị vượt đại kiếp ở Động Phủ',baseRate:95,
          onSuccess:m=>s3f3CommitFormula(m,'truc_co_dan'),onFail:m=>s3f3CommitFormula(m,'truc_co_dan')},
        {id:'heal',label:'Chế 2 Hồi Xuân Đan hồi phục Bí Cảnh và kết thúc câu chuyện',baseRate:95,
          onSuccess:m=>s3f3CommitFormula(m,'heal'),onFail:m=>s3f3CommitFormula(m,'heal')}
      ]
    });

    function s3e2Key(e){return e.kind==='story'?`story:${e.storyId}:${e.memberId}`:`${e.kind}:${e.memberId}`;}
    function s3e2CommitCareer(m,id){
      if(m.craftPath!=='none' || gameState.destinySeen[`career:${m.id}`])return 'Nghề nghiệp đã được định trước.';
      const craft=S3E_CRAFTS.find(c=>c.id===id);
      gameState.destinySeen[`career:${m.id}`]=true;
      m.craftPath=craft?craft.id:'none';m.craftXp=0;m.craftLastSwitchYear=gameState.year;
      const result=craft?`chính thức nhập môn ${craft.name}.`:'chọn chuyên tâm tu luyện, không theo nghề Bách Nghệ.';
      addHistory(`Năm ${gameState.year}: ${m.name} ${result}`);
      return `${m.name} ${result} Lựa chọn được lưu thành đạo lộ cố định.`;
    }
    function s3e2CommitTrial(m,id){
      if(!s3c3EligibleChild(m)||m.familyTrial)return 'Gia sự không còn phù hợp.';
      const cfg=S3C3_CHOICES[id];if(!cfg)return 'Lựa chọn không hợp lệ.';
      // Cơ duyên xuất hiện không thu phí: không khiến cuộc đời trẻ bị khóa khi thiếu tiền.
      m.familyBond=Math.max(0,Math.min(100,(m.familyBond??40)+cfg.bond));
      m.familyTrial={choice:id,year:gameState.year,mentorId:m.mentorId??null,resolved:false};
      gameState.destinySeen[`trial:${m.id}`]=true;
      addHistory(`Năm ${gameState.year}: ${m.name} được định hướng '${cfg.title}'.`);
      return `${m.name} chọn '${cfg.title}'. Nhân quả ứng nghiệm ở tuổi 16; tình thân hiện ${m.familyBond}/100.`;
    }
    function s3e2CommitStory(m,id,accept){
      const story=S3D_STORIES.find(st=>st.id===id);
      if(!story || s3dChain(id,m.id))return 'Hành trình đã có kết quả hoặc không còn hợp lệ.';
      gameState.destinySeen[`story:${id}:${m.id}`]=true;
      if(!accept){addHistory(`Năm ${gameState.year}: ${m.name} từ chối duyên ${story.name}.`);return `${m.name} khước từ ${story.name}; cơ duyên không trở lại.`;}
      if((gameState.s3dChains||[]).filter(c=>c.status==='active').length>=5)return 'Đang có quá nhiều tuyến truyện; cơ duyên được ghi nhận để xem xét sau.';
      gameState.s3dChains.push({id:s3dChainId(id,m.id),storyId:id,memberId:m.id,stage:1,status:'active',due:getMonthIndex()+1,decisions:[]});
      addHistory(`Năm ${gameState.year}: ${m.name} đón nhận Thiên Mệnh ${story.name}; hồi đầu sẽ tới sau một tháng.`);
      return `${m.name} đón nhận ${story.name}. Một tháng sau, hồi đầu tiên sẽ đến.`;
    }
    function s3e2MakeQueue(){
      const seen=gameState.destinySeen||(gameState.destinySeen={});
      const queue=gameState.destinyQueue||(gameState.destinyQueue=[]);
      const existing=new Set(queue.map(s3e2Key));
      const add=e=>{const key=s3e2Key(e);if(!seen[key]&&!existing.has(key)&&queue.length<18){queue.push(e);existing.add(key);}};
      // 3F: Kế vị có gia bảo phải quyết định đạo thống một lần qua Kỳ Ngộ.
      const leader=getValidLivingMember(gameState.clanLeaderId);
      if(leader && leader.legacyPath==='none' && (gameState.legacyRelics||[]).length){
        add({kind:'legacy',memberId:leader.id,storyId:null});
      }
      // Ưu tiên hậu duệ 13–15 tuổi để không bỏ lỡ gia sự trước khi trưởng thành.
      for(const m of gameState.members.filter(m=>m.alive&&!m.isMarriedIn&&m.age>=8&&m.age<16).sort((a,b)=>b.age-a.age)){
        if(!m.familyTrial) add({kind:'trial',memberId:m.id,storyId:null});
      }
      for(const m of gameState.members.filter(m=>m.alive&&!m.isMarriedIn&&m.age>=16)){
        if(m.craftPath==='none' && m.craftLastSwitchYear===-1) add({kind:'career',memberId:m.id,storyId:null});
         // 3F.1: Cơ duyên huyết mạch chỉ dành cho hậu duệ có tổ tiên ruột thực sự để lại dấu ấn.
         if(!seen[`bloodline:${m.id}`] && !m.bloodlineInheritance && s3f1FindAncestor(m))
           add({kind:'bloodline',memberId:m.id,storyId:null});
      }
      // 3E.3: sư đồ và định hướng xuất hiện theo thời gian, một lần cho mỗi tộc nhân.
      for(const child of gameState.members.filter(m=>m.alive&&!m.isMarriedIn&&m.age>=8&&m.age<16).sort((a,b)=>b.age-a.age)){
        if(!seen[`mentor:${child.id}`] && !child.mentorId && s3c2MentorCandidates(child).length)
          add({kind:'mentor',memberId:child.id,storyId:null});
        if(!seen[`education:${child.id}`] && child.educationPath==='none')
          add({kind:'education',memberId:child.id,storyId:null});
      }
      for(const m of gameState.members.filter(m=>m.alive&&!m.isMarriedIn&&m.age>=16&&!m.inheritedTeaching)){
        if(!seen[`transmission:${m.id}`] && s3e3CanTransmit(m))
          add({kind:'transmission',memberId:m.id,storyId:null});
      }
      // Mỗi tộc nhân tối đa một lời mời Thiên Mệnh; không tự mở hàng loạt tuyến truyện.
      if(gameState.s3dChains.filter(c=>c.status==='active').length<5 && queue.length<8){
        const candidates=gameState.members.filter(m=>m.alive&&!m.isMarriedIn&&m.age>=16&&
          !Object.keys(seen).some(k=>k.startsWith('story:')&&k.endsWith(':'+m.id)) &&
          !gameState.s3dChains.some(c=>c.memberId===m.id));
        if(candidates.length && getMonthIndex()%12===0){
          const m=candidates[(gameState.year+gameState.month)%candidates.length];
          const allowed=S3D_STORIES.filter(st=>s3dEligible(st,m)&&!s3dChain(st.id,m.id));
          if(allowed.length){const st=allowed[(gameState.year+m.id)%allowed.length];add({kind:'story',memberId:m.id,storyId:st.id});}
        }
      }
      if(queue.length>18)queue.length=18;
    }
    function s3e2DispatchDestiny(){
      if(gameState.pendingAdventure||battleState||gameState.clanExtinct||!gameState.started)return false;
      const now=getMonthIndex();
      // Một lựa chọn lớn tối đa mỗi 3 tháng, hạn chế popup khi tộc nhân quá đông.
      if(now-(gameState.destinyLastMonth??-100)<3)return false;
      s3e2MakeQueue();
      const q=gameState.destinyQueue;
      for(let i=0;i<q.length;i++){
        const e=q[i],m=getValidLivingMember(e.memberId),key=s3e2Key(e);
        const valid=!!(m&&!gameState.destinySeen[key]&&(
          e.kind==='trial'?(s3c3EligibleChild(m)&&!m.familyTrial):
          e.kind==='career'?(m.age>=16&&m.craftPath==='none'&&m.craftLastSwitchYear===-1):
          e.kind==='mentor'?(m.age>=8&&m.age<16&&!m.mentorId&&s3c2MentorCandidates(m).length>0):
          e.kind==='education'?(m.age>=8&&m.age<16&&m.educationPath==='none'):
          e.kind==='transmission'?s3e3CanTransmit(m):
          e.kind==='legacy'?(m.id===gameState.clanLeaderId && m.legacyPath==='none' && gameState.legacyRelics.length>0):
           e.kind==='bloodline'?(m.age>=16 && !m.isMarriedIn && !m.bloodlineInheritance && !!s3f1FindAncestor(m)) :
          (s3dEligible(S3D_STORIES.find(st=>st.id===e.storyId),m)&&!s3dChain(e.storyId,m.id)&&gameState.s3dChains.filter(c=>c.status==='active').length<5)
        ));
        if(!valid){q.splice(i--,1);continue;}
        const templateId=e.kind==='story'?`s3e2_story_${e.storyId}`:`s3e2_${e.kind}`;
        if(!ADVENTURE_TEMPLATES.some(t=>t.id===templateId)){q.splice(i--,1);continue;}
        q.splice(i,1);
        gameState.pendingAdventure={eventId:templateId,memberId:m.id,context:{},createdAtMonthIndex:now};
        gameState.destinyLastMonth=now;gameState.lastAdventureMonthIndex=now;
        markGameDirty();renderAdventureModal();return true;
      }
      return false;
    }



    // Sprint 3E.3 — ĐẠO LỘ ĐỊNH MỆNH: Mỗi lựa chọn là vết khắc của tuổi trẻ.
    function s3e3CanTransmit(disciple){
      const mentor=disciple?getValidLivingMember(disciple.mentorId):null;
      return !!(disciple&&disciple.alive&&disciple.age>=16&&!disciple.inheritedTeaching&&
        mentor&&mentor.id!==disciple.id&&mentor.age>=18&&mentor.realmIdx>=3&&
        (disciple.familyBond??40)>=60&&gameState.spiritStones>=35);
    }
    function s3e3MentorOptions(m){
      return s3c2MentorCandidates(m).filter(t=>t.alive).sort((a,b)=>b.realmIdx-a.realmIdx||a.id-b.id).slice(0,3);
    }
    function s3e3CommitMentor(m,mentorId){
      const key=`mentor:${m.id}`;
      if(gameState.destinySeen[key] || m.age>=16 || m.mentorId)return 'Đạo duyên đã định, không thể thay đổi.';
      const mentor=mentorId==null?null:s3c2MentorCandidates(m).find(t=>t.id===mentorId);
      if(mentorId!=null&&!mentor)return 'Vị sư phụ không còn đủ điều kiện.';
      gameState.destinySeen[key]=true;
      m.mentorId=mentor?.id??null;
      if(mentor)m.familyBond=Math.min(100,(m.familyBond??40)+3);
      const result=mentor?`${m.name} bái ${mentor.name} làm sư phụ; quan hệ sư đồ được xác lập.`:`${m.name} chọn tự học, không bái sư trong tuổi thiếu niên.`;
      addHistory(`Năm ${gameState.year}: ${result}`);return result;
    }
    function s3e3CommitEducation(m,kind){
      const key=`education:${m.id}`, course=S3B_EDUCATION[kind];
      if(!course||gameState.destinySeen[key]||m.age>=16||m.educationPath!=='none')return 'Định hướng đã được quyết định.';
      gameState.destinySeen[key]=true;m.educationPath=kind;
      addHistory(`Năm ${gameState.year}: ${m.name} chọn con đường ${course.name}; tự học hằng năm khi đủ nguồn lực.`);
      return `${m.name} chọn ${course.name}. Từ nay giáo dưỡng tiến triển theo năm, không cần bấm từng khóa.`;
    }
    function s3e3ProcessAutomaticEducation(){
      // Sau khi tính nguồn thu, chi phí được trừ tối đa một lần mỗi năm. Nếu vừa định hướng giữa năm, học từ tháng kế tiếp.
      const children=gameState.members.filter(m=>m.alive&&!m.isMarriedIn&&m.age>=8&&m.age<16&&
        m.educationPath!=='none'&&(m.educationLessons||0)<6&&m.lastEducationYear!==gameState.year)
        .sort((a,b)=>b.age-a.age||a.id-b.id);
      for(const m of children){
        const kind=m.educationPath,course=S3B_EDUCATION[kind];
        if(!course||gameState.spiritStones<course.cost)continue;
        gameState.spiritStones-=course.cost;
        m.educationLessons=(m.educationLessons||0)+1;m.lastEducationYear=gameState.year;
        const bonus=s3c2LessonBonus(m,kind),guardian=getMemberById(m.careGuardianId)||s3c2FindGuardian(m);
        m.familyBond=Math.min(100,(m.familyBond??40)+(guardian?.alive?4:1)+(bonus>0?2:0));
        if(kind==='dao'){
          m.xp=Math.min(REALMS[m.realmIdx].maxXp,m.xp+12+bonus*3);
          m.innerDemon=Math.max(0,m.innerDemon-3);m.dodge=+(m.dodge+0.3).toFixed(1);
        }else if(kind==='dan'){
          m.bonusHp+=8+bonus*2;m.bonusDef+=2+Math.floor(bonus/2);m.lifesteal=+(m.lifesteal+0.25).toFixed(2);
        }else{
          m.bonusAtk+=3+bonus;m.bonusSpd+=2+Math.floor(bonus/2);m.crit=+(m.crit+0.25).toFixed(2);
        }
        addHistory(`Năm ${gameState.year}: ${m.name} tự hoàn thành ${course.name} (${m.educationLessons}/6), tình thân ${m.familyBond}/100.`);
        markGameDirty();
      }
    }
    function s3e3CommitTransmission(m,accept){
      const key=`transmission:${m.id}`,mentor=getValidLivingMember(m.mentorId);
      if(gameState.destinySeen[key]||m.inheritedTeaching)return 'Cơ duyên đã được định đoạt.';
      if(!s3e3CanTransmit(m))return 'Chưa đủ điều kiện để truyền công.';
      gameState.destinySeen[key]=true;
      if(!accept){const result=`${m.name} khước từ truyền công của ${mentor.name}; cơ duyên này đã khép lại.`;
        addHistory(`Năm ${gameState.year}: ${result}`);return result;}
      gameState.spiritStones-=35;m.inheritedTeaching=true;
      const gain=Math.min(90,20+mentor.realmIdx*4);
      addXp(m,gain);m.bonusAtk+=Math.min(6,1+Math.floor(mentor.realmIdx/4));
      m.familyBond=Math.min(100,(m.familyBond??40)+5);
      const result=`${mentor.name} truyền công cho ${m.name}; +${gain} tu vi và tăng tấn công.`;
      addHistory(`Năm ${gameState.year}: ${result}`);return result;
    }
    // Template choices created at runtime with member-specific mentor ids, but callbacks stay static.
    const S3E3_MENTOR_TEMPLATE={id:'s3e2_mentor',title:'Duyên Sư Đồ',isS3E2:true,
      desc:m=>`<b>${escapeHtml(m.name)}</b> đến tuổi tìm thầy học đạo. Chọn một sư phụ phù hợp, hoặc quyết định tự học. Đây là lựa chọn duy nhất của thời thiếu niên.`,
      choices:[...Array.from({length:3},(_,i)=>({id:`mentor_${i}`,label:`Bái sư theo thứ tự ứng viên ${i+1}`,baseRate:100,
        onSuccess:m=>{const mentor=s3e3MentorOptions(m)[i];return mentor?s3e3CommitMentor(m,mentor.id):'Ứng viên không còn phù hợp.';},
        onFail:m=>{const mentor=s3e3MentorOptions(m)[i];return mentor?s3e3CommitMentor(m,mentor.id):'Ứng viên không còn phù hợp.';}})),
        {id:'self',label:'Tự học không bái sư',baseRate:100,onSuccess:m=>s3e3CommitMentor(m,null),onFail:m=>s3e3CommitMentor(m,null)}]};
    const S3E3_EDUCATION_TEMPLATE={id:'s3e2_education',title:'Định Hướng Giáo Dưỡng',isS3E2:true,
      desc:m=>`<b>${escapeHtml(m.name)}</b> được định hướng giáo dưỡng. Chọn một môn học cả tuổi thiếu niên; mỗi năm gia tộc tự chi linh thạch cho một khóa khi đủ nguồn lực.`,
      choices:Object.entries(S3B_EDUCATION).map(([id,c])=>({id,label:`${c.name} — ${c.desc}, ${c.cost} linh thạch/năm`,baseRate:100,
        onSuccess:m=>s3e3CommitEducation(m,id),onFail:m=>s3e3CommitEducation(m,id)}))};
    const S3E3_TRANSMISSION_TEMPLATE={id:'s3e2_transmission',title:'Sư Môn Truyền Công',isS3E2:true,
      desc:m=>{const mentor=getMemberById(m.mentorId);return `<b>${escapeHtml(m.name)}</b> đã đủ duyên nhận truyền công từ <b>${escapeHtml(mentor?.name||'sư phụ')}</b>. Nghi thức tốn 35 linh thạch; từ chối sẽ khép lại cơ duyên.`;},
      choices:[{id:'accept',label:'Nhận truyền công · 35 linh thạch',baseRate:100,onSuccess:m=>s3e3CommitTransmission(m,true),onFail:m=>s3e3CommitTransmission(m,true)},
      {id:'decline',label:'Từ chối, tự tìm đạo của mình',baseRate:100,onSuccess:m=>s3e3CommitTransmission(m,false),onFail:m=>s3e3CommitTransmission(m,false)}]};
    ADVENTURE_TEMPLATES.push(S3E3_MENTOR_TEMPLATE,S3E3_EDUCATION_TEMPLATE,S3E3_TRANSMISSION_TEMPLATE);


    // Sprint 3F — GIA BẢO & TRUYỀN THỪA
    const S3F_LEGACY_NAMES={
      scholar:'Ngọc Giản Di Huấn',guardian:'Hộ Tộc Ấn',industry:'Linh Nghiệp Phù'
    };
    const S3F_PATHS={
      dao:{title:'Đạo Thống Kinh Văn',explain:'Toàn tộc +1 tu vi mỗi tháng (qua cộng tu vi cơ nghiệp).'},
      bao:{title:'Hộ Tộc Tâm Pháp',explain:'Toàn tộc +2 Phòng Thủ trong đời Tộc Trưởng này.'},
      nghiep:{title:'Khai Nghiệp Gia Phong',explain:'Tăng 2% hiệu quả thu nhập cơ nghiệp trong đời Tộc Trưởng này.'}
    };
    function s3fLegacyKind(m){
      const craft=S3E_CRAFTS.find(c=>c.id===m.craftPath);
      if(craft&&['dan_cac','tang_kinh'].includes(craft.id))return 'scholar';
      if(craft&&['to_son','khi_phuong'].includes(craft.id))return 'guardian';
      if(craft&&['linh_dien','linh_mo'].includes(craft.id))return 'industry';
      // Nếu chưa học nghề, di bảo phản ánh cảnh giới đạt được; kết quả xác định không phụ thuộc RNG.
      return m.realmIdx>=7?'scholar':m.realmIdx>=4?'guardian':'industry';
    }
    function s3fSealLeaderLegacy(leader){
      if(!leader || leader.role!=='Tộc Trưởng')return;
      const list=gameState.legacyRelics||(gameState.legacyRelics=[]);
      if(list.some(r=>r.originId===leader.id))return;
      const kind=s3fLegacyKind(leader), name=S3F_LEGACY_NAMES[kind];
      list.push({id:`leader:${leader.id}`,originId:leader.id,originName:leader.name,
        year:gameState.year,generation:leader.generation,craftId:leader.craftPath||'none',
        legacyKind:kind,name});
      if(list.length>16)list.splice(0,list.length-16);
      addHistory(`Năm ${gameState.year}: Di bảo ${name} của Tộc Trưởng ${leader.name} được lưu vào Từ Đường, chờ đời sau kế thừa.`);
      invalidateAggregateBonuses();
    }
    function s3fSuccession(heir){
      const relics=gameState.legacyRelics||[];
      gameState.legacyActiveRelicId=relics.length?relics[relics.length-1].id:null;
      invalidateAggregateBonuses();
      if(!heir||!relics.length||heir.legacyPath!=='none')return;
      const key=`legacy:${heir.id}`;
      if(gameState.destinySeen?.[key])return;
      const q=gameState.destinyQueue||(gameState.destinyQueue=[]);
      if(!q.some(e=>e.kind==='legacy'&&e.memberId===heir.id)){
        q.unshift({kind:'legacy',memberId:heir.id,storyId:null});
        if(q.length>18)q.length=18;
      }
      addHistory(`Năm ${gameState.year}: ${heir.name} kế vị, chuẩn bị tiếp nhận di huấn của tiền nhân.`);
    }
    function s3fAcceptInheritance(leader,path){
      const key=`legacy:${leader.id}`;
      if(!leader.alive||leader.id!==gameState.clanLeaderId||leader.legacyPath!=='none'||
         !S3F_PATHS[path]||gameState.destinySeen[key])return 'Đạo thống đã được định hoặc người kế vị không hợp lệ.';
      if(!gameState.legacyRelics.length)return 'Gia tộc chưa có di bảo.';
      leader.legacyPath=path;
      leader.legacyReceivedYear=gameState.year;
      gameState.destinySeen[key]=true;
      invalidateAggregateBonuses();
      const relic=gameState.legacyRelics.find(r=>r.id===gameState.legacyActiveRelicId);
      const message=`${leader.name} kế thừa ${relic?.name||'Gia Bảo'} và lập đạo thống ${S3F_PATHS[path].title}. ${S3F_PATHS[path].explain}`;
      addHistory(`Năm ${gameState.year}: ${message}`);
      return message;
    }
    function s3fLegacyPanel(m){
      const relics=gameState.legacyRelics||[];
      const active=relics.find(r=>r.id===gameState.legacyActiveRelicId);
      const leader=gameState.members.find(t=>t.id===gameState.clanLeaderId&&t.alive);
      const path=S3F_PATHS[leader?.legacyPath];
      return `<details class="bg-amber-50 border border-amber-300 rounded-xl p-3 text-[11px]" open>
        <summary class="font-extrabold text-emerald-950 cursor-pointer">🏯 Gia Bảo & Truyền Thừa · ${relics.length} đời lưu dấu</summary>
        <div class="space-y-2 mt-2">
          <div><b>Di bảo đang phụng thờ:</b> ${escapeHtml(active?.name||'Chưa có')} ${active?'— '+escapeHtml(active.originName):''}</div>
          <div><b>Đạo thống đương nhiệm:</b> ${escapeHtml(path?.title||'Chưa lập')} ${path?'· '+escapeHtml(path.explain):''}</div>
          <div><b>Đạo thống cá nhân:</b> ${escapeHtml(S3F_PATHS[m.legacyPath]?.title||'Không có')}</div>
          <div class="border-t border-amber-200 pt-2 space-y-1">${relics.length?relics.slice().reverse().map(r=>
            `<div class="bg-white rounded-lg border border-amber-100 px-2 py-1.5">${r.id===gameState.legacyActiveRelicId?'✨ ':''}<b>${escapeHtml(r.name)}</b> · ${escapeHtml(r.originName)} · Đời ${r.generation}, năm ${r.year}</div>`).join(''):'Gia tộc chưa có Tộc Trưởng để lại gia bảo.'}</div>
          <div class="text-amber-900">Chỉ một di bảo và một đạo thống của Tộc Trưởng đương nhiệm có hiệu lực. Những di bảo cũ được lưu để ghi nhớ lịch sử.</div>
        </div></details>`;
    }

    // Sprint 3F.3 — TRUYỀN THỪA HUYẾT MẠCH
    // Không coi người giám hộ / cha mẹ nuôi là huyết thống. Tối đa ba đời truy nguồn.
    // Dấu ấn nhận một lần, chỉ số tăng nhẹ; không sao chép tu vi hay chỉ số tổ tiên.
    const S3F1_PATHS={
      dao:{name:'Thừa Kế Đạo Tâm',detail:'+22 tu vi, giảm 3 Tâm Ma, +4 tình thân'},
      nghe:{name:'Tiếp Nối Bách Nghệ',detail:'+18 kinh nghiệm nghề nếu đã học nghề; nếu chưa học thì +15 tu vi, +4 tình thân'},
      ho:{name:'Giữ Gìn Huyết Mạch',detail:'+10 sinh lực, +2 phòng thủ, +4 tình thân'}
    };
    function s3f1AncestorIds(child){
      if(!child || child.lineageType!=='birth')return [];
      let ids=[child.biologicalFatherId,child.biologicalMotherId].filter(Number.isInteger);
      const visited=new Set([child.id]),result=[];
      for(let depth=0;depth<3 && ids.length;depth++){
        const next=[];
        for(const id of ids){
          if(visited.has(id))continue;
          visited.add(id);
          const a=getMemberById(id);
          if(!a)continue;
          result.push({member:a,depth:depth+1});
          if(a.lineageType==='birth'){
            if(Number.isInteger(a.biologicalFatherId))next.push(a.biologicalFatherId);
            if(Number.isInteger(a.biologicalMotherId))next.push(a.biologicalMotherId);
          }
        }
        ids=next;
      }
      return result;
    }
    function s3f1Achievement(a){
      if(!a)return null;
      const relic=(gameState.legacyRelics||[]).find(r=>r.originId===a.id);
      if(relic)return {title:relic.name,kind:relic.legacyKind,weight:100};
      if(a.legacyPath && a.legacyPath!=='none')return {title:'Đạo Thống '+(S3F_PATHS[a.legacyPath]?.title||'Gia Tộc'),kind:'scholar',weight:65};
      if(a.craftPath && a.craftPath!=='none' && (a.craftXp||0)>=10){
        const craft=S3E_CRAFTS.find(c=>c.id===a.craftPath);
        return {title:'Tay Nghề '+(craft?.name||'Bách Nghệ'),kind:'industry',weight:50};
      }
      if(a.familyTrial?.resolved)return {title:'Dấu Ấn Gia Sự',kind:'guardian',weight:30};
      if(a.realmIdx>=3)return {title:'Căn Cơ Tu Hành',kind:'scholar',weight:20};
      return null;
    }
    function s3f1FindAncestor(m){
      return s3f1AncestorIds(m).map(({member,depth})=>{
        const mark=s3f1Achievement(member);
        return mark?{member,depth,...mark}:null;
      }).filter(Boolean).sort((a,b)=>b.weight-a.weight || a.depth-b.depth || a.member.id-b.member.id)[0]||null;
    }
    function s3f1Commit(m,path){
      const key=`bloodline:${m.id}`;
      if(!m.alive || m.isMarriedIn || m.age<16 || m.bloodlineInheritance || gameState.destinySeen[key] || !S3F1_PATHS[path])
        return 'Huyết mạch đã có lựa chọn hoặc tộc nhân không hợp lệ.';
      const a=s3f1FindAncestor(m);
      if(!a)return 'Không còn tìm thấy dấu ấn của tổ tiên ruột.';
      m.bloodlineInheritance={path,ancestorId:a.member.id,year:gameState.year};
      gameState.destinySeen[key]=true;
      m.familyBond=Math.min(100,(m.familyBond??40)+4);
      if(path==='dao'){
        addXp(m,22);
        m.innerDemon=Math.max(0,m.innerDemon-3);
      }else if(path==='nghe'){
        if(m.craftPath && m.craftPath!=='none') m.craftXp=Math.min(2000,(m.craftXp||0)+18);
        else addXp(m,15);
      }else{
        m.bonusHp+=10;m.bonusDef+=2;
      }
      const result=`${m.name} nhận lời nhắn từ huyết mạch ${a.member.name} (đời trước ${a.depth} thế hệ), nối tiếp ${a.title}, chọn ${S3F1_PATHS[path].name}.`;
      addHistory(`Năm ${gameState.year}: ${result}`);
      markGameDirty();invalidateAggregateBonuses();
      return result;
    }
    function s3f1BloodlinePanel(m){
      if(m.isMarriedIn)return '';
      const data=m.bloodlineInheritance;
      const origin=data?getMemberById(data.ancestorId):null;
      const anc=s3f1FindAncestor(m);
      const status=data
        ?`<b>${escapeHtml(S3F1_PATHS[data.path]?.name||'Đã kế thừa')}</b> · Năm ${data.year} · Từ ${escapeHtml(origin?.name||'tiền nhân')}`
        :anc?`Có cơ duyên từ <b>${escapeHtml(anc.member.name)}</b> (${escapeHtml(anc.title)}). Lựa chọn sẽ xuất hiện qua Thiên Cơ.`
        :'Chưa có tổ tiên ruột đủ dấu ấn để phát sinh cơ duyên.';
      return `<details class="bg-amber-50 border border-amber-200 rounded-xl p-3 text-[11px]">
        <summary class="font-extrabold text-emerald-950 cursor-pointer">🩸 Truyền Thừa Huyết Mạch</summary>
        <div class="pt-2 text-slate-700">${status}</div>
        <div class="mt-1 text-amber-900">Truy nguồn theo cha mẹ ruột, tối đa ba đời. Chỉ nhận một lựa chọn duy nhất; không cộng dồn sức mạnh của tiền nhân.</div>
      </details>`;
    }
    ADVENTURE_TEMPLATES.push({
      id:'s3e2_bloodline',title:'Huyết Mạch Hồi Âm',isS3E2:true,cooldownMonths:120,
      desc:m=>{
        const a=s3f1FindAncestor(m);
        return a?`<b>${escapeHtml(m.name)}</b> phát hiện lời nhắn truyền đời từ <b>${escapeHtml(a.member.name)}</b>, một tổ tiên ruột cách ${a.depth} thế hệ. Di sản <b>${escapeHtml(a.title)}</b> không thể cho sức mạnh ngay lập tức, nhưng có thể soi lối tu hành. Chọn một cách kế thừa, không thể đổi tùy ý.`
          :'Dòng huyết mạch chưa có di huấn phù hợp.';
      },
      choices:Object.entries(S3F1_PATHS).map(([id,c])=>({
        id,label:`${c.name} — ${c.detail}`,baseRate:100,
        onSuccess:m=>s3f1Commit(m,id),onFail:m=>s3f1Commit(m,id)
      }))
    });

    ADVENTURE_TEMPLATES.push({
      id:'s3e2_legacy',title:'Gia Bảo Truyền Thừa',isS3E2:true,
      desc:m=>{const relic=(gameState.legacyRelics||[]).find(r=>r.id===gameState.legacyActiveRelicId);
        return `<b>${escapeHtml(m.name)}</b> kế vị Tộc Trưởng, bước vào Từ Đường trước <b>${escapeHtml(relic?.name||'di bảo tổ truyền')}</b> của tiền nhân. Chọn một đạo thống duy trì trong đời mình. Quyết định không thể tự thay đổi, nhưng đời Tộc Trưởng sau sẽ chọn con đường riêng.`;},
      choices:Object.entries(S3F_PATHS).map(([id,info])=>({id,label:`${info.title} — ${info.explain}`,baseRate:100,
        onSuccess:m=>s3fAcceptInheritance(m,id),onFail:m=>s3fAcceptInheritance(m,id)}))
    });

