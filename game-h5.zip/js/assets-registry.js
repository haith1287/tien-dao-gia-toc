
window.TDGT_ASSETS = Object.freeze({"familyBg":"assets/images/asset_0411_de75f1e74860.jpg","battleBg":"assets/images/asset_0412_bd304bb0fdd8.jpg","estateBg":"assets/images/asset_0413_d3fb77d419c8.jpg","peachBg":"assets/images/asset_0414_14d039518738.jpg","cultivatorMale":"assets/images/asset_0415_3dce4bec023f.webp","cultivatorFemale":"assets/images/asset_0416_972c119698c9.webp","treasureSheet":"assets/images/asset_0417_65e03760345d.webp","monsterSheet":"assets/images/asset_0418_6e6d91859527.webp","uiSheet":"assets/images/asset_0419_ffe1111e0e5a.webp"});
(function(){
  const a = window.TDGT_ASSETS;
  const root = document.documentElement.style;
  root.setProperty("--asset-family-bg", `url("${a.familyBg}")`);
  root.setProperty("--asset-battle-bg", `url("${a.battleBg}")`);
  root.setProperty("--asset-estate-bg", `url("${a.estateBg}")`);
  root.setProperty("--asset-peach-bg", `url("${a.peachBg}")`);
  root.setProperty("--asset-ui-sheet", `url("${a.uiSheet}")`);
  root.setProperty("--asset-cultivator-male", `url("${a.cultivatorMale}")`);
  root.setProperty("--asset-cultivator-female", `url("${a.cultivatorFemale}")`);
  root.setProperty("--asset-treasure-sheet", `url("${a.treasureSheet}")`);
  root.setProperty("--asset-monster-sheet", `url("${a.monsterSheet}")`);
})();
