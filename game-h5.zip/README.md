# Sprint 3F.4.3 — Bản H5 có cảnh báo mở offline

**Lưu ý quan trọng:** Nếu bạn mở riêng `index.html` trong Google Drive, Android `content://` hoặc chế độ `file://`, rất có thể hình nền và ảnh công trình bị trắng do trình duyệt không cho tải các tài nguyên anh em. Đây là giới hạn cách mở game, không có nghĩa ảnh bị mất khỏi ZIP.

- **Muốn chơi ngay trên điện thoại:** sử dụng file `TienDaoGiaToc_Sprint3F43_SuaLoiAnh_Offline.html` riêng. Tất cả ảnh và mã được nhúng vào duy nhất một file.
- **Muốn chạy bản H5:** giải nén đầy đủ và xuất bản toàn bộ thư mục lên một static web server HTTPS, ví dụ GitHub Pages/Cloudflare Pages. Sau đó mở URL đến `index.html`.
- **Không nên** upload mỗi `index.html` vào Drive rồi mở; thư mục `assets/images` sẽ không được phục vụ như cùng một website.

## Kiểm tra nội bộ

Đã kiểm tra tồn tại và đường dẫn của tất cả tài nguyên trong thư mục H5. Chưa có kiểm thử runtime qua browser do Chromium trong môi trường này chặn localhost.

---

# Tiên Đạo Gia Tộc — Sprint 3F.4.3 H5 Core

Đây là bản **tách file kỹ thuật** từ Sprint 3F.4.2; không chủ ý thay đổi logic gameplay hoặc save.

- `index.html`: khung HTML; giữ thứ tự tải script như bản gốc.
- `css/game.css`: CSS gốc được tách ra.
- `js/`: 5 script gốc theo đúng thứ tự.
- `assets/images/`: ảnh được trích từ dữ liệu Base64 và khử trùng lặp theo SHA-256.
- `docs/asset-manifest.json`: bảng kê tài nguyên.

**Cách chạy:** giải nén toàn bộ ZIP, giữ nguyên cấu trúc thư mục; khuyến nghị chạy qua server HTTP(S). Ví dụ từ thư mục game: `python -m http.server 8000`, sau đó mở `http://localhost:8000`.

**Google Drive chỉ để lưu trữ.** Tệp HTML mở trực tiếp trong giao diện Google Drive không phải máy chủ website và có thể không tải được CSS/JS/ảnh bên cạnh. Để chạy H5 thật sự, xuất bản lên GitHub Pages, Cloudflare Pages hoặc một máy chủ tĩnh.

**Lưu ý:** Bản gốc vẫn phụ thuộc Tailwind CDN/Google Fonts để trình bày một số thành phần; việc tách file chưa biến thành bản offline tuyệt đối và chưa chia lại khối `game-main.js` theo module để tránh tác động logic.

**Save:** giữ nguyên key và định dạng lưu của HTML gốc. Save trong trình duyệt phụ thuộc origin (URL), nên khi chuyển từ `file://` sang website mới sẽ cần xuất/nhập save JSON.
